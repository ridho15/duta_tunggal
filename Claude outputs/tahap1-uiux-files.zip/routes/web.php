<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Livewire\Settings\Profile;
use App\Livewire\Settings\Password;
use App\Livewire\Settings\Appearance;
use App\Http\Controllers\Reports\StockReportController;
use App\Http\Controllers\Reports\FinancialReportPreviewController;
use App\Http\Controllers\Reports\TrialBalancePreviewController;
use App\Http\Controllers\Reports\CogmPreviewController;
use App\Http\Controllers\InventoryCardController;
use App\Http\Controllers\PdfPreviewController;

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::get('settings/profile', Profile::class)->name('settings.profile');
    Route::get('settings/password', Password::class)->name('settings.password');
    Route::get('settings/appearance', Appearance::class)->name('settings.appearance');
});

// Add home route for authenticated users
Route::middleware('auth')->group(function () {
    Route::get('/', function () {
        // Redirect authenticated users to the Filament admin dashboard by default.
        // Use the dashboard page class to derive the current route name so
        // production changes (slug overrides) won't break the redirect.
        return redirect()->route(
            \App\Filament\Pages\MyDashboard::getRouteName()
        );
    })->name('home');
});

// Provide a small compatibility route named 'login' so framework helpers
// and third-party packages that call route('login') can redirect guests
// to the Filament admin sign-in page. This route simply redirects to
// the Filament admin base path which serves the login UI.
Route::middleware('throttle:login')->get('/login', function () {
    return redirect('/admin');
})->name('login');

// Provide a logout route for testing compatibility
Route::post('/logout', function () {
    Auth::logout();
    return redirect('/admin');
})->name('logout');

// Local-only route to serve temporary exported files (used by Filament/Livewire JSON flow)
Route::get('exports/download/{filename}', function ($filename) {
    if (app()->environment() !== 'local') {
        abort(404);
    }

    $path = storage_path('app/exports/' . basename($filename));
    if (! file_exists($path)) {
        abort(404);
    }

    return response()->download($path, $filename)->deleteFileAfterSend(true);
})->name('exports.download');

if (app()->environment('local')) {
    Route::get('/dev-autologin', function () {
        $user = \App\Models\User::first();
        if ($user) {
            \Illuminate\Support\Facades\Auth::login($user);
        }
        return redirect('/admin/order-requests/create');
    });

    Route::get('/dev-autologin-po', function () {
        $user = \App\Models\User::first();
        if ($user) {
            \Illuminate\Support\Facades\Auth::login($user);
        }
        return redirect('/admin/purchase-orders/create');
    });

    Route::get('/dev-autologin-qo', function () {
        $user = \App\Models\User::first();
        if ($user) {
            \Illuminate\Support\Facades\Auth::login($user);
        }
        return redirect('/admin/quotations/create');
    });

    Route::get('/dev-autologin-so', function () {
        $user = \App\Models\User::first();
        if ($user) {
            \Illuminate\Support\Facades\Auth::login($user);
        }
        return redirect('/admin/sale-orders/create');
    });
}

// Reports preview routes
Route::middleware(['auth', 'throttle:60,1'])->group(function () {
    Route::get('/reports/stock-report/preview', [StockReportController::class, 'preview'])
        ->name('reports.stock-report.preview');

    Route::get('/reports/trial-balance/preview', [TrialBalancePreviewController::class, 'preview'])
        ->name('reports.trial-balance.preview');

    Route::get('/reports/cogm/preview', [CogmPreviewController::class, 'preview'])
        ->name('reports.cogm.preview');

    // Financial report standalone previews (no Filament layout)
    Route::get('/reports/financial-statement/preview', [FinancialReportPreviewController::class, 'financialStatement'])->name('reports.financial-statement.preview');
    Route::get('/reports/financial-statement/download-pdf', [FinancialReportPreviewController::class, 'financialStatementPdf'])->name('reports.financial-statement.pdf');
    Route::get('/reports/financial-statement/download-excel', [FinancialReportPreviewController::class, 'financialStatementExcel'])->name('reports.financial-statement.excel');
    Route::get('/reports/drill-down-financial-report/preview', [FinancialReportPreviewController::class, 'drillDownFinancialReport'])->name('reports.drill-down-financial-report.preview');
    Route::get('/reports/drill-down-financial-report/download-pdf', [FinancialReportPreviewController::class, 'drillDownFinancialReportPdf'])->name('reports.drill-down-financial-report.pdf');
    Route::get('/reports/drill-down-financial-report/download-excel', [FinancialReportPreviewController::class, 'drillDownFinancialReportExcel'])->name('reports.drill-down-financial-report.excel');
    Route::get('/reports/alk-grafik/preview', [FinancialReportPreviewController::class, 'alkGrafik'])->name('reports.alk-grafik.preview');
    Route::get('/reports/alk-grafik/download-pdf', [FinancialReportPreviewController::class, 'alkGrafikPdf'])->name('reports.alk-grafik.pdf');
    Route::get('/reports/alk-grafik/download-excel', [FinancialReportPreviewController::class, 'alkGrafikExcel'])->name('reports.alk-grafik.excel');
    Route::get('/reports/balance-sheet/preview',   [FinancialReportPreviewController::class, 'balanceSheet'])->name('reports.balance-sheet.preview');
    Route::get('/reports/profit-and-loss/preview', [FinancialReportPreviewController::class, 'profitAndLoss'])->name('reports.profit-and-loss.preview');
    Route::get('/reports/profit-loss-multi-division/preview', [FinancialReportPreviewController::class, 'profitLossMultiDivision'])->name('reports.profit-loss-multi-division.preview');
    Route::get('/reports/profit-loss-multi-division/download-excel', [FinancialReportPreviewController::class, 'profitLossMultiDivisionExcel'])->name('reports.profit-loss-multi-division.excel');
    Route::get('/reports/cash-flow/preview',       [FinancialReportPreviewController::class, 'cashFlow'])->name('reports.cash-flow.preview');
    Route::get('/reports/hpp/preview',             [FinancialReportPreviewController::class, 'hpp'])->name('reports.hpp.preview');
    Route::get('/reports/ageing-report/preview',   [FinancialReportPreviewController::class, 'ageingReport'])->name('reports.ageing-report.preview');
    Route::get('/reports/journal-consolidation/preview', [FinancialReportPreviewController::class, 'journalConsolidation'])->name('reports.journal-consolidation.preview');

    // Kartu Persediaan — print / PDF / Excel
    Route::get('/reports/inventory-card/print',          [InventoryCardController::class, 'printView'])->name('inventory-card.print');
    Route::get('/reports/inventory-card/download-pdf',   [InventoryCardController::class, 'downloadPdf'])->name('inventory-card.pdf');
    Route::get('/reports/inventory-card/download-excel', [InventoryCardController::class, 'downloadExcel'])->name('inventory-card.excel');

    // Bukti penerimaan customer (disk privat, berotorisasi lewat CustomerReceiptPolicy::view)
    Route::get('/customer-receipts/{receipt}/proof', [\App\Http\Controllers\CustomerReceiptProofController::class, 'show'])
        ->name('customer-receipts.proof')
        ->whereNumber('receipt');

    // Document PDF streaming (opens in new tab)
    Route::get('/pdf/{type}/{id}', [PdfPreviewController::class, 'stream'])
        ->name('pdf-stream')
        ->where('type', 'order-request|purchase-order|purchase-invoice|quotation|sale-order|sales-invoice|delivery-order|delivery-schedule|surat-jalan|credit-note|customer-receipt');

    // Customer Return PDF streaming
    Route::get('/pdf/customer-return/{id}', function (int $id) {
        $return = \App\Models\CustomerReturn::with([
            'invoice', 'customer', 'cabang', 'customerReturnItems.product',
            'receivedBy', 'qcInspectedBy', 'approvedBy'
        ])->findOrFail($id);

        \Illuminate\Support\Facades\Gate::authorize('view', $return);

        $pdf = \Barryvdh\DomPDF\Facade\Pdf::loadView('pdf.customer-return', [
            'return' => $return,
            'doc' => app(\App\Services\DocumentPrintBuilder::class)->customerReturn($return),
        ])->setPaper('a4', 'portrait');
        return $pdf->stream("CustomerReturn_{$return->return_number}.pdf");
    })->name('pdf-customer-return');

    // Backward-compatibility redirects for eliminated Hub pages
    Route::redirect('/admin/sales-hub', '/admin/sale-orders', 301);
    Route::redirect('/admin/purchase-hub', '/admin/purchase-orders', 301);
    Route::redirect('/admin/delivery-hub', '/admin/delivery-orders', 301);
    Route::redirect('/admin/accounting-hub', '/admin/journal-entries', 301);
    Route::redirect('/admin/inventory-hub', '/admin/inventory-stocks', 301);
    Route::redirect('/admin/master-data-hub', '/admin/products', 301);
    Route::redirect('/admin/user-roles-management-hub', '/admin/users', 301);
    Route::redirect('/admin/manufacturing-hub', '/admin', 301);
    Route::redirect('/admin/finance-sales-hub', '/admin/sales-invoices', 301);
    Route::redirect('/admin/finance-purchase-hub', '/admin/purchase-invoices', 301);
    Route::redirect('/admin/payment-hub', '/admin/customer-receipts', 301);
    Route::redirect('/admin/finance-reports', '/admin/financial-statement', 301);
    Route::redirect('/admin/asset-management-hub', '/admin/assets', 301);
    Route::redirect('/admin/warehouse-hub', '/admin/warehouse-confirmations', 301);
    Route::redirect('/admin/dashboard-hub', '/admin', 301);
});