<?php

namespace App\Http\Controllers;

use Barryvdh\DomPDF\Facade\Pdf;
use Filament\Notifications\Notification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class HelperController extends Controller
{
    public static function saveSignatureImage($base64Image)
    {
        $image_parts = explode(";base64,", $base64Image);
        if (count($image_parts) <= 1) {
            return null;
        }
        $image_type_aux = explode("image/", $image_parts[0]);
        $image_type = $image_type_aux[1] ?? 'png';
        $image_base64 = base64_decode($image_parts[1]);

        $fileName = 'signature_' . uniqid() . '.' . $image_type;
        $filePath = 'signatures/' . $fileName;

        // Simpan ke public/storage/signatures/
        Storage::disk('public')->put($filePath, $image_base64);

        return '/' . $filePath;
    }

    public static function generateRandomColors(int $count): array
    {
        $colors = [];

        for ($i = 0; $i < $count; $i++) {
            $colors[] = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
        }

        return $colors;
    }

    /**
     * Returns a mapping between resource names and the set of actions
     * that can be performed on them.  This is used by the permission
     * seeder, the audit tests and various authorization helpers.
     *
     * The format must stay backwards compatible (resource => [action1,
     * action2, …]) because the test-suite and seeder iterate over the
     * values directly.  Do not change it to include descriptions here.
     */
    public static function listPermission()
    {
        $listPermissions = [
            'user' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'role' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'permission' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'purchase order' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'response',
                'request',
            ],
            'purchase order item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'purchase receipt' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'purchase receipt item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'product' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'product category' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'asset' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'asset depreciation' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'asset disposal' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'asset transfer' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'cash bank account' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'cash bank transaction detail' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'currency' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'customer' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'driver' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'delivery order' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'request',
                'response'
            ],
            'delivery order item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'delivery order approval log' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'delivery order log' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'delivery sales order' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'manufacturing order' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'request',
                'response'
            ],
            'quality control' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'rak' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'sales order' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'request',
                'response',
            ],
            'sales order item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'supplier' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'unit of measure' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'vehicle' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'warehouse confirmation' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'warehouse' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'approve'
            ],
            'stock transfer' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'request',
                'response'
            ],
            'stock transfer item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'quotation' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'request-approve',
                'reject',
                'approve'
            ],
            'quotation item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'request-approve',
                'approve'
            ],
            'surat jalan' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'request',
                'response'
            ],
            'delivery schedule' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'update status',
                'rekap',
            ],
            'return product' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'approve',
            ],
            'return product item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'order request' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'approve',
                'reject',
                'submit',
            ],
            'order request item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'inventory stock' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'stock movement' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'cabang' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'product unit conversion' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'production' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'production plan' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'vendor payment' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'vendor payment detail' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'account payable' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'ageing schedule' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'chart of account' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'purchase order currency' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'deposit' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'deposit log' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'purchase order biaya' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'tax setting' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'bill of material' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'bill of material item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'material issue' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'account receivable' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'customer receipt' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'customer receipt item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            // T5 (Nota Kredit): draf dibuat, diterbitkan (approve) oleh peran berwenang; yang terbit final (update tidak dipakai)
            'credit note' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'approve',
            ],
            'purchase return' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'purchase return item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'customer return' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'qc',
                'approve',
            ],
            'customer return item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'invoice' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
            ],
            'invoice item' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'journal entry' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete'
            ],
            'voucher request' => [
                'view any',
                'view',
                'create',
                'update',
                'delete',
                'restore',
                'force-delete',
                'submit',
                'approve',
                'reject',
                'cancel',
            ],
        ];

        return $listPermissions;
    }

    /**
     * Generate a map of full permission names ("action resource") to an
     * Indonesian description explaining its purpose.  The descriptions are
     * generated programmatically for common CRUD/workflow actions, and the
     * method falls back to a generic template if a specific phrase is not
     * defined.  Seeders and UI components can call this helper to retrieve
     * human‑readable text.
     *
     * @return array<string,string>
     */
    public static function permissionDescriptions()
    {
        $descs = [];
        $templates = [
            'view any'    => 'Melihat daftar semua %s',
            'view'        => 'Melihat detail %s',
            'create'      => 'Membuat %s baru',
            'update'      => 'Memperbarui %s',
            'delete'      => 'Menghapus %s',
            'restore'     => 'Mengembalikan %s yang dihapus',
            'force-delete'=> 'Menghapus permanen %s',
            'update status' => 'Memperbarui status %s',
            'rekap'          => 'Membuat rekap %s',
            'request'     => 'Mengajukan permintaan untuk %s',
            'response'    => 'Menanggapi permintaan %s',
            'submit'      => 'Mengajukan %s',
            'approve'     => 'Menyetujui %s',
            'reject'      => 'Menolak %s',
            'cancel'      => 'Membatalkan %s',
            'request-approve' => 'Meminta persetujuan %s',
            'request'     => 'Meminta %s',
            'reject'      => 'Menolak %s',
            'approve'     => 'Menyetujui %s',
            'request-approve' => 'Meminta persetujuan %s',
            'submit'      => 'Mengirimkan %s',
            'approve'     => 'Menyetujui %s',
            'reject'      => 'Menolak %s',
        ];

        foreach (self::listPermission() as $resource => $actions) {
            foreach ($actions as $action) {
                $name = $action . ' ' . $resource;
                $tpl  = $templates[$action] ?? 'Izin untuk ' . $action . ' ' . $resource;
                $descs[$name] = sprintf($tpl, $resource);
            }
        }
        // manual refinements if needed (special cases)
        $descs['request sales order'] = 'Meminta persetujuan atau tindakan lebih lanjut pada sales order';
        $descs['response sales order'] = 'Memberi jawaban (terima/tolak) atas permintaan sales order';
        $descs['request-approve quotation'] = 'Meminta persetujuan pada quotation';
        $descs['approve quotation'] = 'Menyetujui quotation';
        $descs['reject quotation'] = 'Menolak quotation';
        $descs['submit voucher request'] = 'Mengirimkan permintaan voucher';
        $descs['approve voucher request'] = 'Menyetujui permintaan voucher';
        $descs['reject voucher request'] = 'Menolak permintaan voucher';
        $descs['cancel voucher request'] = 'Membatalkan permintaan voucher';
        // ...any other hand-curated descriptions here

        return $descs;
    }

    /**
     * Return Indonesian descriptions for each role defined in the system.
     *
     * @return array<string,string>
     */
    public static function roleDescriptions()
    {
        return [
            'Owner'            => 'Pengguna dengan hak penuh; biasanya pemilik perusahaan atau administrator tingkat tertinggi.',
            'Super Admin'      => 'Administrator sistem dengan hampir semua izin, kecuali beberapa operasi ekstrim.',
            'Admin'            => 'Administrator umum yang mengelola pengguna, peran, dan beberapa konfigurasi dasar.',
            'Sales Manager'    => 'Mengawasi tim penjualan dan memiliki akses ke data sales order, quotation, dan invoice.',
            'Sales'            => 'Staf penjualan yang membuat dan melihat sales order serta quotation pelanggan.',
            'Kasir'            => 'Bertanggung jawab mencatat penerimaan pembayaran pelanggan dan membuat invoice.',
            'Admin Pengiriman' => 'Admin pengiriman: membuat DO dari SO, Surat Jalan, invoice, serta mengelola kendaraan & driver.',
            'Inventory Manager'=> 'Mengelola persediaan, gudang, transfer stok, dan konfigurasi produk.',
            'Admin Inventory'  => 'Role pendukung di departemen inventaris dengan akses terbatas tetapi luas ke modul gudang.',
            'Checker'          => 'Memeriksa konfirmasi gudang, kontrol kualitas, dan stok.',
            'Finance Manager'  => 'Mengelola keuangan, akun payables/receivables, dan laporan keuangan.',
            'Admin Keuangan'   => 'Pendukung manajer keuangan dengan hak akses ke sebagian besar modul keuangan.',
            'Accounting'       => 'Bertanggung jawab atas buku besar, jurnal, dan catatan akuntansi lainnya.',
            'Purchasing'       => 'Staf pembelian yang membuat dan memantau purchase order dan penerimaan.',
            'Purchasing Manager'=> 'Mengawasi kegiatan pembelian dan dapat memproses pembayaran vendor.',
            'Warehouse Staff'  => 'Staf gudang yang mengelola pengiriman, transfer, dan stok fisik.',
            'Delivery Driver'  => 'Pengemudi yang melihat dan memperbarui informasi delivery order serta surat jalan.',
            'Customer Service' => 'Layanan pelanggan yang menangani customer, quotation, dan sales order.',
            'Auditor'          => 'Mempunyai hak baca (view any) di seluruh modul untuk keperluan audit.',
            'IT Support'       => 'Tim teknis yang mengelola akun, izin, dan konfigurasi sistem.',
        ];
    }

    public static function getPermissionOwner()
    {
        return [
            'purchase order',
            'purchase order item',
        ];
    }

    public static function getPermissionGudang()
    {
        return [
            'warehouse',
            'quality control',
            'purchase receipt'
        ];
    }

    public static function cetakPO($purchaseOrder)
    {
        $pdf = Pdf::loadView('pdf.purchase-order', [
            'purchaseOrder' => $purchaseOrder
        ]);
        return $pdf->stream('PO-' . $purchaseOrder->po_number . '.pdf');
    }

    public static function parseIndonesianMoney($formattedValue)
    {
        // Use centralized MoneyHelper parsing to ensure consistent behavior across the app.
        // This avoids duplicated, error-prone parsing logic and keeps tests stable.
        if (!$formattedValue) {
            return 0.0;
        }

        // If it's already numeric, return as float
        if (is_int($formattedValue) || is_float($formattedValue) || (is_string($formattedValue) && is_numeric($formattedValue))) {
            return (float) $formattedValue;
        }

        return \App\Helpers\MoneyHelper::safeParse($formattedValue);
    
    }

    public static function hitungSubtotal($quantity, $unit_price, $discount, $tax, $taxType = null)
    {
        // Normalize only human-formatted money strings. Raw DB decimals like
        // "10000.0000000000" must stay numeric after high-precision migrations.
        if (is_string($unit_price) && preg_match('/[.,]/', $unit_price)) {
            $parsed = \App\Helpers\MoneyHelper::parseHighPrecision($unit_price);
            $unit_price = (float) $parsed;
        }
        // --- INPUT GUARDS ---
        $quantity  = max(0.0, (float) $quantity);
        $unit_price = max(0.0, (float) $unit_price);
        $discount  = max(0.0, min(100.0, (float) $discount));  // clamp 0-100%
        $tax       = max(0.0, min(100.0, (float) $tax));        // clamp 0-100%
        // Default to 'Inklusif' when taxType is null/empty — maintained for backward compatibility.
        // NOTE: TaxService::normalizeType(null) defaults to 'Eksklusif'. If you call TaxService
        // directly (not through this helper), ensure you pass an explicit type to avoid discrepancies.
        $taxType   = (is_string($taxType) && trim($taxType) !== '') ? $taxType : 'Inklusif';

        // Satu-satunya perhitungan baris penjualan: LineAmounts (kebijakan pembulatan D6, config sales.line_rounding_decimals).
        // Eksklusif: DPP + PPN; Inklusif / Non Pajak: nilai setelah diskon (PPN sudah termasuk / tidak ada).
        return \App\Support\LineAmounts::calculate($quantity, $unit_price, $discount, $tax, $taxType)['total'];
    }

    public static function hitungTaxNominal($quantity, $unit_price, $discount, $tax, $taxType = null)
    {
        if (is_string($unit_price) && preg_match('/[.,]/', $unit_price)) {
            $unit_price = (float) \App\Helpers\MoneyHelper::parseHighPrecision($unit_price);
        }

        $quantity  = max(0.0, (float) $quantity);
        $unit_price = max(0.0, (float) $unit_price);
        $discount  = max(0.0, min(100.0, (float) $discount));
        $tax       = max(0.0, min(100.0, (float) $tax));
        $taxType   = (is_string($taxType) && trim($taxType) !== '') ? $taxType : 'Inklusif';

        $baseAmount = $quantity * $unit_price * (1 - ($discount / 100));

        $normalizedTaxType = strtolower(trim((string) $taxType));
        if (in_array($normalizedTaxType, ['none', 'non pajak', 'non-pajak', 'nonpajak'], true)) {
            return 0.0;
        }

        return round($baseAmount * ($tax / 100.0), 2);
    }

    public static function sendNotification($isSuccess = false, $title = "", $message = "")
    {
        if ($isSuccess) {
            return Notification::make()
                ->body($message)
                ->title($title)
                ->success()
                ->send();
        } else {
            return Notification::make()
                ->body($message)
                ->title($title)
                ->danger()
                ->send();
        }
    }

    public static function sendNotificationToUser() {}

    public static function terbilang($number)
    {
        $number = abs((int) round($number)); // Ensure integer to fix deprecated warnings
        $words = [
            "",
            "satu",
            "dua",
            "tiga",
            "empat",
            "lima",
            "enam",
            "tujuh",
            "delapan",
            "sembilan",
            "sepuluh",
            "sebelas"
        ];

        $temp = "";
        if ($number < 12) {
            $temp = " " . $words[$number];
        } else if ($number < 20) {
            $temp = static::terbilang($number - 10) . " belas ";
        } else if ($number < 100) {
            $temp = static::terbilang((int) ($number / 10)) . " puluh " . static::terbilang($number % 10);
        } else if ($number < 200) {
            $temp = " seratus " . static::terbilang($number - 100);
        } else if ($number < 1000) {
            $temp = static::terbilang((int) ($number / 100)) . " ratus " . static::terbilang($number % 100);
        } else if ($number < 2000) {
            $temp = " seribu" . static::terbilang($number - 1000);
        } else if ($number < 1000000) {
            $temp = static::terbilang((int) ($number / 1000)) . " ribu " . static::terbilang($number % 1000);
        } else if ($number < 1000000000) {
            $temp = static::terbilang((int) ($number / 1000000)) . " juta " . static::terbilang($number % 1000000);
        } else if ($number < 1000000000000) {
            $temp = static::terbilang((int) ($number / 1000000000)) . " milyar " . static::terbilang((int) fmod($number, 1000000000));
        } else if ($number < 1000000000000000) {
            $temp = static::terbilang((int) ($number / 1000000000000)) . " triliun " . static::terbilang((int) fmod($number, 1000000000000));
        }

        return trim($temp);
    }

    public static function setLog($message, $model)
    {
        activity()
            ->causedBy(Auth::user())
            ->performedOn($model)
            ->log($message);
    }

    /**
     * Format amount dengan pemisah ribuan titik (.) dan desimal koma (,)
     * Format Indonesia: 1.234.567,89
     *
     * @param float|int|string $amount
     * @param int $decimals
     * @return string
     */
    public static function formatAmount($amount, int $decimals = 2): string
    {
        return number_format((float) $amount, $decimals, ',', '.');
    }

    /**
     * Format amount tanpa desimal
     * Format: 1.234.567
     *
     * @param float|int|string $amount
     * @return string
     */
    public static function formatAmountNoDecimal($amount): string
    {
        return number_format((float) $amount, 0, ',', '.');
    }

    /**
     * Format amount dengan prefix Rp
     * Format: Rp 1.234.567,89
     *
     * @param float|int|string $amount
     * @param int $decimals
     * @return string
     */
    public static function formatCurrency($amount, int $decimals = 2): string
    {
        return 'Rp ' . self::formatAmount($amount, $decimals);
    }

    /**
     * Format currency tanpa desimal
     * Format: Rp 1.234.567
     *
     * @param float|int|string $amount
     * @return string
     */
    public static function formatCurrencyNoDecimal($amount): string
    {
        return 'Rp ' . self::formatAmountNoDecimal($amount);
    }

    /**
     * Generate request number for Order Request
     * Format: OR-YYYYMMDD-XXXX
     *
     * @return string
     */
    public static function generateUniqueCode(string $table, string $column, string $prefix, int $digits = 4): string
    {
        return \App\Services\SequentialNumberGenerator::generate($table, $column, $prefix, $digits, null);
    }

    public static function generateRequestNumber(): string
    {
        return \App\Services\SequentialNumberGenerator::generate('order_requests', 'request_number', 'OR-', 4, 'Ymd');
    }

    /**
     * Generate PO number for Purchase Order
     * Format: PO-YYYYMMDD-XXXX
     *
     * @return string
     */
    public static function generatePoNumber(): string
    {
        $date = now()->format('Ymd');
        $prefix = 'PO-' . $date . '-';

        // Find the latest PO number for today including soft deleted
        $latest = \App\Models\PurchaseOrder::withTrashed()
            ->where('po_number', 'like', $prefix . '%')
            ->orderBy('po_number', 'desc')
            ->first();

        if ($latest) {
            $lastNumber = (int) substr($latest->po_number, -4);
            $nextNumber = $lastNumber + 1;
        } else {
            $nextNumber = 1;
        }

        $candidate = $prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
        while (\App\Models\PurchaseOrder::withTrashed()->where('po_number', $candidate)->exists()) {
            $nextNumber++;
            $candidate = $prefix . str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
        }

        return $candidate;
    }
}
