<?php

namespace App\Models;

use App\Models\Scopes\CabangScope;
use App\Traits\LogsGlobalActivity;
use App\Traits\CascadesJournalEntries;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class DeliveryOrder extends Model
{
    use SoftDeletes, HasFactory,LogsGlobalActivity, CascadesJournalEntries;

    /**
     * Status DO yang kuantitasnya dihitung SUDAH TERKIRIM ke SO (barang sudah keluar gudang).
     */
    public const DELIVERED_STATUSES = ['sent', 'received', 'completed'];

    /**
     * Status DO yang kuantitasnya DILEPAS kembali ke SO (DO ditutup sebelum dikirim).
     * Semua status lain (draft s/d approved, partial, reject, delivery_failed, dst.)
     * masih "terikat" ke SO karena DO dapat diperbaiki / dijadwalkan ulang.
     */
    public const RELEASED_STATUSES = ['closed'];

    public const STATUS_LABELS = [
        // Label tampil mengikuti Spesifikasi UI/UX 7.2
        'draft' => 'Draft',
        'request_stock' => 'Menunggu Konfirmasi Stok',
        'request_approve' => 'Menunggu konfirmasi gudang',
        'approved' => 'Siap dicek & dikirim',
        'confirmed' => 'Dikonfirmasi',
        'partial' => 'Sebagian',
        'sent' => 'Dalam pengiriman',
        'received' => 'Diterima customer',
        'completed' => 'Selesai',
        'supplier' => 'Dari Supplier',
        'request_close' => 'Minta Ditutup',
        'closed' => 'Ditutup',
        'reject' => 'Ditolak',
        'delivery_failed' => 'Gagal kirim',
    ];

    public const STATUS_COLORS = [
        'draft' => 'gray',
        'request_stock' => 'warning',
        'request_approve' => 'gray',
        'approved' => 'info',
        'confirmed' => 'info',
        'partial' => 'warning',
        'sent' => 'primary',
        'received' => 'info',
        'completed' => 'success',
        'supplier' => 'warning',
        'request_close' => 'warning',
        'closed' => 'danger',
        'reject' => 'danger',
        'delivery_failed' => 'danger',
    ];

    /** Label "Siap Kirim" (D4) untuk `approved` saat alur ketat aktif: DO sudah disetujui gudang tetapi barang belum berangkat. */
    public const STRICT_STATUS_LABELS = [
        'approved' => 'Siap Kirim',
        'confirmed' => 'Siap Kirim',
        'sent' => 'Dikirim',
    ];

    public static function statusLabel(?string $status): string
    {
        if (config('sales.stock.strict_dispatch', false) && isset(self::STRICT_STATUS_LABELS[$status ?? ''])) {
            return self::STRICT_STATUS_LABELS[$status];
        }

        return self::STATUS_LABELS[$status ?? ''] ?? ($status ? ucfirst(str_replace('_', ' ', $status)) : '-');
    }

    public static function statusColor(?string $status): string
    {
        return self::STATUS_COLORS[$status ?? ''] ?? 'gray';
    }

    protected $table = 'delivery_orders';

    protected $casts = [
        'received_at' => 'datetime',
        'returned_at' => 'datetime',
    ];

    protected $fillable = [
        'do_number',
        'delivery_date',
        'driver_id',
        'vehicle_id',
        'warehouse_id',
        'status', // 'draft', 'sent', 'received', 'supplier', 'completed', 'request_approve', 'approved', 'request_close', 'closed', 'reject'
        'notes',
        'additional_cost',
        'additional_cost_description',
        'created_by',
        'cabang_id',
        'received_at',
        'received_by_name',
        'returned_at',
        'replacement_for_delivery_order_id',
    ];

    /** DO asal yang digantikan oleh DO ini (DO pengganti …C akibat retur). */
    public function replacementFor()
    {
        return $this->belongsTo(self::class, 'replacement_for_delivery_order_id');
    }

    /** DO pengganti (…C) yang dibuat dari DO ini setelah retur. */
    public function replacements()
    {
        return $this->hasMany(self::class, 'replacement_for_delivery_order_id');
    }

    public function driver()
    {
        return $this->belongsTo(Driver::class, 'driver_id')->withDefault();
    }

    public function vehicle()
    {
        return $this->belongsTo(Vehicle::class, 'vehicle_id')->withDefault();
    }

    public function deliveryOrderItem()
    {
        return $this->hasMany(DeliveryOrderItem::class, 'delivery_order_id');
    }

    public function salesOrders()
    {
        return $this->belongsToMany(SaleOrder::class, 'delivery_sales_orders', 'delivery_order_id', 'sales_order_id');
    }

    public function suratJalan()
    {
        return $this->belongsToMany(SuratJalan::class, 'surat_jalan_delivery_orders', 'delivery_order_id', 'surat_jalan_id')->withTimestamps();
    }

    /**
     * Memeriksa apakah Delivery Order ini sudah memiliki Surat Jalan (SJ) yang diterbitkan (status Terbit / STATUS_ISSUED).
     */
    public function hasIssuedSuratJalan(): bool
    {
        return $this->suratJalan()
            ->where('surat_jalans.status', SuratJalan::STATUS_ISSUED)
            ->exists();
    }

    public function deliverySchedules()
    {
        return $this->belongsToMany(DeliverySchedule::class, 'delivery_schedule_delivery_orders', 'delivery_order_id', 'delivery_schedule_id')->withTimestamps();
    }

    public function deliverySalesOrder()
    {
        return $this->hasMany(DeliverySalesOrder::class, 'delivery_order_id');
    }

    public function log()
    {
        return $this->hasMany(DeliveryOrderLog::class, 'delivery_order_id');
    }

    public function returnProduct(){
        return $this->morphOne(ReturnProduct::class, 'from_model')->withDefault();
    }

    public function stockMovement()
    {
        return $this->morphOne(StockMovement::class, 'from_model')->withDefault();
    }

    public function approvalLogs()
    {
        return $this->hasMany(DeliveryOrderApprovalLog::class, 'delivery_order_id');
    }

    /**
     * Nilai DO = total invoice yang akan terbit dari DO ini (barang + PPN + biaya tambahan), via satu sumber:
     * DeliveryOrderValuation (LineAmounts). Sebelumnya `harga − diskon + pajak` mencampur persen dengan rupiah.
     */
    public function getTotalAttribute()
    {
        return $this->valueBreakdown()['total'];
    }

    /** Rincian nilai DO: baris, DPP, PPN, total barang, biaya tambahan, total. */
    public function valueBreakdown(): array
    {
        return app(\App\Services\DeliveryOrderValuation::class)->forDeliveryOrder($this);
    }

    protected static function booted()
    {
        static::addGlobalScope(new CabangScope);

        static::deleting(function ($deliveryOrder) {
            if (in_array($deliveryOrder->status, ['sent', 'completed', 'delivered', 'delivering'], true)) {
                throw new \Exception("Surat Jalan / Delivery Order dengan status '{$deliveryOrder->status}' tidak dapat dihapus karena barang sudah keluar gudang dan mempengaruhi stok fisik serta akuntansi.");
            }

            $hasInvoices = \App\Models\Invoice::where(function ($q) use ($deliveryOrder) {
                $q->where('from_model_type', self::class)
                  ->where('from_model_id', $deliveryOrder->id);
            })->orWhereJsonContains('delivery_orders', (string) $deliveryOrder->id)
              ->orWhereJsonContains('delivery_orders', (int) $deliveryOrder->id)
              ->exists();

            if ($hasInvoices) {
                throw new \Exception("Delivery Order tidak dapat dihapus karena sudah memiliki faktur penjualan (Invoice) terkait.");
            }

            // Tahap 3: Kembalikan stok fisik bila DO dihapus
            app(\App\Services\DeliveryShipments::class)->reverse($deliveryOrder, "DO {$deliveryOrder->do_number} dihapus");

            if ($deliveryOrder->isForceDeleting()) {
                $deliveryOrder->deliveryOrderItem()->forceDelete();
            } else {
                $deliveryOrder->deliveryOrderItem()->delete();
            }
        });

        static::restoring(function ($deliveryOrder) {
            $deliveryOrder->deliveryOrderItem()->withTrashed()->restore();
        });

        // T2.3 (flag stock.strict_dispatch): perubahan status di luar matriks / stok fisik kurang ditolak di model,
        // apa pun pintunya (aksi UI, jadwal, kode lama yang memanggil ->update(['status' => ...])).
        static::updating(function ($deliveryOrder) {
            \App\Services\DeliveryOrderTransitions::guardModelChange($deliveryOrder);
        });
    }

    public function stockReservations()
    {
        return $this->hasMany(StockReservation::class, 'delivery_order_id');
    }

    public function journalEntries()
    {
        return $this->morphMany(JournalEntry::class, 'source');
    }

    public function warehouse()
    {
        return $this->belongsTo(Warehouse::class, 'warehouse_id')->withDefault();
    }

    public function cabang()
    {
        return $this->belongsTo(Cabang::class, 'cabang_id')->withDefault();
    }

    // WC records linked to this DO via polymorphic relationship (DO-centric flow)
    public function warehouseConfirmations()
    {
        return $this->morphMany(WarehouseConfirmation::class, 'confirmable');
    }

    /**
     * Update DO status based on all linked WC outcomes.
     * - ALL confirmed  → approved (auto)
     * - ANY rejected   → reject (auto)
     * - still pending  → stays request_stock
     */
    public function updateStatusFromWarehouseConfirmations(): void
    {
        $wcs = $this->warehouseConfirmations()->get();
        if ($wcs->isEmpty()) {
            if ($this->status !== 'request_stock') {
                $this->moveStatusFromWarehouseConfirmations('request_stock');
            }

            return;
        }

        $statuses = $wcs->map(fn ($wc) => strtolower((string) $wc->status))->values();

        $allConfirmed = $statuses->every(fn ($status) => $status === 'confirmed');
        $anyRejected  = $statuses->contains('rejected');

        if ($allConfirmed) {
            $this->moveStatusFromWarehouseConfirmations('approved');
        } elseif ($anyRejected) {
            $this->moveStatusFromWarehouseConfirmations('reject');
        }
        // else: one or more WCs still pending → stay at request_stock
    }

    /**
     * Alur ketat (T2.3): konfirmasi gudang hanya menggerakkan DO bila transisinya sah menurut matriks. DO yang sudah Dikirim/Selesai
     * tidak boleh "mundur" ke Siap Kirim hanya karena WC dikonfirmasi belakangan. Alur lama: langsung ubah (perilaku semula).
     */
    private function moveStatusFromWarehouseConfirmations(string $target): void
    {
        if (! \App\Services\DeliveryOrderTransitions::enabled()) {
            $this->update(['status' => $target]);

            return;
        }

        if ($this->status === $target || ! \App\Services\DeliveryOrderTransitions::allows($this->status, $target)) {
            return;
        }

        app(\App\Services\DeliveryOrderTransitions::class)->to($this, $target, ['source' => 'warehouse_confirmation']);
    }
}
