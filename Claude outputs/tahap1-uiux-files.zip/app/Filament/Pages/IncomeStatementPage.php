<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Form;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\Section;
use Filament\Actions\Action;
use App\Services\IncomeStatementService;
use App\Models\Cabang;
use App\Models\IncomeStatementItem;
use Filament\Notifications\Notification;
use App\Exports\IncomeStatementExport;
use App\Exports\IncomeStatementPdfExport;
use Maatwebsite\Excel\Facades\Excel;

class IncomeStatementPage extends Page implements HasForms, HasTable
{
    use \App\Filament\Concerns\HasMenuAccess;

    use InteractsWithForms, InteractsWithTable;

    protected static ?string $navigationIcon = 'heroicon-o-chart-bar';

    protected static string $view = 'filament.pages.income-statement-page';

    protected static ?string $navigationLabel = 'Laporan Laba Rugi (Legacy)';

    protected static ?string $navigationGroup = 'Laporan Keuangan';

    protected static ?int $navigationSort = 2;

    public static function shouldRegisterNavigation(): bool
    {
        return false;
    }

    public ?string $start_date = null;
    public ?string $end_date = null;
    public ?int $cabang_id = null;
    public bool $show_comparison = false;
    public ?string $comparison_start_date = null;
    public ?string $comparison_end_date = null;

    // Preview gate – show filters first, data only after Preview is clicked
    public bool $showPreview = false;

    // Display options
    public bool $show_only_totals = false;
    public bool $show_parent_accounts = true;
    public bool $show_child_accounts = true;
    public bool $show_zero_balance = false;

    public function mount(): void
    {
        // Default to current year for better data visibility
        $this->showPreview = filter_var(request('preview', false), FILTER_VALIDATE_BOOL);

        $this->form->fill([
            'start_date' => request()->query('start', now()->startOfYear()->format('Y-m-d')),
            'end_date' => request()->query('end', now()->endOfYear()->format('Y-m-d')),
            'cabang_id' => request()->query('cabang_id'),
            'show_comparison' => filter_var(request('show_comparison', false), FILTER_VALIDATE_BOOL),
            'comparison_start_date' => request()->query('comparison_start_date', now()->subYear()->startOfYear()->format('Y-m-d')),
            'comparison_end_date' => request()->query('comparison_end_date', now()->subYear()->endOfYear()->format('Y-m-d')),
            'show_only_totals' => filter_var(request('show_only_totals', false), FILTER_VALIDATE_BOOL),
            'show_parent_accounts' => filter_var(request('show_parent_accounts', true), FILTER_VALIDATE_BOOL),
            'show_child_accounts' => filter_var(request('show_child_accounts', true), FILTER_VALIDATE_BOOL),
            'show_zero_balance' => filter_var(request('show_zero_balance', false), FILTER_VALIDATE_BOOL),
        ]);
    }

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Filter Laporan')
                    ->schema([
                        DatePicker::make('start_date')
                            ->label('Tanggal Mulai')
                            ->required(),
                        DatePicker::make('end_date')
                            ->label('Tanggal Akhir')
                            ->required(),
                        Select::make('cabang_id')
                            ->label('Cabang')
                            ->options(function () {
                                return Cabang::all()->mapWithKeys(function ($cabang) {
                                    return [$cabang->id => "({$cabang->kode}) {$cabang->nama}"];
                                });
                            })
                            ->searchable()
                            ->preload()
                            ->getSearchResultsUsing(function (string $search) {
                                return Cabang::where('nama', 'like', "%{$search}%")
                                    ->orWhere('kode', 'like', "%{$search}%")
                                    ->limit(50)
                                    ->get()
                                    ->mapWithKeys(function ($cabang) {
                                        return [$cabang->id => "({$cabang->kode}) {$cabang->nama}"];
                                    });
                            }),
                        Toggle::make('show_comparison')
                            ->label('Tampilkan Perbandingan')
                            ->live(),
                        DatePicker::make('comparison_start_date')
                            ->label('Tanggal Mulai Perbandingan')
                            ->visible(fn ($get) => $get('show_comparison')),
                        DatePicker::make('comparison_end_date')
                            ->label('Tanggal Akhir Perbandingan')
                            ->visible(fn ($get) => $get('show_comparison')),
                    ])->columns(2),

                Section::make('Opsi Tampilan')
                    ->schema([
                        Toggle::make('show_only_totals')
                            ->label('Tampilkan Hanya Total'),
                        Toggle::make('show_parent_accounts')
                            ->label('Tampilkan Akun Induk'),
                        Toggle::make('show_child_accounts')
                            ->label('Tampilkan Akun Anak'),
                        Toggle::make('show_zero_balance')
                            ->label('Tampilkan Saldo Nol'),
                    ])->columns(2),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->defaultSort('id', 'desc')
            ->query(IncomeStatementItem::query())
            ->columns([
                TextColumn::make('code')
                    ->label('Kode')
                    ->sortable(),
                TextColumn::make('description')
                    ->label('Deskripsi')
                    ->wrap()
                    ->sortable(),
                TextColumn::make('amount')
                    ->label('Saldo')
                    ->formatStateUsing(function ($state) {
                        $amount = (float) $state;
                        if ($amount < 0) {
                            $formatted = '(' . number_format(abs($amount), 0, ',', '.') . ')';
                            return new \Illuminate\Support\HtmlString('<span style="color: #D9534F; font-weight: bold;">' . $formatted . '</span>');
                        }
                        return number_format($amount, 0, ',', '.');
                    })
                    ->sortable()
                    ->alignRight(),
            ])
            ->recordClasses(function ($record) {
                // Apply different styling based on row_type
                return match($record->row_type) {
                    'section_total' => 'bg-red-100 font-bold',
                    'computed' => 'bg-green-100 font-bold',
                    'subtotal' => 'bg-yellow-50 font-bold',
                    'child' => 'text-gray-600',
                    'parent' => 'font-semibold',
                    default => '',
                };
            })
            ->emptyStateHeading('Klik "Preview" untuk menampilkan laporan')
            ->emptyStateDescription('Pilih rentang tanggal lalu klik tombol Preview di atas.')
            ->emptyStateIcon('heroicon-o-document-chart-bar')
            ->modifyQueryUsing(fn ($query) => $this->showPreview ? $query : $query->whereRaw('1=0'))
            ->paginated(false);
    }

    protected function getHeaderActions(): array
    {
        return [
            \Filament\Actions\Action::make('preview')
                ->label('Preview')
                ->icon('heroicon-o-eye')
                ->color('primary')
                ->action(fn () => $this->generateReport()),

            \Filament\Actions\Action::make('reset')
                ->label('Reset')
                ->icon('heroicon-o-x-circle')
                ->color('gray')
                ->visible(fn () => $this->showPreview)
                ->action(fn () => $this->resetReport()),

            \Filament\Actions\Action::make('export_excel')
                ->label('Export Excel')
                ->icon('heroicon-o-arrow-down-tray')
                ->color('success')
                ->visible(fn () => $this->showPreview)
                ->action(function () {
                    $data = $this->form->getState();
                    return Excel::download(
                        new IncomeStatementExport(
                            $data['start_date'],
                            $data['end_date'],
                            $data['cabang_id'] ?? null
                        ),
                        'laporan-laba-rugi-' . now()->format('Y-m-d') . '.xlsx'
                    );
                }),

            \Filament\Actions\Action::make('export_pdf')
                ->label('Export PDF')
                ->icon('heroicon-o-document')
                ->color('danger')
                ->visible(fn () => $this->showPreview)
                ->action(function () {
                    $data = $this->form->getState();
                    $pdfExport = new IncomeStatementPdfExport(
                        $data['start_date'],
                        $data['end_date'],
                        $data['cabang_id'] ?? null
                    );
                    $pdf = $pdfExport->generatePdf();
                    return response()->streamDownload(function () use ($pdf) {
                        echo $pdf->output();
                    }, 'laporan-laba-rugi-' . now()->format('Y-m-d') . '.pdf');
                }),
        ];
    }

    public function resetReport(): void
    {
        $this->redirect(static::getUrl());
    }

    public function generateReport(): void
    {
        $data = $this->form->getState();

        // Validate dates
        if (!$data['start_date'] || !$data['end_date']) {
            Notification::make()
                ->title('Error')
                ->danger()
                ->body('Tanggal mulai dan akhir harus diisi.')
                ->send();
            return;
        }

        if ($data['start_date'] > $data['end_date']) {
            Notification::make()
                ->title('Error')
                ->danger()
                ->body('Tanggal mulai tidak boleh lebih besar dari tanggal akhir.')
                ->send();
            return;
        }

        // Clear existing data and populate with new data
        IncomeStatementItem::truncate();

        // Use grouped data (by parent COA) so we can show classification and totals
        $groupedData = app(IncomeStatementService::class)->getGroupedByParent([
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'cabang_id' => $data['cabang_id'] ?? null,
        ]);

        $flatData = [];

        // Local helper to push a row with code/description/amount and row_type
        $pushRow = function ($code, $description, $amount, $rowType = null) use (&$flatData) {
            $flatData[] = [
                'code' => $code,
                'description' => $description,
                'amount' => $amount,
                'row_type' => $rowType,
            ];
        };

        // Process a section that uses grouped data
        $processSection = function ($sectionGrouped, $sectionLabel) use (&$pushRow) {
            // $sectionGrouped is an array with keys 'grouped' => Collection, 'total' => float
            if (!isset($sectionGrouped['grouped'])) {
                return;
            }

            $groups = $sectionGrouped['grouped'];
            $sectionTotal = $sectionGrouped['total'] ?? 0;

            foreach ($groups as $group) {
                $parent = $group['account'] ?? null;
                $children = $group['children'] ?? collect();

                // Parent row
                if ($this->show_parent_accounts && $parent) {
                    $pushRow($parent['code'] ?? '', $parent['name'] ?? '', $parent['balance'] ?? 0, 'parent');
                }

                // Children rows
                if ($this->show_child_accounts && $children instanceof \Illuminate\Support\Collection) {
                    foreach ($children as $child) {
                        $pushRow($child['code'] ?? '', $child['name'] ?? '', $child['balance'] ?? 0, 'child');
                    }
                }

                // No subtotal per parent - balance already includes children
            }

            // Section total row
            $pushRow('', 'Total ' . $sectionLabel, $sectionTotal, 'section_total');
        };

        // Map sections and labels
        $sections = [
            'sales_revenue' => ['data' => $groupedData['sales_revenue'] ?? null, 'label' => 'Pendapatan'],
            'cogs' => ['data' => $groupedData['cogs'] ?? null, 'label' => 'HPP'],
            'operating_expenses' => ['data' => $groupedData['operating_expenses'] ?? null, 'label' => 'Biaya Operasional'],
            'other_income' => ['data' => $groupedData['other_income'] ?? null, 'label' => 'Pendapatan Lain'],
            'other_expense' => ['data' => $groupedData['other_expense'] ?? null, 'label' => 'Biaya Lain'],
            'tax_expense' => ['data' => $groupedData['tax_expense'] ?? null, 'label' => 'Pajak'],
        ];

        foreach ($sections as $key => $section) {
            if ($section['data']) {
                $processSection($section['data'], $section['label']);

                // Insert computed rows in the right positions
                if ($key === 'cogs') {
                    // After COGS, add Gross Profit
                    $gross = $groupedData['gross_profit'] ?? 0;
                    $pushRow('', 'LABA KOTOR (Gross Profit)', $gross, 'computed');
                }

                if ($key === 'operating_expenses') {
                    // After operating expenses, add Operating Profit
                    $operatingProfit = $groupedData['operating_profit'] ?? 0;
                    $pushRow('', 'LABA OPERASIONAL (Operating Profit)', $operatingProfit, 'computed');
                }

                if ($key === 'tax_expense') {
                    // After tax, add Net Profit
                    $net = $groupedData['net_profit'] ?? 0;
                    $pushRow('', 'LABA BERSIH (Net Profit)', $net, 'computed');
                }
            }
        }

        // Save to database
        foreach ($flatData as $item) {
            IncomeStatementItem::create([
                'account_name' => $item['description'] ?? $item['code'] ?? null,
                'debit' => 0,
                'credit' => 0,
                'balance' => $item['amount'] ?? 0,
                'code' => $item['code'] ?? null,
                'description' => $item['description'] ?? null,
                'amount' => $item['amount'] ?? 0,
                'row_type' => $item['row_type'] ?? null,
            ]);
        }

        // Refresh table data
        $this->dispatch('open-report-preview', url: $this->getPreviewUrl());
    }

    public function getPreviewUrl(): string
    {
        return static::getUrl() . '?' . http_build_query(array_filter([
            'preview' => 1,
            'start' => $this->start_date,
            'end' => $this->end_date,
            'cabang_id' => $this->cabang_id,
            'show_comparison' => $this->show_comparison ? 1 : 0,
            'comparison_start_date' => $this->comparison_start_date,
            'comparison_end_date' => $this->comparison_end_date,
            'show_only_totals' => $this->show_only_totals ? 1 : 0,
            'show_parent_accounts' => $this->show_parent_accounts ? 1 : 0,
            'show_child_accounts' => $this->show_child_accounts ? 1 : 0,
            'show_zero_balance' => $this->show_zero_balance ? 1 : 0,
        ], fn ($value) => $value !== null && $value !== '' && $value !== []));
    }

    public function getIncomeStatementData(): array
    {
        $data = $this->form->getState();

        return app(IncomeStatementService::class)->generate([
            'start_date' => $data['start_date'] ?? now()->startOfMonth()->format('Y-m-d'),
            'end_date' => $data['end_date'] ?? now()->endOfMonth()->format('Y-m-d'),
            'cabang_id' => $data['cabang_id'] ?? null,
        ]);
    }


    public function getTitle(): string
    {
        return 'Laporan Laba Rugi (Income Statement)';
    }

    public function getHeading(): string
    {
        return 'Laporan Laba Rugi';
    }
}
