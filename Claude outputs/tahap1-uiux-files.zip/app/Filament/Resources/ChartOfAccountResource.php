<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ChartOfAccountResource\Pages;
use App\Filament\Resources\ChartOfAccountResource\Pages\ViewChartOfAccount;
use App\Filament\Resources\ChartOfAccountResource\RelationManagers\JournalEntryRelationManager;
use App\Models\ChartOfAccount;
use App\Services\ChartOfAccountService;
use Filament\Forms\Components\Actions\Action;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\DeleteBulkAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Actions\Action as TableAction;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Tables\Enums\ActionsPosition;
use Filament\Tables\Filters\SelectFilter;

class ChartOfAccountResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = ChartOfAccount::class;

    protected static bool $shouldRegisterNavigation = true;

    protected static ?string $navigationIcon = 'heroicon-o-calculator';

    protected static ?string $navigationGroup = 'DATA MASTER';

    protected static ?string $navigationLabel = 'Akun & Pajak';

    protected static ?string $modelLabel = 'Akun & Pajak';

    protected static ?string $pluralModelLabel = 'Akun & Pajak';

    protected static ?int $navigationSort = 7;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('code')
                    ->label('Kode')
                    ->required()
                    ->reactive()
                    ->suffixAction(Action::make('generateCode')
                        ->icon('heroicon-m-arrow-path') // ikon reload
                        ->tooltip('Generate Code')
                        ->action(function ($set, $get, $state) {
                            $chartOfAccountService = app(ChartOfAccountService::class);
                            $set('code', $chartOfAccountService->generateCode());
                        }))
                    ->validationMessages([
                        'required' => 'Kode akun tidak boleh kosong',
                        'max' => 'Kode akun terlalu panjang'
                    ])
                    ->maxLength(255),
                TextInput::make('name')
                    ->label('Name')
                    ->required()
                    ->validationMessages([
                        'required' => 'Nama akun tidak boleh kosong',
                        'max' => 'Nama akun terlalu panjang'
                    ])
                    ->maxLength(255),
                Select::make('type')
                    ->label('Tipe')
                    ->options(function () {
                        return [
                            'Asset' => 'Asset',
                            'Liability' => 'Liability',
                            'Equity' => 'Equity',
                            'Revenue' => 'Revenue',
                            'Expense' => 'Expense',
                            'Contra Asset' => 'Contra Asset',
                        ];
                    })
                    ->validationMessages([
                        'required' => 'Tipe akun harus dipilih'
                    ])
                    ->required(),
                Select::make('parent_id')
                    ->label('Induk Akun')
                    ->preload()
                    ->searchable()
                    ->options(function () {
                        return \App\Models\ChartOfAccount::query()
                            ->whereNull('deleted_at')
                            ->get()
                            ->mapWithKeys(function ($coa) {
                                return [$coa->id => $coa->code . ' - ' . $coa->name];
                            })
                            ->toArray();
                    })
                    ->nullable(),
                Toggle::make('is_active')
                    ->required()
                    ->default(true),
                Textarea::make('description')
                    ->label('Description'),
                TextInput::make('opening_balance')
                    ->label('Saldo Awal')
                    ->default(0)
                    ->indonesianMoney()
                    ->validationMessages([
                        'numeric' => 'Saldo awal harus berupa angka',
                        'max' => 'Saldo awal terlalu panjang'
                    ])
                    ->maxLength(255),
                TextInput::make('debit')
                    ->label('Debit')
                    ->default(0)
                    ->indonesianMoney()
                    ->validationMessages([
                        'numeric' => 'Debit harus berupa angka',
                        'max' => 'Debit terlalu panjang'
                    ])
                    ->maxLength(255),
                TextInput::make('credit')
                    ->label('Kredit')
                    ->default(0)
                    ->indonesianMoney()
                    ->validationMessages([
                        'max' => 'Kredit terlalu panjang'
                    ])
                    ->maxLength(255),
                TextInput::make('ending_balance')
                    ->label('Saldo Akhir')
                    ->default(0)
                    ->indonesianMoney()
                    ->disabled()
                    ->dehydrated(false)
                    ->helperText('Otomatis dihitung berdasarkan jenis akun'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                TextColumn::make('code')
                    ->searchable(),
                TextColumn::make('name')
                    ->searchable(),
                TextColumn::make('type')
                    ->label('Tipe')
                    ->badge(),
                TextColumn::make('coaParent.code')
                        ->label('Induk Akun')
                        ->searchable()
                        ->formatStateUsing(function ($state, $record) {
                            if ($record->coaParent) {
                                return $record->coaParent->code . ' - ' . $record->coaParent->name;
                            }
                            return null;
                        }),
                IconColumn::make('is_active')
                    ->label('Aktif')
                    ->boolean(),
                TextColumn::make('description')
                    ->label('Deskripsi')
                    ->searchable(),
                TextColumn::make('opening_balance')
                    ->label('Saldo Awal')
                    ->rupiah()
                    ->sortable(),
                TextColumn::make('debit')
                    ->label('Debit')
                    ->rupiah()
                    ->sortable(),
                TextColumn::make('credit')
                    ->label('Kredit')
                    ->rupiah()
                    ->sortable(),
                TextColumn::make('ending_balance')
                    ->label('Saldo Akhir')
                    ->rupiah()
                    ->sortable(),
                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('deleted_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('type')
                    ->label('Tipe Akun')
                    ->options([
                        'Asset' => 'Asset',
                        'Liability' => 'Liability',
                        'Equity' => 'Equity',
                        'Revenue' => 'Revenue',
                        'Expense' => 'Expense',
                        'Contra Asset' => 'Contra Asset',
                    ])
                    ->placeholder('Pilih Tipe Akun'),
            ])
            ->actions([
                ActionGroup::make([
                    TableAction::make('ledger')
                        ->label('Buku Besar')
                        ->icon('heroicon-o-book-open')
                        ->color('info')
                        ->url(fn ($record) => static::getUrl('view', ['record' => $record->id])),
                    EditAction::make()
                        ->color('success'),
                    DeleteAction::make(),
                ])
            ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            JournalEntryRelationManager::class
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListChartOfAccounts::route('/'),
            'create' => Pages\CreateChartOfAccount::route('/create'),
            'view' => ViewChartOfAccount::route('/{record}'),
            'edit' => Pages\EditChartOfAccount::route('/{record}/edit'),
        ];
    }

    protected function afterSave($record): void
    {
        $record->updateEndingBalance();
    }
}
