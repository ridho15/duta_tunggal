<?php

namespace App\Filament\Resources;

use App\Filament\Resources\StockAdjustmentResource\Pages;
use App\Filament\Resources\StockAdjustmentResource\RelationManagers;
use App\Helpers\MoneyHelper;
use App\Http\Controllers\HelperController;
use App\Models\InventoryStock;
use App\Models\Product;
use App\Models\StockAdjustment;
use App\Models\Rak;
use App\Models\Warehouse;
use App\Services\StockAdjustmentService;
use Filament\Forms;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\ActionsPosition;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\HtmlString;
use Illuminate\Validation\ValidationException;

class StockAdjustmentResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = StockAdjustment::class;

    protected static bool $shouldRegisterNavigation = true;

    protected static ?string $navigationIcon = 'heroicon-o-adjustments-horizontal';

    protected static ?string $navigationGroup = 'GUDANG';

    protected static ?string $navigationLabel = 'Penyesuaian Stok';

    protected static ?string $modelLabel = 'Penyesuaian Stok';

    protected static ?string $pluralModelLabel = 'Penyesuaian Stok';

    protected static ?int $navigationSort = 6;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Fieldset::make('Informasi Adjustment')
                    ->schema([
                        TextInput::make('adjustment_number')
                            ->label('Nomor Adjustment')
                            ->required()
                            ->unique(ignoreRecord: true)
                            ->default(fn () => \App\Models\StockAdjustment::generateAdjustmentNumber())
                            ->readonly()
                            ->suffixAction(
                                Forms\Components\Actions\Action::make('regenerate')
                                    ->label('Generate Baru')
                                    ->icon('heroicon-o-arrow-path')
                                    ->action(function (Forms\Set $set) {
                                        $set('adjustment_number', \App\Models\StockAdjustment::generateAdjustmentNumber());
                                    })
                            )
                            ->validationMessages([
                                'required' => 'Nomor adjustment harus diisi',
                                'unique' => 'Nomor adjustment sudah digunakan'
                            ]),

                        DatePicker::make('adjustment_date')
                            ->label('Tanggal Adjustment')
                            ->required()
                            ->default(now())
                            ->validationMessages([
                                'required' => 'Tanggal adjustment harus diisi'
                            ]),

                        Select::make('warehouse_id')
                            ->label('Gudang')
                            ->live()
                            ->options(function () {
                                $user = Auth::user();
                                $manageType = $user?->manage_type ?? [];
                                $query = Warehouse::where('status', 1);
                                
                                if (!$user || !is_array($manageType) || !in_array('all', $manageType)) {
                                    $query->where('cabang_id', $user?->cabang_id);
                                }
                                
                                return $query->get()->mapWithKeys(function ($warehouse) {
                                    return [$warehouse->id => "({$warehouse->kode}) {$warehouse->name}"];
                                });
                            })
                            ->required()
                            ->searchable()
                            ->preload()
                            ->getSearchResultsUsing(function (string $search) {
                                $user = Auth::user();
                                $manageType = $user?->manage_type ?? [];
                                $query = Warehouse::where('status', 1)
                                    ->where(function ($q) use ($search) {
                                                                                $q->where('name', 'like', "%{$search}%")
                                          ->orWhere('kode', 'like', "%{$search}%");
                                    });
                                
                                if (!$user || !is_array($manageType) || !in_array('all', $manageType)) {
                                    $query->where('cabang_id', $user?->cabang_id);
                                }
                                
                                return $query->limit(50)->get()->mapWithKeys(function ($warehouse) {
                                    return [$warehouse->id => "({$warehouse->kode}) {$warehouse->name}"];
                                });
                            })
                            ->validationMessages([
                                'required' => 'Warehouse harus dipilih'
                            ]),

                        Select::make('adjustment_type')
                            ->label('Tipe Adjustment')
                            ->options([
                                'increase' => 'Penambahan Stock (+)',
                                'decrease' => 'Pengurangan Stock (-)',
                            ])
                            ->required()
                            ->validationMessages([
                                'required' => 'Tipe adjustment harus dipilih'
                            ]),

                        TextInput::make('reason')
                            ->label('Alasan')
                            ->required()
                            ->validationMessages([
                                'required' => 'Alasan adjustment harus diisi'
                            ]),

                        Textarea::make('notes')
                            ->label('Catatan')
                            ->rows(3),

                        Repeater::make('items')
                            ->label('Item Adjustment')
                            ->relationship()
                            ->defaultItems(1)
                            ->minItems(1)
                            ->addActionLabel('Tambah Item')
                            ->columnSpanFull()
                            ->schema([
                                Select::make('product_id')
                                    ->label('Produk')
                                    ->searchable()
                                    ->preload()
                                    ->required()
                                    ->options(fn () => self::resolveProductOptions())
                                    ->getSearchResultsUsing(fn (string $search) => self::resolveProductOptions($search))
                                    ->getOptionLabelUsing(fn ($value): ?string => self::resolveProductLabel(is_numeric($value) ? (int) $value : null))
                                    ->live()
                                    ->afterStateUpdated(function ($state, Forms\Get $get, Forms\Set $set) {
                                        self::syncAdjustmentItemStockState($set, $get, $get('../../warehouse_id'), $state, $get('rak_id'));

                                        if (is_numeric($state)) {
                                            $product = Product::withoutGlobalScope('product_cabang')->find((int) $state);
                                            if ($product) {
                                                $set('unit_cost', self::formatMoney($product->cost_price ?? 0));
                                            }
                                        }

                                        self::syncDifferenceValue($set, (float) ($get('difference_qty') ?? 0), $get('unit_cost'));
                                    }),

                                Select::make('rak_id')
                                    ->label('Rak')
                                    ->searchable()
                                    ->preload()
                                    ->nullable()
                                    ->placeholder('Pilih rak (opsional)')
                                    ->options(function (Forms\Get $get) {
                                        return self::resolveRakOptions($get('../../warehouse_id'));
                                    })
                                    ->getSearchResultsUsing(function (string $search, Forms\Get $get) {
                                        return self::resolveRakOptions($get('../../warehouse_id'), $search);
                                    })
                                    ->getOptionLabelUsing(fn ($value): ?string => self::resolveRakLabel(is_numeric($value) ? (int) $value : null))
                                    ->live()
                                    ->afterStateUpdated(function ($state, Forms\Get $get, Forms\Set $set) {
                                        self::syncAdjustmentItemStockState($set, $get, $get('../../warehouse_id'), $get('product_id'), $state);
                                        self::syncDifferenceValue($set, (float) ($get('difference_qty') ?? 0), $get('unit_cost'));
                                    }),

                                TextInput::make('current_qty')
                                    ->label('Qty Saat Ini')
                                    ->numeric()
                                    ->disabled()
                                    ->dehydrated()
                                    ->default(0),

                                TextInput::make('adjusted_qty')
                                    ->label('Qty Setelah Adjustment')
                                    ->numeric()
                                    ->minValue(0)
                                    ->required()
                                    ->live()
                                    ->afterStateUpdated(function ($state, Forms\Get $get, Forms\Set $set) {
                                        $currentQty = (float) ($get('current_qty') ?? 0);
                                        $adjustedQty = (float) ($state ?? 0);
                                        $differenceQty = $adjustedQty - $currentQty;
                                        $set('difference_qty', $differenceQty);
                                        self::syncDifferenceValue($set, $differenceQty, $get('unit_cost'));
                                    }),

                                TextInput::make('difference_qty')
                                    ->label('Selisih Qty')
                                    ->disabled()
                                    ->dehydrated(),

                                // Harga memicu hitung Nilai Selisih, jadi memakai debounce (bukan onBlur), sama dengan relation manager-nya.
                                TextInput::make('unit_cost')
                                    ->label('Harga Satuan')
                                    ->indonesianMoney()
                                    ->required()
                                    ->default(0)
                                    ->live(debounce: 500)
                                    ->afterStateUpdated(function ($state, Forms\Get $get, Forms\Set $set) {
                                        self::syncDifferenceValue($set, (float) ($get('difference_qty') ?? 0), $state);
                                    }),

                                TextInput::make('difference_value')
                                    ->label('Nilai Selisih')
                                    ->indonesianMoney()
                                    ->disabled()
                                    ->dehydrated(),

                                Textarea::make('notes')
                                    ->label('Catatan')
                                    ->rows(2),
                            ]),

                        Hidden::make('status')
                            ->default('draft'),

                        Hidden::make('created_by')
                            ->default(Auth::id()),

                        Placeholder::make('status_display')
                            ->label('Status')
                            ->content(fn (?StockAdjustment $record): string => match ($record?->status) {
                                'approved' => 'Approved',
                                'rejected' => 'Rejected',
                                default => 'Draft',
                            }),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('adjustment_number')
                    ->label('Nomor')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('adjustment_date')
                    ->label('Tanggal')
                    ->date('d/m/Y')
                    ->sortable(),

                TextColumn::make('warehouse')
                    ->label('Gudang')
                    ->formatStateUsing(function ($state) {
                        return "({$state->kode}) {$state->name}";
                    })
                    ->searchable(query: function (Builder $query, $search) {
                        return $query->whereHas('warehouse', function ($query) use ($search) {
                            return $query->where('kode', 'LIKE', '%' . $search . '%')
                                ->orWhere('name', 'LIKE', '%' . $search . '%');
                        });
                    })
                    ->sortable(),

                TextColumn::make('adjustment_type')
                    ->label('Tipe')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'increase' => 'success',
                        'decrease' => 'danger',
                    })
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'increase' => 'Penambahan (+)',
                        'decrease' => 'Pengurangan (-)',
                    }),

                TextColumn::make('reason')
                    ->label('Alasan')
                    ->limit(30)
                    ->tooltip(function (TextColumn $column): ?string {
                        $state = $column->getState();
                        if (strlen($state) <= 30) {
                            return null;
                        }
                        return $state;
                    }),

                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'draft' => 'gray',
                        'approved' => 'success',
                        'rejected' => 'danger',
                    }),

                TextColumn::make('creator.name')
                    ->label('Dibuat Oleh')
                    ->sortable(),

                TextColumn::make('created_at')
                    ->label('Dibuat')
                    ->dateTime('d/m/Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('warehouse_id')
                    ->label('Gudang')
                    ->options(function () {
                        $user = Auth::user();
                        $manageType = $user?->manage_type ?? [];
                        $query = Warehouse::where('status', 1);

                        if (!$user || !is_array($manageType) || !in_array('all', $manageType)) {
                            $query->where('cabang_id', $user?->cabang_id);
                        }

                        return $query->orderBy('name')
                            ->get()
                            ->mapWithKeys(function ($warehouse) {
                                return [$warehouse->id => "({$warehouse->kode}) {$warehouse->name}"];
                            });
                    }),

                SelectFilter::make('adjustment_type')
                    ->label('Tipe Adjustment')
                    ->options([
                        'increase' => 'Penambahan Stock (+)',
                        'decrease' => 'Pengurangan Stock (-)',
                    ]),

                SelectFilter::make('status')
                    ->label('Status')
                    ->options([
                        'draft' => 'Draft',
                        'approved' => 'Approved',
                        'rejected' => 'Rejected',
                    ]),
            ])
            ->actions([
                Tables\Actions\ActionGroup::make([
                    Tables\Actions\ViewAction::make()->color('primary'),
                    Tables\Actions\EditAction::make()
                        ->visible(fn (StockAdjustment $record) => $record->status === 'draft'),
                    Tables\Actions\DeleteAction::make()
                        ->visible(fn (StockAdjustment $record) => in_array($record->status, ['draft', 'rejected'], true)),
                    Tables\Actions\Action::make('approve')
                        ->label('Approve')
                        ->icon('heroicon-o-check-circle')
                        ->color('success')
                        ->visible(fn (StockAdjustment $record) => $record->status === 'draft')
                        ->requiresConfirmation()
                        ->modalHeading('Setujui Stock Adjustment')
                        ->modalDescription('Approval akan membuat mutasi stok sesuai item adjustment dan tidak dapat dibatalkan dari layar ini.')
                        ->action(function (StockAdjustment $record) {
                            try {
                                app(StockAdjustmentService::class)->approveStockAdjustment($record, Auth::id());

                                HelperController::sendNotification(
                                    isSuccess: true,
                                    title: 'Information',
                                    message: 'Stock adjustment berhasil disetujui, mutasi stok dan jurnal penyesuaian sudah dicatat.'
                                );
                            } catch (ValidationException $exception) {
                                HelperController::sendNotification(
                                    isSuccess: false,
                                    title: 'Validasi Stock Adjustment',
                                    message: collect($exception->errors())->flatten()->implode("\n")
                                );
                            }
                        }),
                    Tables\Actions\Action::make('reject')
                        ->label('Reject')
                        ->icon('heroicon-o-x-circle')
                        ->color('danger')
                        ->visible(fn (StockAdjustment $record) => $record->status === 'draft')
                        ->requiresConfirmation()
                        ->action(fn (StockAdjustment $record) => $record->update([
                            'status' => 'rejected',
                            'approved_by' => Auth::id(),
                            'approved_at' => now(),
                        ])),
                ])
            ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('created_at', 'desc')
            ->description(new HtmlString('
                <details style="background: #f8f9fa; padding: 12px; border-radius: 8px; margin-bottom: 16px; border: 1px solid #dee2e6;">
                    <summary style="cursor: pointer; font-weight: bold; color: #495057; font-size: 14px;">
                        📊 Panduan Manajemen Penyesuaian Stok
                    </summary>
                    <div style="margin-top: 12px; color: #495057; font-size: 13px; line-height: 1.5;">
                        <div style="margin-bottom: 12px;">
                            <strong style="color: #dc3545;">🎯 Tujuan & Fungsi:</strong>
                            <ul style="margin: 8px 0; padding-left: 20px;">
                                <li>Mengelola koreksi dan penyesuaian quantity stok inventory</li>
                                <li>Menangani perbedaan fisik vs sistem dalam stock taking</li>
                                <li>Memperbaiki kesalahan input atau kerusakan produk</li>
                                <li>Mempertahankan akurasi data inventory dengan approval workflow</li>
                            </ul>
                        </div>

                        <div style="margin-bottom: 12px;">
                            <strong style="color: #28a745;">🔄 Tipe Penyesuaian:</strong>
                            <ul style="margin: 8px 0; padding-left: 20px;">
                                <li><strong>Penambahan Stock (+):</strong> Menambah quantity untuk koreksi kekurangan</li>
                                <li><strong>Pengurangan Stock (-):</strong> Mengurangi quantity untuk koreksi kelebihan</li>
                                <li><strong>Nomor Adjustment:</strong> Auto-generated untuk tracking unik setiap adjustment</li>
                                <li><strong>Tanggal Adjustment:</strong> Tanggal efektif perubahan stok</li>
                            </ul>
                        </div>

                        <div style="margin-bottom: 12px;">
                            <strong style="color: #007bff;">⚙️ Item Penyesuaian:</strong>
                            <ul style="margin: 8px 0; padding-left: 20px;">
                                <li><strong>Produk:</strong> Pilih produk yang akan disesuaikan</li>
                                <li><strong>Rak & Lokasi:</strong> Tentukan lokasi penyimpanan spesifik</li>
                                <li><strong>Quantity:</strong> Jumlah yang akan ditambah/dikurangi</li>
                                <li><strong>Kondisi:</strong> Status produk (good/damage/repair)</li>
                                <li><strong>Alasan:</strong> Penjelasan detail mengapa adjustment dilakukan</li>
                            </ul>
                        </div>

                        <div style="margin-bottom: 12px;">
                            <strong style="color: #ffc107;">📊 Alur Status:</strong>
                            <ul style="margin: 8px 0; padding-left: 20px;">
                                <li><strong>Draft:</strong> Adjustment dibuat, dapat diedit/dihapus</li>
                                <li><strong>Approved:</strong> Adjustment disetujui, stok diperbarui otomatis</li>
                                <li><strong>Rejected:</strong> Adjustment ditolak, tidak ada perubahan stok</li>
                                <li><strong>Kode Warna:</strong> Abu-abu=Draft, Hijau=Approved, Merah=Rejected</li>
                            </ul>
                        </div>

                        <div style="margin-bottom: 12px;">
                            <strong style="color: #17a2b8;">🔗 Integrasi & Dependensi:</strong>
                            <ul style="margin: 8px 0; padding-left: 20px;">
                                <li><strong>Inventory Management:</strong> Langsung memperbarui stock levels</li>
                                <li><strong>Warehouse & Racks:</strong> Mengelola penempatan produk per lokasi</li>
                                <li><strong>Stock Movement:</strong> Mencatat pergerakan stok untuk audit trail</li>
                                <li><strong>Product Management:</strong> Terintegrasi dengan master data produk</li>
                                <li><strong>Reporting:</strong> Data adjustment tersedia untuk laporan inventory</li>
                            </ul>
                        </div>

                        <div style="margin-bottom: 12px;">
                            <strong style="color: #6c757d;">🔐 Permission & Workflow:</strong>
                            <ul style="margin: 8px 0; padding-left: 20px;">
                                <li><strong>Create:</strong> User dapat membuat adjustment draft</li>
                                <li><strong>Edit:</strong> Hanya adjustment draft yang dapat dimodifikasi</li>
                                <li><strong>Approve/Reject:</strong> Membutuhkan permission khusus untuk approval</li>
                                <li><strong>Delete:</strong> Hanya draft atau admin yang dapat menghapus</li>
                                <li><strong>View:</strong> Semua user dapat melihat detail adjustment</li>
                            </ul>
                        </div>

                        <div style="margin-bottom: 12px;">
                            <strong style="color: #fd7e14;">📈 Reporting & Audit:</strong>
                            <ul style="margin: 8px 0; padding-left: 20px;">
                                <li><strong>Audit Trail:</strong> Mencatat semua perubahan dan approval</li>
                                <li><strong>Stock History:</strong> Riwayat perubahan quantity per produk</li>
                                <li><strong>User Tracking:</strong> Mencatat siapa yang membuat/menyetujui</li>
                                <li><strong>Reason Logging:</strong> Alasan adjustment tersimpan untuk reference</li>
                            </ul>
                        </div>

                        <div style="background: #fff3cd; padding: 8px; border-radius: 4px; border-left: 4px solid #ffc107;">
                            <strong style="color: #856404;">⚠️ Catatan Penting:</strong>
                            <ul style="margin: 4px 0; padding-left: 20px; color: #856404;">
                                <li>Adjustment yang sudah approved akan langsung mempengaruhi quantity stok</li>
                                <li>Pastikan alasan adjustment jelas dan dapat dipertanggungjawabkan</li>
                                <li>Adjustment tidak dapat diubah setelah approved - buat adjustment baru jika perlu</li>
                                <li>Gunakan dengan hati-hati karena langsung mempengaruhi akurasi inventory</li>
                                <li>Selalu lakukan stock opname fisik sebelum melakukan adjustment besar</li>
                            </ul>
                        </div>
                    </div>
                </details>
            '));
    }

    public static function getRelations(): array
    {
        return [
            RelationManagers\StockAdjustmentItemsRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListStockAdjustments::route('/'),
            'create' => Pages\CreateStockAdjustment::route('/create'),
            'view' => Pages\ViewStockAdjustment::route('/{record}'),
            'edit' => Pages\EditStockAdjustment::route('/{record}/edit'),
        ];
    }

    public static function resolveProductOptions(?string $search = null): array
    {
        $query = Product::query()->orderBy('sku')->orderBy('name');

        if (filled($search)) {
            $query->where(function (Builder $query) use ($search) {
                $query->where('sku', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%");
            });
        }

        return $query
            ->limit(50)
            ->get()
            ->mapWithKeys(fn (Product $product) => [
                $product->id => sprintf('(%s) %s', $product->sku ?? '-', $product->name ?? '-'),
            ])
            ->toArray();
    }

    public static function resolveProductLabel(?int $productId): ?string
    {
        if (! $productId) {
            return null;
        }

        $product = Product::find($productId);

        return $product ? sprintf('(%s) %s', $product->sku ?? '-', $product->name ?? '-') : null;
    }

    public static function resolveRakOptions(?int $warehouseId = null, ?string $search = null): array
    {
        if (! $warehouseId) {
            return [];
        }

        $query = Rak::query()->where('warehouse_id', $warehouseId)->orderBy('code')->orderBy('name');

        if (filled($search)) {
            $query->where(function (Builder $query) use ($search) {
                $query->where('code', 'like', "%{$search}%")
                    ->orWhere('name', 'like', "%{$search}%");
            });
        }

        return $query
            ->limit(50)
            ->get()
            ->mapWithKeys(fn (Rak $rak) => [
                $rak->id => sprintf('(%s) %s', $rak->code ?? '-', $rak->name ?? '-'),
            ])
            ->toArray();
    }

    public static function resolveRakLabel(?int $rakId): ?string
    {
        if (! $rakId) {
            return null;
        }

        $rak = Rak::find($rakId);

        return $rak ? sprintf('(%s) %s', $rak->code ?? '-', $rak->name ?? '-') : null;
    }

    public static function resolveAdjustmentCurrentQty(?int $productId, ?int $warehouseId, ?int $rakId = null): float
    {
        if (! $productId || ! $warehouseId) {
            return 0.0;
        }

        return InventoryStock::freeQtyFor($productId, $warehouseId, $rakId);
    }

    protected static function syncAdjustmentItemStockState(Forms\Set $set, Forms\Get $get, $warehouseId, $productId, $rakId = null): void
    {
        if (! $warehouseId) {
            $set('current_qty', 0);
            $set('difference_qty', 0);
            return;
        }

        $currentQty = self::resolveAdjustmentCurrentQty(
            is_numeric($productId) ? (int) $productId : null,
            is_numeric($warehouseId) ? (int) $warehouseId : null,
            is_numeric($rakId) ? (int) $rakId : null,
        );

        $set('current_qty', $currentQty);
        $adjustedQty = $get('adjusted_qty');
        if ($adjustedQty === null || $adjustedQty === '') {
            $set('adjusted_qty', $currentQty);
            $adjustedQty = $currentQty;
        }

        $adjustedQty = (float) $adjustedQty;
        $set('difference_qty', $adjustedQty - $currentQty);
    }

    /**
     * Harga satuan datang sebagai string bermask ("10.000,00"), sehingga wajib di-parse dengan MoneyHelper
     * (bukan cast (float)), dan hasilnya disimpan ke state dalam format yang sama agar tampil konsisten.
     */
    public static function syncDifferenceValue(Forms\Set $set, float $differenceQty, $unitCost): void
    {
        $set('difference_value', self::formatMoney($differenceQty * MoneyHelper::safeParse($unitCost)));
    }

    public static function formatMoney(mixed $value): string
    {
        return number_format(MoneyHelper::safeParse($value), 2, ',', '.');
    }

    public static function getEloquentQuery(): Builder
    {
        $query = parent::getEloquentQuery();

        $user = Auth::user();
        if ($user && ! in_array('all', $user->manage_type ?? [])) {
            $query->whereHas('warehouse', function (Builder $q) use ($user) {
                $q->where('cabang_id', $user->cabang_id);
            });
        }

        return $query;
    }
}
