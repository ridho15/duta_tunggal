<?php

namespace App\Filament\Resources;

use App\Filament\Resources\QualityControlManufactureResource\Pages;
use App\Filament\Resources\QualityControlManufactureResource\Pages\ViewQualityControlManufacture;
use App\Filament\Resources\QualityControlManufactureResource\Widgets;
use App\Http\Controllers\HelperController;
use App\Models\InventoryStock;
use App\Models\Production;
use App\Models\QualityControl;
use App\Models\Rak;
use App\Models\ReturnProduct;
use App\Models\Warehouse;
use App\Services\PurchaseReturnAutomationService;
use App\Services\QualityControlService;
use App\Services\ReturnProductService;
use Filament\Forms\Components\Actions\Action as ActionsAction;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\DeleteBulkAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;
use Filament\Tables\Enums\ActionsPosition;

class QualityControlManufactureResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = QualityControl::class;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $navigationIcon = 'heroicon-o-cog-6-tooth';

    protected static ?string $navigationGroup = 'PRODUKSI';

    protected static ?string $navigationLabel = 'QC Produksi';

    protected static ?string $modelLabel = 'Kontrol Kualitas Produksi';

    protected static ?string $pluralModelLabel = 'Kontrol Kualitas Produksi';

    protected static ?int $navigationSort = 6;

    public static function canChooseInspector(): bool
    {
        return Auth::user()?->hasRole(['Super Admin', 'Owner']) === true;
    }

    public static function getProductionQuery(?QualityControl $record = null): Builder
    {
        $currentProductionId = $record?->from_model_type === Production::class
            ? $record->from_model_id
            : null;
        $qualityControlTable = (new QualityControl())->getTable();
        $productionTable = (new Production())->getTable();

        return Production::query()
            ->with(['manufacturingOrder.productionPlan.product'])
            ->whereIn('status', ['finished', 'completed'])
            ->where(function (Builder $query) use ($currentProductionId, $qualityControlTable, $productionTable) {
                $query->whereNotExists(function ($subQuery) use ($qualityControlTable, $productionTable) {
                    $subQuery->selectRaw('1')
                        ->from($qualityControlTable)
                        ->whereColumn("{$qualityControlTable}.from_model_id", "{$productionTable}.id")
                        ->where("{$qualityControlTable}.from_model_type", Production::class)
                        ->whereNull("{$qualityControlTable}.deleted_at");
                });

                if ($currentProductionId) {
                    $query->orWhere('id', $currentProductionId);
                }
            })
            ->orderByDesc('production_date')
            ->orderByDesc('id');
    }

    public static function getProductionOptionLabel(?Production $production): string
    {
        if (! $production || ! $production->exists) {
            return '-';
        }

        $production->loadMissing('manufacturingOrder.productionPlan.product');

        $manufacturingOrder = $production->manufacturingOrder;
        $productionPlan = $manufacturingOrder?->productionPlan;
        $product = $productionPlan?->product;
        $quantity = $production->quantity_produced ?? $productionPlan?->quantity ?? 0;

        return sprintf(
            'MO: %s - %s (Qty: %s)',
            $manufacturingOrder?->mo_number ?? '-',
            $product?->name ?? '-',
            rtrim(rtrim(number_format((float) $quantity, 2, '.', ''), '0'), '.')
        );
    }

    public static function getProductionSelectOptions(?QualityControl $record = null): array
    {
        return static::getProductionQuery($record)
            ->get()
            ->mapWithKeys(function (Production $production) {
                return [$production->id => static::getProductionOptionLabel($production)];
            })
            ->all();
    }

    public static function findProductionOptionLabel($value): ?string
    {
        if (! $value) {
            return null;
        }

        $production = Production::query()
            ->with(['manufacturingOrder.productionPlan.product'])
            ->find($value);

        if (! $production) {
            return null;
        }

        return static::getProductionOptionLabel($production);
    }

    public static function resolveProductionContext(?Production $production): array
    {
        $production?->loadMissing('manufacturingOrder.productionPlan.product');

        $manufacturingOrder = $production?->manufacturingOrder;
        $productionPlan = $manufacturingOrder?->productionPlan;

        return [
            'product_id' => $productionPlan?->product_id,
            'product_name' => $productionPlan?->product?->name,
            'warehouse_id' => $production?->warehouse_id ?? $productionPlan?->warehouse_id,
            'rak_id' => $production?->rak_id,
            'passed_quantity' => (float) ($production?->quantity_produced ?? $productionPlan?->quantity ?? 0),
            'rejected_quantity' => 0,
            'total_inspected' => (float) ($production?->quantity_produced ?? $productionPlan?->quantity ?? 0),
            'cabang_id' => $manufacturingOrder?->cabang_id ?? $productionPlan?->cabang_id ?? Auth::user()?->cabang_id,
        ];
    }

    public static function buildProcessingFormSchema(?QualityControl $record): array
    {
        $production = $record?->fromModel;
        $manufacturingOrder = $production?->manufacturingOrder;
        $productionPlan = $manufacturingOrder?->productionPlan;
        $product = $record?->product;
        $targetQuantity = (float) ($production?->quantity_produced ?? $productionPlan?->quantity ?? 0);

        return [
            TextInput::make('product_info')
                ->label('Produk')
                ->default($product ? "({$product->sku}) {$product->name}" : '-')
                ->disabled()
                ->dehydrated(false),
            TextInput::make('production_reference')
                ->label('Referensi Produksi')
                ->default($production ? "{$production->production_number} / {$manufacturingOrder?->mo_number}" : '-')
                ->disabled()
                ->dehydrated(false),
            TextInput::make('target_quantity')
                ->label('Total Produksi')
                ->default($targetQuantity)
                ->disabled()
                ->dehydrated(false),
            TextInput::make('passed_quantity')
                ->label('Passed Quantity')
                ->numeric()
                ->required()
                ->default((float) ($record?->passed_quantity ?? 0))
                ->helperText($targetQuantity > 0 ? 'Total passed + reject tidak boleh melebihi total produksi.' : null),
            TextInput::make('rejected_quantity')
                ->label('Rejected Quantity')
                ->numeric()
                ->required()
                ->default((float) ($record?->rejected_quantity ?? 0)),
            Textarea::make('reason_reject')
                ->label('Reason Reject')
                ->rows(3)
                ->default($record?->reason_reject),
            Select::make('warehouse_id')
                ->label('Gudang')
                ->options(function () {
                    $user = Auth::user();
                    $manageType = $user?->manage_type ?? [];
                    $query = Warehouse::where('status', 1);

                    if (!$user || !is_array($manageType) || !in_array('all', $manageType)) {
                        $query->where('cabang_id', $user?->cabang_id);
                    }

                    return $query->orderBy('name')
                        ->get()
                        ->mapWithKeys(function ($warehouse) {
                            return [$warehouse->id => "({$warehouse->kode}) {$warehouse->name}"];
                        });
                })
                ->default($record?->warehouse_id)
                ->required()
                ->searchable()
                ->preload()
                ->reactive(),
            Select::make('rak_id')
                ->label('Rak')
                ->options(function ($get) {
                    $warehouseId = $get('warehouse_id');

                    if (!$warehouseId) {
                        return [];
                    }

                    return Rak::query()
                        ->where('warehouse_id', $warehouseId)
                        ->get()
                        ->mapWithKeys(fn($rak) => [$rak->id => filled($rak->code) ? "({$rak->code}) {$rak->name}" : ($rak->name ?? '-')])
                        ->toArray();
                })
                ->required(function ($get) {
                    $warehouseId = $get('warehouse_id');
                    return filled($warehouseId) && Rak::where('warehouse_id', $warehouseId)->exists();
                })
                ->validationMessages([
                    'required' => 'Rak penyimpanan barang jadi wajib dipilih untuk gudang yang memiliki konfigurasi rak.',
                ])
                ->helperText(function ($get) {
                    $warehouseId = $get('warehouse_id');
                    if (!$warehouseId) return null;
                    return Rak::where('warehouse_id', $warehouseId)->exists()
                        ? 'Pilih rak penyimpanan untuk barang jadi hasil produksi.'
                        : 'Gudang ini tidak memiliki konfigurasi rak.';
                })
                ->default($record?->rak_id)
                ->searchable()
                ->preload(),
        ];
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Fieldset::make('Form Quality Control Manufacture')
                    ->schema([
                        Section::make('From Production')
                            ->description('Quality Control untuk Production')
                            ->columns(2)
                            ->columnSpanFull()
                            ->schema([
                                Hidden::make('from_model_type')
                                    ->default(Production::class),
                                Hidden::make('product_id')
                                    ->default(fn (?QualityControl $record) => $record?->product_id),
                                Hidden::make('cabang_id')
                                    ->default(fn (?QualityControl $record) => $record?->cabang_id ?? Auth::user()?->cabang_id),
                                Select::make('from_model_id')
                                    ->label('From Production')
                                    ->options(fn (?QualityControl $record) => static::getProductionSelectOptions($record))
                                    ->getOptionLabelUsing(fn ($value) => static::findProductionOptionLabel($value))
                                    ->preload()
                                    ->searchable()
                                    ->reactive()
                                    ->afterStateUpdated(function ($set, $get, $state) {
                                        $production = Production::query()
                                            ->with(['manufacturingOrder.productionPlan.product'])
                                            ->find($state);

                                        if ($production) {
                                            $context = static::resolveProductionContext($production);

                                            foreach ($context as $field => $value) {
                                                $set($field, $value);
                                            }
                                        }
                                    })
                                    ->required()
                                    ->validationMessages([
                                        'required' => 'Production wajib dipilih'
                                    ]),
                                TextInput::make('qc_number')
                                    ->label('QC Number')
                                    ->default(function () {
                                        return HelperController::generateUniqueCode('quality_controls', 'qc_number', 'QC-M-' . date('Ymd') . '-', 4);
                                    })
                                    ->required()
                                    ->unique(ignoreRecord: true)
                                    ->validationMessages([
                                        'required' => 'QC Number wajib diisi',
                                        'unique' => 'QC Number sudah digunakan'
                                    ]),
                            ]),
                        Section::make('Product Information')
                            ->columns(2)
                            ->schema([
                                TextInput::make('product_name')
                                    ->label('Product')
                                    ->default(fn (?QualityControl $record) => $record?->product?->name)
                                    ->disabled()
                                    ->dehydrated(false)
                                    ->afterStateUpdated(function ($set, $get) {
                                        $productId = $get('product_id');
                                        if ($productId) {
                                            $product = \App\Models\Product::find($productId);
                                            $set('product_name', $product ? $product->name : '');
                                        }
                                    }),
                                Select::make('warehouse_id')
                                    ->label('Warehouse')
                                    ->options(function () {
                                        $user = Auth::user();
                                        $manageType = $user?->manage_type ?? [];
                                        $query = Warehouse::where('status', 1);

                                        if (!$user || !is_array($manageType) || !in_array('all', $manageType)) {
                                            $query->where('cabang_id', $user?->cabang_id);
                                        }

                                        return $query->orderBy('name')
                                            ->get()
                                            ->mapWithKeys(function ($warehouse) {
                                                return [$warehouse->id => "({$warehouse->kode}) {$warehouse->name}"];
                                            });
                                    })
                                    ->required()
                                    ->getOptionLabelFromRecordUsing(function (Warehouse $warehouse) {
                                        return "({$warehouse->kode}) {$warehouse->name}";
                                    })
                                    ->reactive()
                                    ->validationMessages([
                                        'required' => 'Warehouse wajib dipilih'
                                    ]),
                                Select::make('rak_id')
                                    ->label('Rak')
                                    ->options(function ($get) {
                                        $warehouseId = $get('warehouse_id');
                                        if ($warehouseId) {
                                            return Rak::where('warehouse_id', $warehouseId)
                                                ->get()
                                                ->mapWithKeys(fn($rak) => [$rak->id => filled($rak->code) ? "({$rak->code}) {$rak->name}" : ($rak->name ?? '-')]);
                                        }
                                        return [];
                                    })
                                    ->required(function ($get) {
                                        $warehouseId = $get('warehouse_id');
                                        return filled($warehouseId) && Rak::where('warehouse_id', $warehouseId)->exists();
                                    })
                                    ->validationMessages([
                                        'required' => 'Rak penyimpanan barang jadi wajib dipilih untuk gudang yang memiliki konfigurasi rak.',
                                    ])
                                    ->helperText(function ($get) {
                                        $warehouseId = $get('warehouse_id');
                                        if (!$warehouseId) return null;
                                        return Rak::where('warehouse_id', $warehouseId)->exists()
                                            ? 'Pilih rak penyimpanan untuk barang jadi hasil produksi.'
                                            : 'Gudang ini tidak memiliki konfigurasi rak.';
                                    })
                                    ->searchable()
                                    ->preload(),
                            ]),
                        Section::make('Quality Control Result')
                            ->columns(3)
                            ->schema([
                                TextInput::make('passed_quantity')
                                    ->label('Passed Quantity')
                                    ->numeric()
                                    ->required()
                                    ->reactive()
                                    ->afterStateUpdated(function ($set, $get) {
                                        $passed = (float) $get('passed_quantity');
                                        $rejected = (float) $get('rejected_quantity');
                                        $totalInspected = $passed + $rejected;

                                        $productionId = $get('from_model_id');
                                        if ($productionId) {
                                            $production = Production::find($productionId);
                                            if ($production && $totalInspected > $production->quantity_produced) {
                                                $set('passed_quantity', $production->quantity_produced - $rejected);
                                            }
                                        }
                                    })
                                    ->validationMessages([
                                        'required' => 'Passed quantity wajib diisi',
                                        'numeric' => 'Passed quantity harus berupa angka'
                                    ]),
                                TextInput::make('rejected_quantity')
                                    ->label('Rejected Quantity')
                                    ->numeric()
                                    ->required()
                                    ->reactive()
                                    ->afterStateUpdated(function ($set, $get) {
                                        $passed = (float) $get('passed_quantity');
                                        $rejected = (float) $get('rejected_quantity');
                                        $totalInspected = $passed + $rejected;

                                        $productionId = $get('from_model_id');
                                        if ($productionId) {
                                            $production = Production::find($productionId);
                                            if ($production && $totalInspected > $production->quantity_produced) {
                                                $set('rejected_quantity', $production->quantity_produced - $passed);
                                            }
                                        }
                                    })
                                    ->validationMessages([
                                        'required' => 'Rejected quantity wajib diisi',
                                        'numeric' => 'Rejected quantity harus berupa angka'
                                    ]),
                                TextInput::make('total_inspected')
                                    ->label('Total Inspected')
                                    ->default(fn (?QualityControl $record) => (float) (($record?->passed_quantity ?? 0) + ($record?->rejected_quantity ?? 0)))
                                    ->disabled()
                                    ->dehydrated(false)
                                    ->reactive()
                                    ->afterStateUpdated(function ($set, $get) {
                                        $passed = (float) $get('passed_quantity');
                                        $rejected = (float) $get('rejected_quantity');
                                        $set('total_inspected', $passed + $rejected);
                                    }),
                            ]),
                        Section::make('Additional Information')
                            ->columns(2)
                            ->schema([
                                Select::make('inspected_by')
                                    ->label('Inspected By')
                                    ->options(\App\Models\User::pluck('name', 'id'))
                                    ->default(fn (?QualityControl $record) => $record?->inspected_by ?? Auth::id())
                                    ->disabled(fn () => ! static::canChooseInspector())
                                    ->dehydrated(true)
                                    ->searchable(fn () => static::canChooseInspector())
                                    ->preload(fn () => static::canChooseInspector())
                                    ->required()
                                    ->validationMessages([
                                        'required' => 'Inspected by wajib dipilih'
                                    ]),
                                DatePicker::make('date_send_stock')
                                    ->label('Date Send to Stock'),
                                Textarea::make('notes')
                                    ->label('Notes')
                                    ->rows(3),
                                Textarea::make('reason_reject')
                                    ->label('Reason Reject')
                                    ->rows(3),
                            ]),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('qc_number')
                    ->label('QC Number')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('fromModel.manufacturingOrder.mo_number')
                    ->label('Manufacturing Order')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('product.name')
                    ->label('Product')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('passed_quantity')
                    ->label('Passed')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('rejected_quantity')
                    ->label('Rejected')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('status_formatted')
                    ->label('Status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'Sudah diproses' => 'success',
                        'Belum diproses' => 'warning',
                    }),
                TextColumn::make('inspectedBy.name')
                    ->label('Inspected By')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('created_at')
                    ->label('Created At')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('status')
                    ->options([
                        0 => 'Belum diproses',
                        1 => 'Sudah diproses',
                    ]),
                SelectFilter::make('warehouse_id')
                    ->label('Warehouse')
                    ->options(function () {
                        $user = Auth::user();
                        $manageType = $user?->manage_type ?? [];
                        $query = Warehouse::where('status', 1);

                        if (!$user || !is_array($manageType) || !in_array('all', $manageType)) {
                            $query->where('cabang_id', $user?->cabang_id);
                        }

                        return $query->orderBy('name')
                            ->pluck('name', 'id');
                    }),
                Filter::make('created_at')
                    ->form([
                        DatePicker::make('created_from'),
                        DatePicker::make('created_until'),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when(
                                $data['created_from'],
                                fn (Builder $query, $date): Builder => $query->whereDate('created_at', '>=', $date),
                            )
                            ->when(
                                $data['created_until'],
                                fn (Builder $query, $date): Builder => $query->whereDate('created_at', '<=', $date),
                            );
                    }),
            ])
            ->actions([
                ActionGroup::make([
                    ViewAction::make(),
                    EditAction::make(),
                    Action::make('process_qc')
                        ->label('Process QC')
                        ->icon('heroicon-o-check-circle')
                        ->color('success')
                        ->visible(fn ($record) => !$record->status)
                        ->form(fn ($record) => static::buildProcessingFormSchema($record))
                        ->action(function (array $data, $record) {
                            $qcService = new QualityControlService();
                            $qcService->completeQualityControl($record, $data);
                            HelperController::sendNotification(isSuccess: true, title: "Information", message: "Quality Control Manufacture Completed. Proses selanjutnya: Tim Gudang perlu memindahkan barang hasil produksi ke lokasi penyimpanan dan memperbarui stok inventori.");
                        }),
                    DeleteAction::make(),
                ])
                ->icon('heroicon-m-ellipsis-horizontal'),
                    ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('created_at', 'desc')
            ->description(new \Illuminate\Support\HtmlString(
                '<details class="mb-4">' .
                    '<summary class="cursor-pointer font-semibold">Panduan Quality Control Manufacture (QC Produksi)</summary>' .
                    '<div class="mt-2 text-sm">' .
                        '<ul class="list-disc pl-5">' .
                            '<li><strong>Apa ini:</strong> Quality Control Manufacture adalah proses inspeksi kualitas produk yang telah selesai diproduksi dari Manufacturing Order.</li>' .
                            '<li><strong>Sumber:</strong> Dibuat otomatis dari <em>Production</em> record saat Manufacturing Order diselesaikan. Setiap production akan memiliki QC terpisah.</li>' .
                            '<li><strong>Komponen Utama:</strong> <em>QC Number</em> (nomor QC unik), <em>Manufacturing Order</em> (referensi MO), <em>Product</em> (produk yang diinspeksi), <em>Inspected By</em> (petugas QC).</li>' .
                            '<li><strong>Quantity Control:</strong> <em>Passed Quantity</em> (jumlah lulus QC), <em>Rejected Quantity</em> (jumlah ditolak), <em>Total Quantity</em> (dari production).</li>' .
                            '<li><strong>Status Flow:</strong> <em>Belum diproses</em> (menunggu inspeksi) → <em>Sudah diproses</em> (QC selesai, stock updated).</li>' .
                            '<li><strong>Validasi:</strong> <em>Quantity Check</em> - total passed + rejected harus sama dengan quantity production. <em>Stock Validation</em> - memastikan stock dapat diupdate.</li>' .
                            '<li><strong>Integration:</strong> Terintegrasi dengan <em>Production</em> (sumber), <em>Manufacturing Order</em> (proses produksi), <em>Production Plan</em> (rencana), dan <em>Inventory</em> (update stock).</li>' .
                            '<li><strong>Actions:</strong> <em>Process QC</em> (proses inspeksi - hanya untuk status belum diproses), <em>View/Edit</em> (lihat detail QC), <em>Delete</em> (hapus QC record).</li>' .
                            '<li><strong>Permissions:</strong> <em>view any quality control manufacture</em>, <em>create quality control manufacture</em>, <em>update quality control manufacture</em>, <em>delete quality control manufacture</em>, <em>restore quality control manufacture</em>, <em>force-delete quality control manufacture</em>.</li>' .
                            '<li><strong>Stock Impact:</strong> <em>Passed items</em> → stock produk jadi bertambah di inventory. <em>Rejected items</em> → tidak mempengaruhi stock (produk cacat tidak masuk inventory).</li>' .
                            '<li><strong>Reporting:</strong> Menyediakan data untuk quality metrics produksi, production efficiency, dan product quality tracking.</li>' .
                        '</ul>' .
                    '</div>' .
                '</details>'
            ));
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListQualityControlManufactures::route('/'),
            'create' => Pages\CreateQualityControlManufacture::route('/create'),
            'view' => Pages\ViewQualityControlManufacture::route('/{record}'),
            'edit' => Pages\EditQualityControlManufacture::route('/{record}/edit'),
        ];
    }

    public static function getEloquentQuery(): Builder
    {
        $query = parent::getEloquentQuery()->where('from_model_type', 'App\Models\Production');

        $user = Auth::user();
        if ($user && !in_array('all', $user->manage_type ?? [])) {
            $query->whereHas('fromModel.manufacturingOrder', function ($q) use ($user) {
                $q->where('cabang_id', $user->cabang_id);
            });
        }

        return $query;
    }
}
