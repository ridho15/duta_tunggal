<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PermissionResource\Pages;
use App\Models\Permission;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class PermissionResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = Permission::class;

    protected static bool $shouldRegisterNavigation = false;

    protected static ?string $navigationIcon = 'heroicon-o-finger-print';

    // Rename the group to the requested label
    protected static ?string $navigationGroup = 'User Roles Management';

    // Ensure the Roles group appears last in the requested order
    protected static ?int $navigationSort = 3;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->required()
                    ->maxLength(255)
                    ->disabled()
                    ->validationMessages([
                        'required' => 'Nama permission wajib diisi',
                        'max' => 'Nama permission maksimal 255 karakter'
                    ]),
                TextInput::make('description')
                    ->label('Deskripsi')
                    ->maxLength(65535)
                    ->disabled()
                    ->columnSpan('full'),
                Select::make('roles')
                    ->label('Roles')
                    ->preload()
                    ->searchable()
                    ->multiple()
                    ->relationship('roles', 'name'),
                Select::make('id_user')
                    ->label('User')
                    ->searchable()
                    ->preload()
                    ->relationship('users', 'name')
                    ->multiple()
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                TextColumn::make('name')
                    ->searchable(),
                TextColumn::make('description')
                    ->label('Deskripsi'),
                TextColumn::make('guard_name')
                    ->searchable(),
                TextColumn::make('roles.name')
                    ->label('Roles')
                    ->searchable()
                    ->badge(),
                TextColumn::make('users.name')
                    ->label('Users')
                    ->searchable()
                    ->badge()
            ])
            ->filters([
                //
            ])
            ->actions([
                EditAction::make()
            ])
            ->bulkActions([]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPermissions::route('/'),
            // 'create' => Pages\CreatePermission::route('/create'),
            // 'edit' => Pages\EditPermission::route('/{record}/edit'),
        ];
    }
}
