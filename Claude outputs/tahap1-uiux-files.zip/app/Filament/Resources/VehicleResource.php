<?php

namespace App\Filament\Resources;

use App\Filament\Resources\VehicleResource\RelationManagers\DeliveryOrderRelationManager;
use App\Filament\Resources\VehicleResource\Pages;
use App\Filament\Resources\VehicleResource\Pages\ViewVehicle;
use App\Models\Cabang;
use App\Models\Vehicle;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\DeleteBulkAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Enums\ActionsPosition;
use Illuminate\Support\Facades\Auth;

class VehicleResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = Vehicle::class;

    protected static bool $shouldRegisterNavigation = true;

    protected static ?string $navigationIcon = 'heroicon-o-truck';

    protected static ?string $navigationGroup = 'DATA MASTER';

    protected static ?string $navigationLabel = 'Kendaraan & Driver';

    protected static ?string $modelLabel = 'Kendaraan & Driver';

    protected static ?string $pluralModelLabel = 'Kendaraan & Driver';

    protected static ?int $navigationSort = 6;
    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Fieldset::make('Form Vehicle')
                    ->schema([
                        TextInput::make('plate')
                            ->label('Plat Nomor / Nomor Polisi')
                            ->placeholder('Contoh: B 1234 ABC')
                            ->required()
                            ->unique(ignoreRecord: true)
                            ->validationMessages([
                                'required' => 'Plat nomor tidak boleh kosong',
                                'unique' => 'Plat nomor sudah terdaftar',
                                'max' => 'Plat nomor terlalu panjang'
                            ])
                            ->maxLength(255),
                        Select::make('type')
                            ->label('Jenis Kendaraan')
                            ->options([
                                'Truck' => 'Truck',
                                'Pickup' => 'Pickup',
                                'Van' => 'Van',
                                'Motor' => 'Motor',
                                'Mobil Box' => 'Mobil Box',
                                'Container' => 'Container',
                                'Trailer' => 'Trailer',
                                'Lainnya' => 'Lainnya'
                            ])
                            ->searchable()
                            ->required()
                            ->validationMessages([
                                'required' => 'Jenis kendaraan harus dipilih'
                            ]),
                        TextInput::make('capacity')
                            ->label('Kapasitas')
                            ->placeholder('Contoh: 5 Ton, 1000 kg, 20 m³')
                            ->required()
                            ->validationMessages([
                                'required' => 'Kapasitas tidak boleh kosong',
                                'max' => 'Kapasitas terlalu panjang'
                            ])
                            ->maxLength(255),
                        Select::make('cabang_id')
                            ->label('Cabang')
                            ->options(Cabang::all()->mapWithKeys(function ($cabang) {
                                return [$cabang->id => "({$cabang->kode}) {$cabang->nama}"];
                            }))
                            ->required()
                            ->searchable()
                            ->preload()
                            ->visible(fn () => in_array('all', Auth::user()?->manage_type ?? []))
                            ->default(fn () => in_array('all', Auth::user()?->manage_type ?? []) ? null : Auth::user()?->cabang_id)
                            ->validationMessages([
                                'required' => 'Cabang harus dipilih',
                            ]),
                    ])
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                TextColumn::make('plate')
                    ->label('Plat Nomor')
                    ->searchable()
                    ->sortable()
                    ->copyable()
                    ->copyMessage('Plat nomor disalin!')
                    ->copyMessageDuration(1500),
                TextColumn::make('type')
                    ->label('Jenis Kendaraan')
                    ->searchable()
                    ->sortable()
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'Truck' => 'success',
                        'Pickup' => 'warning', 
                        'Van' => 'info',
                        'Motor' => 'gray',
                        'Mobil Box' => 'primary',
                        'Container' => 'danger',
                        'Trailer' => 'secondary',
                        default => 'gray',
                    }),
                TextColumn::make('capacity')
                    ->label('Kapasitas')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('cabang')
                    ->label('Cabang')
                    ->formatStateUsing(function ($state) {
                        return "({$state->kode}) {$state->nama}";
                    })
                    ->searchable(query: function (Builder $query, $search) {
                        return $query->whereHas('cabang', function ($query) use ($search) {
                            return $query->where('kode', 'LIKE', '%' . $search . '%')
                                ->orWhere('nama', 'LIKE', '%' . $search . '%');
                        });
                    }),
                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('deleted_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('type')
                    ->label('Jenis Kendaraan')
                    ->options([
                        'Truck' => 'Truck',
                        'Pickup' => 'Pickup',
                        'Van' => 'Van',
                        'Motor' => 'Motor',
                        'Mobil Box' => 'Mobil Box',
                        'Container' => 'Container',
                        'Trailer' => 'Trailer',
                        'Lainnya' => 'Lainnya'
                    ])
                    ->multiple()
                    ->preload(),
            ])
            ->actions([
                ActionGroup::make([
                    ViewAction::make()
                        ->color('primary'),
                    EditAction::make()
                        ->color('success'),
                    DeleteAction::make()
                ])
            ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            DeliveryOrderRelationManager::class
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListVehicles::route('/'),
            'view' => ViewVehicle::route('/{record}'),
            // 'create' => Pages\CreateVehicle::route('/create'),
            // 'edit' => Pages\EditVehicle::route('/{record}/edit'),
        ];
    }
}
