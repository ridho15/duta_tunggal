<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PaymentRequestResource\Pages;
use App\Models\Invoice;
use App\Models\PaymentRequest;
use App\Models\Supplier;
use App\Models\Cabang;
use App\Helpers\MoneyHelper;
use Filament\Forms;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\BadgeColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Tables\Actions\ActionGroup;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;

class PaymentRequestResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = PaymentRequest::class;

    protected static ?string $navigationIcon = 'heroicon-o-document-currency-dollar';
    protected static ?string $navigationLabel = 'Pengajuan Dana';
    protected static ?string $modelLabel = 'Pengajuan Dana';
    protected static ?string $pluralModelLabel = 'Pengajuan Dana';
    protected static ?string $navigationGroup = 'KEUANGAN';
    protected static ?int $navigationSort = 3;

    protected static bool $shouldRegisterNavigation = true;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Payment Request')
                    ->schema([
                        Section::make('Informasi Dasar')
                            ->columns(2)
                            ->schema([
                                TextInput::make('request_number')
                                    ->label('Nomor PR')
                                    ->default(fn () => PaymentRequest::generateNumber())
                                    ->dehydrated(true)
                                    ->required()
                                    ->suffixAction(
                                        Forms\Components\Actions\Action::make('generate')
                                            ->icon('heroicon-m-arrow-path')
                                            ->tooltip('Generate Nomor PR')
                                            ->action(function ($set) {
                                                $set('request_number', PaymentRequest::generateNumber());
                                            })
                                    ),

                                Select::make('supplier_id')
                                    ->label('Vendor / Supplier')
                                    ->relationship('supplier', 'perusahaan')
                                    ->getSearchResultsUsing(fn (string $search) =>
                                        Supplier::where('perusahaan', 'like', "%{$search}%")
                                            ->orWhere('code', 'like', "%{$search}%")
                                            ->orderBy('perusahaan')
                                            ->limit(30)
                                            ->get()
                                            ->mapWithKeys(fn ($s) => [$s->id => "({$s->code}) {$s->perusahaan}"])
                                            ->toArray()
                                    )
                                    ->getOptionLabelUsing(function ($value) {
                                        $s = Supplier::find($value);
                                        return $s ? "({$s->code}) {$s->perusahaan}" : null;
                                    })
                                    ->searchable()
                                    ->preload() // FIX #13: preload agar supplier langsung muncul tanpa harus ketik dulu
                                    ->required()
                                    ->reactive()
                                    ->afterStateUpdated(function ($state, $set) {
                                        $set('selected_invoices', []);
                                        if ($state) {
                                            $supplier = Supplier::find($state);
                                            if ($supplier) {
                                                $bankName = $supplier->nama_bank ?? $supplier->bank_name ?? '';
                                                $bankNum = $supplier->nomor_rekening ?? $supplier->rekening_bank ?? '';
                                                $holder = $supplier->nama_rekening ?? $supplier->atas_nama ?? $supplier->perusahaan ?? '';
                                                if ($bankNum || $bankName) {
                                                    $set('supplier_bank_info', trim("{$bankName} - {$bankNum} (a.n. {$holder})", ' -()'));
                                                }
                                            }
                                        }
                                    }),

                                TextInput::make('supplier_bank_info')
                                    ->label('Rekening Bank Vendor')
                                    ->disabled()
                                    ->dehydrated(false)
                                    ->placeholder('Otomatis dari master vendor')
                                    ->afterStateHydrated(function ($component, $get, $record) {
                                        $supplierId = $get('supplier_id') ?: $record?->supplier_id;
                                        if ($supplierId) {
                                            $supplier = Supplier::find($supplierId);
                                            if ($supplier) {
                                                $bankName = $supplier->nama_bank ?? $supplier->bank_name ?? '';
                                                $bankNum = $supplier->nomor_rekening ?? $supplier->rekening_bank ?? '';
                                                $holder = $supplier->nama_rekening ?? $supplier->atas_nama ?? $supplier->perusahaan ?? '';
                                                if ($bankNum || $bankName) {
                                                    $component->state(trim("{$bankName} - {$bankNum} (a.n. {$holder})", ' -()'));
                                                }
                                            }
                                        }
                                    }),

                                DatePicker::make('request_date')
                                    ->label('Tanggal Request')
                                    ->default(now())
                                    ->required(),

                                DatePicker::make('payment_date')
                                    ->label('Tanggal Pembayaran yang Diminta')
                                    ->required(),

                                Select::make('cabang_id')
                                    ->label('Cabang')
                                    ->options(fn () => Cabang::orderBy('kode')->get()->mapWithKeys(fn ($c) => [
                                        $c->id => "({$c->kode}) {$c->nama}"
                                    ]))
                                    ->searchable()
                                    ->preload()
                                    ->default(fn () => Auth::user()?->cabang_id)
                                    ->required(),

                                TextInput::make('total_amount')
                                    ->label('Total Pembayaran (Rp)')
                                    ->disabled()
                                    ->dehydrated(true)
                                    ->dehydrateStateUsing(fn ($state) => MoneyHelper::safeParse($state))
                                    ->indonesianMoney(),
                            ]),

                        Section::make('Pilih Invoice yang akan Dibayar')
                            ->schema([
                                CheckboxList::make('selected_invoices')
                                    ->label('')
                                    ->options(function ($get, $record) {
                                        $supplierId = $get('supplier_id');
                                        if (!$supplierId) return [];

                                        // restrict to invoices issued from purchase orders belonging to the selected supplier
                                        $poIds = \App\Models\PurchaseOrder::where('supplier_id', $supplierId)->pluck('id');
                                        $currentPrId = $record?->id;

                                        return Invoice::with('accountPayable')
                                            ->where('from_model_type', \App\Models\PurchaseOrder::class)
                                            ->whereIn('from_model_id', $poIds)
                                            ->whereNotIn('status', ['draft', Invoice::STATUS_PAID, Invoice::STATUS_CANCELLED])
                                            ->get()
                                            ->filter(function ($invoice) use ($currentPrId) {
                                                // Exclude invoices that are fully paid or have no remaining debt
                                                $remainingPayable = PaymentRequest::getInvoiceRemainingPayable($invoice, $currentPrId);
                                                return $remainingPayable > 0.01;
                                            })
                                            ->mapWithKeys(function ($invoice) use ($currentPrId) {
                                                try {
                                                    $dueDate = $invoice->due_date ? Carbon::parse($invoice->due_date)->format('d/m/Y') : '-';
                                                    $isOverdue = $invoice->due_date && Carbon::parse($invoice->due_date)->isPast();
                                                } catch (\Throwable $e) {
                                                    $dueDate = '-';
                                                    $isOverdue = false;
                                                }

                                                $remainingPayable = PaymentRequest::getInvoiceRemainingPayable($invoice, $currentPrId);
                                                $remainingFormatted = PurchaseInvoiceResource::formatInvoiceCurrencyPair($invoice, $remainingPayable);
                                                $totalFormatted = PurchaseInvoiceResource::formatInvoiceCurrencyPair($invoice, $invoice->total);
                                                $activePrAmount = PaymentRequest::getActivePrAmountForInvoice((int) $invoice->id, $currentPrId);

                                                $label = "{$invoice->invoice_number} - Sisa Hutang: {$remainingFormatted} (Total: {$totalFormatted}, Due: {$dueDate})";
                                                if ($isOverdue) {
                                                    $label .= ' ⚠ TERLAMBAT';
                                                }
                                                if ($activePrAmount > 0) {
                                                    $label .= ' [Sebagian di PR Aktif Lain]';
                                                }

                                                return [$invoice->id => $label];
                                            });
                                    })
                                    ->columns(1)
                                    ->reactive()
                                    ->afterStateUpdated(function ($set, $get, $state, $record) {
                                        if (!$state || empty($state)) {
                                            $set('cabang_id', Auth::user()?->cabang_id);
                                            $set('total_amount', 0);
                                            return;
                                        }

                                        $invoices = Invoice::with('accountPayable')->whereIn('id', (array) $state)->get();
                                        $firstInvoice = $invoices->first();
                                        if ($firstInvoice && $firstInvoice->cabang_id) {
                                            $set('cabang_id', $firstInvoice->cabang_id);
                                        }

                                        $currentPrId = $record?->id;
                                        $total = $invoices->sum(function (Invoice $invoice) use ($currentPrId) {
                                            $remainingPayable = PaymentRequest::getInvoiceRemainingPayable($invoice, $currentPrId);
                                            return PurchaseInvoiceResource::invoiceAmountToIdr($invoice, $remainingPayable);
                                        });

                                        // FIX #6: Gunakan 2 desimal agar sisa sen tidak terpotong
                                        // (number_format(..., 0) membulatkan ke bawah, sisa sen < Rp1 menggantung di AP)
                                        $set('total_amount', number_format((float) $total, 2, ',', '.'));
                                    }),
                            ]),

                        Section::make('Catatan')
                            ->schema([
                                Textarea::make('notes')
                                    ->label('Catatan Permintaan')
                                    ->rows(3)
                                    ->placeholder('Alasan atau keterangan tambahan...'),
                            ]),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('request_number')
                    ->label('Nomor PR')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('supplier.perusahaan')
                    ->label('Vendor')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('request_date')
                    ->label('Tanggal Request')
                    ->date('d/m/Y')
                    ->sortable(),

                TextColumn::make('payment_date')
                    ->label('Tgl Pembayaran')
                    ->date('d/m/Y')
                    ->sortable(),

                TextColumn::make('total_amount')
                    ->label('Total (Rp)')
                    ->money('IDR', locale: 'id')
                    ->sortable(),

                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->color(fn ($state) => PaymentRequest::STATUS_COLORS[$state] ?? 'gray')
                    ->formatStateUsing(fn ($state) => PaymentRequest::STATUS_LABELS[$state] ?? $state),

                TextColumn::make('requestedBy.name')
                    ->label('Diminta Oleh')
                    ->sortable(),

                TextColumn::make('approvedBy.name')
                    ->label('Disetujui Oleh')
                    ->default('-'),

                TextColumn::make('created_at')
                    ->label('Dibuat')
                    ->dateTime('d/m/Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('Status')
                    ->options(PaymentRequest::STATUS_LABELS),

                Tables\Filters\SelectFilter::make('supplier_id')
                    ->label('Supplier')
                    ->relationship('supplier', 'perusahaan'),
            ])
            ->actions([
                ActionGroup::make([
                    Tables\Actions\ViewAction::make(),
                    Tables\Actions\EditAction::make()
                        ->visible(fn ($record) => in_array($record->status, ['draft'])),

                    // Submit for Approval
                    Tables\Actions\Action::make('submit')
                        ->label('Ajukan Persetujuan')
                        ->icon('heroicon-o-paper-airplane')
                        ->color('warning')
                        ->visible(fn ($record) => $record->status === 'draft')
                        ->requiresConfirmation()
                        ->action(function ($record) {
                            $record->update([
                                'status' => 'pending_approval',
                                'requested_by' => Auth::id(),
                            ]);
                            Notification::make()->title('Payment Request diajukan untuk persetujuan')->success()->send();
                        }),

                    // Approve
                    Tables\Actions\Action::make('approve')
                        ->label('Setujui')
                        ->icon('heroicon-o-check-circle')
                        ->color('success')
                        ->visible(function ($record) {
                            if ($record->status !== 'pending_approval') {
                                return false;
                            }
                            $check = app(\App\Services\ApprovalControlService::class)->canApprovePaymentRequest(Auth::user(), $record);
                            return $check['allowed'];
                        })
                        ->requiresConfirmation()
                        ->form([
                            Textarea::make('approval_notes')
                                ->label('Catatan Persetujuan')
                                ->rows(2),
                        ])
                        ->action(function ($record, array $data) {
                            $check = app(\App\Services\ApprovalControlService::class)->canApprovePaymentRequest(Auth::user(), $record);
                            if (! $check['allowed']) {
                                Notification::make()->title('Akses Ditolak')->body($check['reason'])->danger()->send();
                                return;
                            }

                            $record->update([
                                'status' => 'approved',
                                'approved_by' => Auth::id(),
                                'approved_at' => now(),
                                'approval_notes' => $data['approval_notes'] ?? null,
                            ]);
                            Notification::make()->title('Payment Request disetujui')->success()->send();
                        }),

                    // Reject
                    Tables\Actions\Action::make('reject')
                        ->label('Tolak')
                        ->icon('heroicon-o-x-circle')
                        ->color('danger')
                        ->visible(fn ($record) => $record->status === 'pending_approval')
                        ->requiresConfirmation()
                        ->form([
                            Textarea::make('approval_notes')
                                ->label('Alasan Penolakan')
                                ->required()
                                ->rows(2),
                        ])
                        ->action(function ($record, array $data) {
                            $record->update([
                                'status' => 'rejected',
                                'approved_by' => Auth::id(),
                                'approved_at' => now(),
                                'approval_notes' => $data['approval_notes'],
                            ]);
                            Notification::make()->title('Payment Request ditolak')->warning()->send();
                        }),

                    Tables\Actions\DeleteAction::make()
                        ->visible(fn ($record) => $record->status === 'draft'),
                ]),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListPaymentRequests::route('/'),
            'create' => Pages\CreatePaymentRequest::route('/create'),
            'view'   => Pages\ViewPaymentRequest::route('/{record}'),
            'edit'   => Pages\EditPaymentRequest::route('/{record}/edit'),
        ];
    }
}
