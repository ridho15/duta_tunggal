<?php

namespace App\Filament\Resources;

use App\Filament\Resources\WarehouseResource\Pages;
use App\Filament\Resources\WarehouseResource\Pages\ViewWarehouse;
use App\Filament\Resources\WarehouseResource\RelationManagers;
use App\Models\Cabang;
use App\Models\Warehouse;
use App\Rules\InternationalPhoneNumber;
use App\Services\WarehouseService;
use Filament\Forms\Components\Actions\Action;
use Filament\Forms\Components\Checkbox;
use Filament\Forms\Components\ColorPicker;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\DeleteBulkAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\ColorColumn;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Tables\Enums\ActionsPosition;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class WarehouseResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = Warehouse::class;

    protected static bool $shouldRegisterNavigation = true;

    protected static ?string $navigationIcon = 'heroicon-o-building-office';

    protected static ?string $navigationGroup = 'DATA MASTER';

    protected static ?string $navigationLabel = 'Gudang & Rak';

    protected static ?string $modelLabel = 'Gudang & Rak';

    protected static ?string $pluralModelLabel = 'Gudang & Rak';

    protected static ?int $navigationSort = 4;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Fieldset::make('Form Gudang')
                    ->schema([
                        TextInput::make('kode')
                            ->label('Kode')
                            ->maxLength(20)
                            ->reactive()
                            ->unique(ignoreRecord: true)
                            ->suffixAction(Action::make('generateKodeGudang')
                                ->icon('heroicon-m-arrow-path') // ikon reload
                                ->tooltip('Generate Kode Gudang')
                                ->action(function ($set, $get, $state) {
                                    $warehouseService = app(WarehouseService::class);
                                    $set('kode', $warehouseService->generateKodeGudang());
                                }))
                            ->validationMessages([
                                'required' => 'Kode Gudang wajib diisi',
                                'unique' => 'Kode gudang sudah digunakan',
                                'max' => 'Kode gudang terlalu panjang'
                            ])
                            ->required(),
                        TextInput::make('name')
                            ->label('Nama')
                            ->validationMessages([
                                'required' => 'Nama gudang tidak boleh kosong',
                                'max' => 'Nama gudang terlalu panjang'
                            ])
                            ->maxLength(100)
                            ->required(),
                        Select::make('cabang_id')
                            ->label('Cabang')
                            ->options(Cabang::orderBy('kode')->limit(50)->get()->mapWithKeys(function ($cabang) {
                                return [$cabang->id => "({$cabang->kode}) {$cabang->nama}"];
                            }))
                            ->preload()
                            ->searchable()
                            ->visible(fn () => in_array('all', Auth::user()?->manage_type ?? []))
                            ->default(fn () => in_array('all', Auth::user()?->manage_type ?? []) ? null : Auth::user()?->cabang_id)
                            ->validationMessages([
                                'exists' => 'Cabang tidak tersedia',
                                'required' => "Cabang wajib dipilih"
                            ])
                            ->required(),
                        Radio::make('tipe')
                            ->label('Tipe')
                            ->inlineLabel()
                            ->options([
                                'Kecil' => 'Kecil',
                                'Besar' => 'Besar',
                            ])
                            ->validationMessages([
                                'required' => 'Tipe gudang belum dipilih'
                            ])
                            ->default('Kecil')
                            ->required(),
                        Textarea::make('location')
                            ->required()
                            ->validationMessages([
                                'required' => 'Alamat wajib diisi'
                            ])
                            ->label('Alamat'),
                        TextInput::make('telepon')
                            ->tel()
                            ->telRegex('/^[0-9+\s().-]*$/')
                            ->label('Telepon')
                            ->dehydrateStateUsing(fn ($state) => is_string($state) ? trim($state) : $state)
                            ->validationMessages([
                                'required' => 'Nomor Telepon tidak boleh kosong',
                                'max' => 'Nomor telepon terlalu panjang'
                            ])
                            ->helperText('Contoh : (+62) 830 9787 333, +62 812 3456 7890, 07512345678')
                            ->rules([new InternationalPhoneNumber()])
                            ->required()
                            ->maxLength(50),
                        Checkbox::make('status')
                            ->label('Status (Aktif / Tidak Aktif)')
                            ->default(false),
                        ColorPicker::make('warna_background')
                            ->label('Warna Background'),
                    ])
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                ColorColumn::make('warna_background')
                    ->label('Background'),
                TextColumn::make('kode')
                    ->label('Kode')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('name')
                    ->label('Nama')
                    ->sortable()
                    ->searchable(),
                TextColumn::make('cabang')
                    ->label('Cabang')
                    ->searchable(query: function (Builder $query, $search) {
                        $query->whereHas('cabang', function ($query) use ($search) {
                            $query->where('kode', 'LIKE', '%' . $search . '%')
                                ->orWhere('nama', 'LIKE', '%' . $search . '%');
                        });
                    })->formatStateUsing(function ($state) {
                        return "({$state->kode}) {$state->nama}";
                    }),
                TextColumn::make('tipe')
                    ->label('Tipe')
                    ->badge()
                    ->colors([
                        'info' => 'Kecil',
                        'success' => 'Besar',
                    ]),
                TextColumn::make('location')
                    ->label('Alamat')
                    ->limit(30),
                TextColumn::make('telepon')
                    ->label('Telepon'),
                IconColumn::make('status')
                    ->label('Status')
                    ->boolean(),
            ])
            ->filters([
                //
            ])
            ->actions([
                ActionGroup::make([
                    ViewAction::make()
                        ->color('primary'),
                    EditAction::make()
                        ->color('success'),
                    DeleteAction::make()
                ])
            ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            RelationManagers\RakRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListWarehouses::route('/'),
            'create' => Pages\CreateWarehouse::route('/create'),
            'view' => ViewWarehouse::route('/{record}'),
            'edit' => Pages\EditWarehouse::route('/{record}/edit'),
        ];
    }
}
