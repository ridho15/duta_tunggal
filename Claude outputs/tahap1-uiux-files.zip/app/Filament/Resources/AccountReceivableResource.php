<?php

namespace App\Filament\Resources;

use App\Enums\PaymentStatus;
use App\Filament\Resources\AccountReceivableResource\Pages;
use App\Models\Cabang;
use App\Models\AccountReceivable;
use App\Models\Customer;
use App\Models\Invoice;
use App\Support\AccountReceivableQuery;
use App\Support\OverdueStatusPresenter;
use Filament\Forms;
use Filament\Forms\Components\Checkbox;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Filament\Tables\Enums\ActionsPosition;
use Illuminate\Database\Eloquent\Builder;

class AccountReceivableResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = AccountReceivable::class;

    protected static ?string $navigationIcon = 'heroicon-o-scale';

    protected static ?string $navigationGroup = 'KEUANGAN';

    protected static ?string $navigationLabel = 'Piutang & Hutang';

    protected static ?string $modelLabel = 'Piutang & Hutang';

    protected static ?string $pluralModelLabel = 'Piutang & Hutang';

    protected static bool $shouldRegisterNavigation = true;

    protected static ?int $navigationSort = 2;

    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return false;
    }

    public static function canDelete(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return false;
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Fieldset::make('Account Receivable')
                    ->schema([
                        Select::make('cabang_id')
                            ->label('Cabang')
                            ->options(Cabang::orderBy('kode')->limit(50)->get()->mapWithKeys(function ($cabang) {
                                return [$cabang->id => "({$cabang->kode}) {$cabang->nama}"];
                            }))
                            ->default(function () {
                                return Auth::user()->cabang_id;
                            })
                            ->disabled()
                            ->required()
                            ->helperText('Pilih cabang untuk account receivable ini'),
                        Select::make('invoice_id')
                            ->required()
                            ->preload()
                            ->searchable()
                            ->disabled()
                            ->reactive()
                            ->afterStateUpdated(function ($get, $set, $state) {
                                $invoice = Invoice::find($state);
                                if ($invoice) {
                                    $set('customer_id', $invoice->fromModel->customer_id);
                                }
                            })
                            ->validationMessages([
                                'required' => 'Invoice belum dipilih'
                            ])
                            ->label('Invoice')
                            ->relationship('invoice', 'invoice_number', function (Builder $query, $get) {
                                $query->where('from_model_type', 'App\Models\SaleOrder');
                            }),
                        Select::make('customer_id')
                            ->label('Customer')
                            ->preload()
                            ->reactive()
                            ->disabled()
                            ->validationMessages([
                                'required' => 'Customer belum dipilih'
                            ])
                            ->searchable(['name', 'code'])
                            ->required()
                            ->getOptionLabelFromRecordUsing(function (Customer $customer) {
                                return "({$customer->code}) {$customer->name}";
                            })
                            ->relationship('customer', 'name'),
                        TextInput::make('total')
                            ->required()
                            ->disabled()
                            ->indonesianMoney(),
                        TextInput::make('paid')
                            ->required()
                            ->disabled()
                            ->indonesianMoney()
                            ->default(0.00),
                        TextInput::make('remaining')
                            ->required()
                            ->disabled()
                            ->indonesianMoney(),
                        Checkbox::make('status')
                            ->disabled()
                            ->label('Lunas / Belum Lunas')
                    ])
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->modifyQueryUsing(function (Builder $query) {
                return AccountReceivableQuery::withOverdueGrouping(
                    AccountReceivableQuery::base()->with(['invoice.fromModel'])
                );
            })
            ->columns([
                TextColumn::make('invoice.invoice_number')
                    ->label('Invoice Number')
                    ->searchable()
                    ->sortable()
                    ->copyable()
                    ->tooltip('Click to copy'),
                    
                TextColumn::make('customer')
                    ->formatStateUsing(function ($state) {
                        return "({$state->code}) {$state->name}";
                    })
                    ->label('Customer')
                    ->searchable(query: function (Builder $query, string $search): Builder {
                        return $query->whereHas('customer', function (Builder $query) use ($search) {
                            $query->where('code', 'like', "%{$search}%")
                                  ->orWhere('name', 'like', "%{$search}%");
                        });
                    })
                    ->sortable(),
                    
                TextColumn::make('invoice.invoice_date')
                    ->label('Invoice Date')
                    ->date('M j, Y')
                    ->sortable(),
                    
                TextColumn::make('invoice.due_date')
                    ->label('Due Date')
                    ->date('M j, Y')
                    ->sortable()
                    ->color(fn ($record) => self::overdueStatusPresenter()->dueDateColor($record)),
                    
                TextColumn::make('total')
                    ->label('Total Amount')
                    ->sortable()
                    ->searchable()
                    ->rupiah()
                    ->summarize([
                        Tables\Columns\Summarizers\Sum::make()
                            ->rupiah()
                            ->label('Total AR')
                    ]),
                    
                TextColumn::make('paid')
                    ->label('Paid Amount')
                    ->sortable()
                    ->rupiah()
                    ->color('success')
                    ->summarize([
                        Tables\Columns\Summarizers\Sum::make()
                            ->rupiah()
                            ->label('Total Paid')
                    ]),
                    
                TextColumn::make('remaining')
                    ->label('Outstanding')
                    ->sortable()
                    ->rupiah()
                    ->color(fn ($state) => $state > 0 ? 'warning' : 'success')
                    ->weight('bold')
                    ->summarize([
                        Tables\Columns\Summarizers\Sum::make()
                            ->rupiah()
                            ->label('Total Outstanding')
                    ]),
                    
                TextColumn::make('days_overdue')
                    ->label('Days Overdue')
                    ->getStateUsing(fn ($record) => self::overdueStatusPresenter()->daysOverdue($record))
                    ->color(fn ($state) => self::overdueStatusPresenter()->daysOverdueColor($state))
                    ->badge()
                    ->sortable(),
                    
                TextColumn::make('createdBy.name')
                    ->label('Created By')
                    ->searchable()
                    ->sortable()
                    ->default('System'),
                    
                TextColumn::make('invoice.fromModel.createdBy.name')
                    ->label('SO Created By')
                    ->getStateUsing(function ($record) {
                        return $record->invoice->fromModel?->createdBy?->name ?? 'System';
                    })
                    ->sortable(query: function (Builder $query, string $direction): Builder {
                        return $query->orderByRaw("
                            (SELECT name FROM users WHERE users.id = (
                                SELECT created_by FROM sale_orders WHERE sale_orders.id = invoices.from_model_id
                            )) {$direction}
                        ");
                    }),
                    
                TextColumn::make('created_at')
                    ->label('Created At')
                    ->dateTime('M j, Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                    
                TextColumn::make('updated_at')
                    ->label('Updated At')
                    ->dateTime('M j, Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('invoice.due_date', 'desc')
            ->groups([
                Tables\Grouping\Group::make('customer.name')
                    ->label('Customer')
                    ->titlePrefixedWithLabel(false)
                    ->getTitleFromRecordUsing(function ($record) {
                        return "👤 ({$record->customer->code}) {$record->customer->name}";
                    })
                    ->collapsible(),
                    
                Tables\Grouping\Group::make('status')
                    ->label('Payment Status')
                    ->titlePrefixedWithLabel(false)
                    ->getTitleFromRecordUsing(function ($record) {
                        return $record->status === PaymentStatus::PAID->value ? '✅ PAID' : '⏳ OUTSTANDING';
                    })
                    ->collapsible(),
                    
                Tables\Grouping\Group::make('overdue_group')
                    ->label('Overdue Status')
                    ->titlePrefixedWithLabel(false)
                    ->getTitleFromRecordUsing(fn ($record) => self::overdueStatusPresenter()->overdueGroupLabel($record))
                    ->collapsible(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('customer_id')
                    ->label('Customer')
                    ->relationship('customer', 'name')
                    ->searchable()
                    ->preload()
                    ->multiple()
                    ->getOptionLabelFromRecordUsing(function ($record) {
                        return "({$record->code}) {$record->name}";
                    }),
                    
                Tables\Filters\SelectFilter::make('status')
                    ->label('Payment Status')
                    ->options([
                        PaymentStatus::UNPAID->value => 'Outstanding',
                        PaymentStatus::PAID->value => 'Paid',
                    ])
                    ->multiple(),
                    
                Tables\Filters\Filter::make('amount_range')
                    ->form([
                        Forms\Components\Grid::make(2)
                            ->schema([
                                Forms\Components\TextInput::make('amount_from')
                                    ->label('Amount From')
                                    ->indonesianMoney(),
                                Forms\Components\TextInput::make('amount_to')
                                    ->label('Amount To')
                                    ->indonesianMoney(),
                            ])
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when($data['amount_from'], fn (Builder $query, $amount): Builder => 
                                $query->where('total', '>=', $amount))
                            ->when($data['amount_to'], fn (Builder $query, $amount): Builder => 
                                $query->where('total', '<=', $amount));
                    })
                    ->indicateUsing(function (array $data): array {
                        $indicators = [];
                        if ($data['amount_from'] ?? null) {
                            $indicators['amount_from'] = 'Amount from: Rp ' . number_format($data['amount_from']);
                        }
                        if ($data['amount_to'] ?? null) {
                            $indicators['amount_to'] = 'Amount to: Rp ' . number_format($data['amount_to']);
                        }
                        return $indicators;
                    }),
                    
                Tables\Filters\Filter::make('outstanding_only')
                    ->label('Outstanding Only')
                    ->query(fn (Builder $query): Builder => $query->where('remaining', '>', 0))
                    ->toggle(),
                    
                Tables\Filters\Filter::make('overdue')
                    ->label('Overdue Invoices')
                    ->query(fn (Builder $query): Builder => AccountReceivableQuery::applyOverdueFilter($query))
                    ->toggle(),

                Tables\Filters\SelectFilter::make('overdue_days')
                    ->label('Overdue Period')
                    ->options([
                        '1-30' => '1-30 Days',
                        '31-60' => '31-60 Days',
                        '60+' => '60+ Days',
                    ])
                    ->query(function (Builder $query, $data) {
                        if (!$data['value']) {
                            return $query;
                        }

                        return AccountReceivableQuery::applyOverdueDaysFilter($query, $data['value']);
                    }),
                    
                Tables\Filters\Filter::make('date_range')
                    ->form([
                        Forms\Components\Grid::make(2)
                            ->schema([
                                Forms\Components\DatePicker::make('created_from')
                                    ->label('Start Date'),
                                Forms\Components\DatePicker::make('created_until')
                                    ->label('End Date'),
                            ])
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when($data['created_from'], fn (Builder $query, $date): Builder => 
                                $query->whereDate('created_at', '>=', $date))
                            ->when($data['created_until'], fn (Builder $query, $date): Builder => 
                                $query->whereDate('created_at', '<=', $date));
                    })
                    ->indicateUsing(function (array $data): array {
                        $indicators = [];
                        if ($data['created_from'] ?? null) {
                            $indicators['created_from'] = 'Created from: ' . \Carbon\Carbon::parse($data['created_from'])->toFormattedDateString();
                        }
                        if ($data['created_until'] ?? null) {
                            $indicators['created_until'] = 'Created until: ' . \Carbon\Carbon::parse($data['created_until'])->toFormattedDateString();
                        }
                        return $indicators;
                    }),
                    
                Tables\Filters\Filter::make('due_date_range')
                    ->form([
                        Forms\Components\Grid::make(2)
                            ->schema([
                                Forms\Components\DatePicker::make('due_from')
                                    ->label('Due From'),
                                Forms\Components\DatePicker::make('due_until')
                                    ->label('Due Until'),
                            ])
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query->whereHas('invoice', function (Builder $query) use ($data) {
                            $query->when($data['due_from'], fn (Builder $query, $date): Builder => 
                                    $query->whereDate('due_date', '>=', $date))
                                ->when($data['due_until'], fn (Builder $query, $date): Builder => 
                                    $query->whereDate('due_date', '<=', $date));
                        });
                    })
                    ->indicateUsing(function (array $data): array {
                        $indicators = [];
                        if ($data['due_from'] ?? null) {
                            $indicators['due_from'] = 'Due from: ' . \Carbon\Carbon::parse($data['due_from'])->toFormattedDateString();
                        }
                        if ($data['due_until'] ?? null) {
                            $indicators['due_until'] = 'Due until: ' . \Carbon\Carbon::parse($data['due_until'])->toFormattedDateString();
                        }
                        return $indicators;
                    }),
                    
                Tables\Filters\Filter::make('invoice_date_range')
                    ->form([
                        Forms\Components\Grid::make(2)
                            ->schema([
                                Forms\Components\DatePicker::make('invoice_from')
                                    ->label('Invoice Date From'),
                                Forms\Components\DatePicker::make('invoice_until')
                                    ->label('Invoice Date Until'),
                            ])
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query->whereHas('invoice', function (Builder $query) use ($data) {
                            $query->when($data['invoice_from'], fn (Builder $query, $date): Builder => 
                                    $query->whereDate('invoice_date', '>=', $date))
                                ->when($data['invoice_until'], fn (Builder $query, $date): Builder => 
                                    $query->whereDate('invoice_date', '<=', $date));
                        });
                    })
                    ->indicateUsing(function (array $data): array {
                        $indicators = [];
                        if ($data['invoice_from'] ?? null) {
                            $indicators['invoice_from'] = 'Invoice from: ' . \Carbon\Carbon::parse($data['invoice_from'])->toFormattedDateString();
                        }
                        if ($data['invoice_until'] ?? null) {
                            $indicators['invoice_until'] = 'Invoice until: ' . \Carbon\Carbon::parse($data['invoice_until'])->toFormattedDateString();
                        }
                        return $indicators;
                    }),
            ])
            ->actions([
                ActionGroup::make([
                    ViewAction::make()
                        ->color('primary'),
                ])->button()
                    ->label('Action')
            ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([])
            ->description(new \Illuminate\Support\HtmlString(
                '<details class="mb-4">' .
                    '<summary class="cursor-pointer font-semibold">Panduan Account Receivable</summary>' .
                    '<div class="mt-2 text-sm">' .
                        '<ul class="list-disc pl-5">' .
                            '<li><strong>Apa ini:</strong> Account Receivable adalah catatan piutang perusahaan dari customer berdasarkan invoice penjualan yang belum dibayar.</li>' .
                            '<li><strong>Status:</strong> <em>Belum Lunas</em> (outstanding), <em>Lunas</em> (paid). Hanya menampilkan yang belum lunas secara default.</li>' .
                            '<li><strong>Imutabilitas:</strong> Piutang Usaha dimutasi otomatis oleh sistem (Invoice, Pembayaran, Retur). Tidak dapat ditambah, diubah, atau dihapus manual.</li>' .
                            '<li><strong>Grouping:</strong> Berdasarkan Customer, Status Pembayaran, dan Status Overdue (Current, Overdue, dll.).</li>' .
                            '<li><strong>Filters:</strong> Customer, Status, Amount Range, Outstanding Only, Overdue, Date Range, dll.</li>' .
                            '<li><strong>Permissions:</strong> Tergantung pada cabang user, hanya menampilkan AR dari cabang tersebut jika tidak memiliki akses all.</li>' .
                        '</ul>' .
                    '</div>' .
                '</details>'
            ));
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAccountReceivables::route('/'),
            'view' => Pages\ViewAccountReceivable::route('/{record}'),
        ];
    }

    public static function overdueStatusPresenter(): OverdueStatusPresenter
    {
        return app(OverdueStatusPresenter::class);
    }
}
