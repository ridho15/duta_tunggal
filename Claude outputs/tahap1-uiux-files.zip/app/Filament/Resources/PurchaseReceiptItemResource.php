<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PurchaseReceiptItemResource\Pages;
use App\Http\Controllers\HelperController;
use App\Models\Product;
use App\Models\PurchaseOrderItem;
use App\Models\PurchaseReceiptItem;
use App\Models\User;
use App\Models\InventoryStock;
use App\Services\QualityControlService;
use App\Services\ProductService;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Actions\Action;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Columns\ImageColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Tables\Enums\ActionsPosition;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class PurchaseReceiptItemResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = PurchaseReceiptItem::class;

    protected static ?string $navigationIcon = 'heroicon-o-chevron-up-down';

    // Put Purchase Receipt Item under the Purchase Order group
    protected static ?string $navigationGroup = 'Pembelian';

    protected static ?int $navigationSort = 6;

    public static function shouldRegisterNavigation(): bool
    {
        return false;
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Fieldset::make()
                    ->schema([
                        Select::make('purchase_receipt_id')
                            ->label('Purchase Receipt')
                            ->preload()
                            ->searchable()
                            ->relationship('purchaseReceipt', 'receipt_number')
                            ->required(),
                        Select::make('product_id')
                            ->label('Product')
                            ->preload()
                            ->searchable()
                            ->relationship('product', 'id')
                            ->getOptionLabelFromRecordUsing(function (Product $product) {
                                return "({$product->sku}) {$product->name}";
                            })
                            ->required(),
                        TextInput::make('qty_received')
                            ->required()
                            ->numeric()
                            ->default(0),
                        TextInput::make('qty_accepted')
                            ->required()
                            ->numeric()
                            ->default(0),
                        TextInput::make('qty_rejected')
                            ->required()
                            ->numeric()
                            ->default(0),
                        Textarea::make('reason_rejected'),
                        Select::make('warehouse_id')
                            ->label('Warehouse')
                            ->options(function () {
                                $user = Auth::user();
                                $manageType = $user?->manage_type ?? [];
                                $query = \App\Models\Warehouse::where('status', true);
                                
                                if (!$user || !is_array($manageType) || !in_array('all', $manageType)) {
                                    $query->where('cabang_id', $user?->cabang_id);
                                }
                                
                                return $query->get()->mapWithKeys(function ($warehouse) {
                                    return [$warehouse->id => "({$warehouse->kode}) {$warehouse->name}"];
                                });
                            })
                            ->preload()
                            ->reactive()
                            ->searchable()
                            ->getSearchResultsUsing(function (string $search) {
                                $user = Auth::user();
                                $manageType = $user?->manage_type ?? [];
                                $query = \App\Models\Warehouse::where('status', true)
                                    ->where(function ($q) use ($search) {
                                        $q->where('name', 'like', "%{$search}%")
                                          ->orWhere('kode', 'like', "%{$search}%");
                                    });
                                
                                if (!$user || !is_array($manageType) || !in_array('all', $manageType)) {
                                    $query->where('cabang_id', $user?->cabang_id);
                                }
                                
                                return $query->limit(50)->get()->mapWithKeys(function ($warehouse) {
                                    return [$warehouse->id => "({$warehouse->kode}) {$warehouse->name}"];
                                });
                            })
                            ->required(),
                        Select::make('purchase_order_item_id')
                            ->label('Purchase Order')
                            ->preload()
                            ->searchable()
                            ->relationship('purchaseOrderItem', 'id')
                            ->getOptionLabelFromRecordUsing(function (PurchaseOrderItem $purchaseOrderItem) {
                                return "({$purchaseOrderItem->purchaseOrder->po_number}) - ({$purchaseOrderItem->product->sku}) {$purchaseOrderItem->product->sku}";
                            })
                            ->nullable(),
                        Select::make('rak_id')
                            ->label('Rak')
                            ->preload()
                            ->searchable()
                            ->relationship('rak', 'name', function ($get, Builder $query) {
                                return $query->where('warehouse_id', $get('warehouse_id'));
                            })
                            ->nullable(),
                        Repeater::make('purchaseReceiptItemPhoto')
                            ->relationship()
                            ->addActionLabel('Tambah Photo')
                            ->schema([
                                FileUpload::make('photo_url')
                                    ->label('Photo')
                                    ->image()
                                    ->maxSize(1024)
                                    ->required(),
                            ]),
                    ])
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                TextColumn::make('is_sent')
                    ->label('Status Stock')
                    ->badge()
                    ->color(function ($state) {
                        if ($state == 0) {
                            return 'gray';
                        } else {
                            return 'success';
                        }
                    })
                    ->formatStateUsing(function ($state) {
                        if ($state == 1) {
                            return "Sudah Masuk Stock";
                        } else {
                            return "Belum Masuk Stock";
                        }
                    }),
                TextColumn::make('purchaseReceipt.receipt_number')
                    ->label('Receipt Number')
                    ->searchable(),
                TextColumn::make('product')
                    ->label('Product')
                    ->searchable(query: function (Builder $query, $search) {
                        $query->whereHas('product', function (Builder $query) use ($search) {
                            $query->where('sku', 'LIKE', '%' . $search . '%')
                                ->orWhere('name', 'LIKE', '%' . $search . '%');
                        });
                    })->formatStateUsing(function ($state) {
                        return "({$state->sku}) {$state->name}";
                    }),
                TextColumn::make('qty_received')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('qty_accepted')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('qty_rejected')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('warehouse.name')
                    ->label('Warehouse')
                    ->searchable(),
                TextColumn::make('rak.name')
                    ->label('Rak')
                    ->searchable(),
                TextColumn::make('rak.name')
                    ->searchable()
                    ->label('Rak'),
                ImageColumn::make('purchaseReceiptItemPhoto.photo_url')
                    ->label('Photo')
                    ->circular()
                    ->stacked()
                    ->size(75),
                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('deleted_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),

            ])
            ->filters([
                //
            ])
            ->actions([
                EditAction::make()
                    ->color('success')
                    ->hidden(function ($record) {
                        return $record->is_sent == 1 || $record->qualityControl()->where('status', 1)->exists();
                    }),
            ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPurchaseReceiptItems::route('/'),
            // 'create' => Pages\CreatePurchaseReceiptItem::route('/create'),
            // 'edit' => Pages\EditPurchaseReceiptItem::route('/{record}/edit'),
        ];
    }
}
