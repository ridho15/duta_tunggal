<?php

namespace App\Filament\Resources;

use App\Filament\Resources\VendorPaymentResource\Pages;
use App\Helpers\MoneyHelper;
use App\Support\ProcurementFailureNotifier;
use App\Support\VendorPaymentAccounts;
use App\Models\ChartOfAccount;
use App\Models\Invoice;
use App\Models\PaymentRequest;
use App\Models\Supplier;
use App\Models\VendorPayment;
use App\Models\VendorPaymentDetail;
use Filament\Forms\Components\Actions\Action;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Enums\ActionsPosition;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Log;
use Filament\Tables\Actions\ActionGroup;

class VendorPaymentResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = VendorPayment::class;

    protected static ?string $navigationIcon = 'heroicon-o-credit-card';

    protected static ?string $navigationGroup = 'PEMBELIAN';

    protected static ?string $navigationLabel = 'Bayar Supplier';

    protected static ?string $modelLabel = 'Bayar Supplier';

    protected static ?string $pluralModelLabel = 'Bayar Supplier';

    protected static ?int $navigationSort = 4;

    protected static bool $shouldRegisterNavigation = true;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('Vendor Payment')
                    ->schema([
                        // Payment Request Reference (Task 15c)
                        Section::make('Referensi Payment Request')
                            ->description('Vendor Payment harus mengacu pada Payment Request yang sudah disetujui')
                            ->schema([
                                Select::make('payment_request_id')
                                    ->label('Payment Request (PR)')
                                    ->options(function () {
                                        // Show approved and partially-paid PRs (exclude fully paid).
                                        return PaymentRequest::whereIn('status', [PaymentRequest::STATUS_APPROVED, PaymentRequest::STATUS_PARTIAL])
                                            ->with('supplier')
                                            ->get()
                                            ->mapWithKeys(function ($pr) {
                                                return [$pr->id => "{$pr->request_number} - {$pr->supplier->perusahaan} (" . MoneyHelper::rupiah($pr->total_amount) . ")"];
                                            });
                                    })
                                    ->searchable()
                                    ->required()
                                    ->reactive()
                                    ->helperText('Pilih Payment Request yang sudah disetujui. Invoice yang ditampilkan hanya berasal dari Payment Request yang dipilih.')
                                    ->afterStateUpdated(function ($set, $get, $state) {
                                        if (!$state) {
                                            $set('supplier_id', null);
                                            $set('selected_invoices', []);
                                            $set('total_payment', self::formatMoneyState(0));
                                            $set('payment_details', []);
                                            return;
                                        }
                                        $pr = PaymentRequest::with('supplier')->find($state);
                                        if ($pr) {
                                            $set('supplier_id', $pr->supplier_id);
                                            // Pre-select only invoices that still have remaining payable
                                            $prInvoiceIds = $pr->selected_invoices ?? [];
                                            $eligibleInvoices = empty($prInvoiceIds)
                                                ? collect()
                                                : Invoice::whereIn('id', $prInvoiceIds)->where('status', '!=', Invoice::STATUS_CANCELLED)->with('accountPayable')->get()
                                                    ->filter(fn ($invoice) => ((float)($invoice->accountPayable->remaining ?? $invoice->total)) > 0);

                                            $set('selected_invoices', $eligibleInvoices->pluck('id')->values()->toArray());
                                            // Calculate total from PR invoices
                                            if (!empty($prInvoiceIds)) {
                                                $invoices = $eligibleInvoices;
                                                $total = self::calculateSelectedInvoiceTotal($invoices);
                                                $set('total_payment', self::formatMoneyState($total));
                                                $set('payment_details', self::buildPaymentDetails($invoices));
                                            } else {
                                                $set('payment_details', []);
                                            }
                                        }
                                    }),
                            ])
                            ->collapsible(),

                        // Header Section - Payment Number, Branch, Vendor, and Date
                        Section::make()
                            ->columns(3)
                            ->schema([
                                TextInput::make('payment_number')
                                    ->label('Nomor Pembayaran (VP)')
                                    ->placeholder('Otomatis: VP-YYYYMM-XXXX')
                                    ->readOnly()
                                    ->columnSpan(1),

                                Select::make('cabang_id')
                                    ->label('Cabang Operasional')
                                    ->options(fn () => \App\Models\Cabang::pluck('nama', 'id'))
                                    ->searchable()
                                    ->nullable()
                                    ->columnSpan(1),

                                DatePicker::make('payment_date')
                                    ->label('Payment Date')
                                    ->required()
                                    ->default(now())
                                    ->validationMessages([
                                        'required' => 'Tanggal pembayaran belum diisi'
                                    ])
                                    ->columnSpan(1),

                                Select::make('supplier_id')
                                    ->label('Vendor')
                                    ->options(function () {
                                        return Supplier::orderBy('perusahaan')->limit(50)->get()->mapWithKeys(function ($supplier) {
                                            return [$supplier->id => "({$supplier->code}) {$supplier->perusahaan}"];
                                        })->toArray();
                                    })
                                    ->preload()
                                    ->searchable()
                                    ->reactive()
                                    ->disabled(fn($get) => !empty($get('payment_request_id')))
                                    ->dehydrated(true)
                                    ->helperText(fn($get) => !empty($get('payment_request_id')) ? 'Vendor otomatis terisi dari Payment Request.' : null)
                                    ->validationMessages([
                                        'required' => 'Supplier belum dipilih'
                                    ])
                                    ->afterStateUpdated(function ($set, $get, $state) {
                                        // Only reset if no payment_request_id is selected
                                        if (empty($get('payment_request_id'))) {
                                            $set('selected_invoices', []);
                                            $set('total_payment', self::formatMoneyState(0));
                                            $set('payment_details', []);
                                        }

                                        // Auto prefill target bank account from supplier master
                                        if ($state) {
                                            $supplier = Supplier::find($state);
                                            if ($supplier) {
                                                $bankName = $supplier->nama_bank ?? $supplier->bank_name ?? '';
                                                $bankNum = $supplier->nomor_rekening ?? $supplier->rekening_bank ?? '';
                                                $holder = $supplier->nama_rekening ?? $supplier->atas_nama ?? $supplier->perusahaan ?? '';
                                                if ($bankNum || $bankName) {
                                                    $set('target_bank_account', trim("{$bankName} - {$bankNum} (a.n. {$holder})", ' -()'));
                                                }
                                            }
                                        }
                                    })
                                    ->columnSpan(3)
                                    ->required(),
                            ]),

                        // Invoice Selection Section
                        Section::make('Pilih Invoice')
                            ->schema([
                                Hidden::make('is_processing_invoices')
                                    ->default(false)
                                    ->reactive(),
                                Hidden::make('has_invoices')
                                    ->default(false)
                                    ->reactive(),
                                Hidden::make('force_section_update')
                                    ->default(false)
                                    ->reactive(),
                                CheckboxList::make('selected_invoices')
                                    ->label('Pilih Invoice')
                                    ->options(function ($get, $set) {
                                        $paymentRequestId = $get('payment_request_id');

                                        if (!$paymentRequestId) {
                                            $set('has_invoices', false);
                                            return [];
                                        }

                                        try {
                                            $pr = PaymentRequest::find($paymentRequestId);
                                            $prInvoiceIds = $pr ? ($pr->selected_invoices ?? []) : [];

                                            if (empty($prInvoiceIds)) {
                                                $set('has_invoices', false);
                                                return [];
                                            }

                                            $invoices = Invoice::whereIn('id', $prInvoiceIds)->where('status', '!=', Invoice::STATUS_CANCELLED)
                                                ->with(['accountPayable'])
                                                ->get();

                                            $options = [];
                                            foreach ($invoices as $invoice) {
                                                $remaining = self::resolveInvoiceRemainingAmount($invoice);
                                                $statusText = $remaining <= 0 ? ' (SUDAH LUNAS)' : '';

                                                $invDate = $invoice->invoice_date ? $invoice->invoice_date->format('Y-m-d') : '-';
                                                $dueDate = $invoice->due_date ? $invoice->due_date->format('Y-m-d') : '-';
                                                $options[$invoice->id] = "Invoice {$invoice->invoice_number} ({$invDate}) - Total: "
                                                    . PurchaseInvoiceResource::formatInvoiceCurrencyPair($invoice, $invoice->total)
                                                    . " - Sisa: " . PurchaseInvoiceResource::formatInvoiceCurrencyPair($invoice, $remaining)
                                                    . " - Due: {$dueDate}" . $statusText;
                                            }

                                            $set('has_invoices', !empty($options));
                                            return $options;
                                        } catch (\Throwable $exception) {
                                            $set('has_invoices', false);
                                            Log::warning('VendorPaymentResource: gagal memuat daftar invoice', [
                                                'payment_request_id' => $paymentRequestId,
                                                'error' => $exception->getMessage(),
                                            ]);
                                            ProcurementFailureNotifier::warning(
                                                'Gagal Memuat Daftar Invoice',
                                                $exception,
                                                'Daftar invoice supplier belum berhasil dimuat. Coba pilih ulang payment request atau refresh halaman.'
                                            );
                                            return [];
                                        }
                                    })
                                    ->disableOptionWhen(function ($value, $get) {
                                        $paymentRequestId = $get('payment_request_id');
                                        if (!$paymentRequestId) {
                                            return false;
                                        }

                                        $pr = PaymentRequest::find($paymentRequestId);
                                        $prInvoiceIds = $pr ? ($pr->selected_invoices ?? []) : [];
                                        if (empty($prInvoiceIds)) {
                                            return false;
                                        }

                                        $invoice = Invoice::whereIn('id', $prInvoiceIds)->where('status', '!=', Invoice::STATUS_CANCELLED)
                                            ->with('accountPayable')
                                            ->find((int)$value);

                                        if (!$invoice) {
                                            return false;
                                        }

                                        $remaining = self::resolveInvoiceRemainingAmount($invoice);
                                        return $remaining <= 0;
                                    })
                                    ->visible(fn($get) => !empty($get('supplier_id')))
                                    ->helperText(function ($get) {
                                        $paymentRequestId = $get('payment_request_id');
                                        if (!$paymentRequestId) {
                                            return 'Pilih Payment Request terlebih dahulu untuk melihat invoice yang tersedia.';
                                        }

                                        $hasInvoices = $get('has_invoices');
                                        if ($hasInvoices === false) {
                                            return 'Tidak ada invoice yang tersedia pada Payment Request ini.';
                                        }

                                        return 'Pilih invoice dari Payment Request ini untuk diproses pembayarannya.';
                                    })
                                    ->reactive()
                                    ->live()
                                    ->disabled(fn($get) => $get('is_processing_invoices'))
                                    ->afterStateUpdated(function ($state, $set, $get) {
                                        // Set loading state to show processing indicator
                                        $set('is_processing_invoices', true);

                                        // CheckboxList returns array of selected invoice IDs directly
                                        $invoiceIds = is_array($state) ? array_map('intval', $state) : [];

                                        \Illuminate\Support\Facades\Log::info('CheckboxList afterStateUpdated', [
                                            'selected_invoice_ids' => $invoiceIds,
                                            'supplier_id' => $get('supplier_id'),
                                        ]);

                                        // Calculate total payment based on selected invoices
                                        if (empty($invoiceIds)) {
                                            $set('total_payment', self::formatMoneyState(0));
                                            $set('payment_details', []);
                                            $set('force_section_update', false); // Reset force update
                                            \Illuminate\Support\Facades\Log::info('No invoices selected, resetting totals');
                                            $set('is_processing_invoices', false);
                                            return;
                                        }

                                        try {
                                            $invoices = Invoice::whereIn('id', $invoiceIds)->where('status', '!=', Invoice::STATUS_CANCELLED)
                                                ->with('accountPayable')
                                                ->get();

                                            \Illuminate\Support\Facades\Log::info('Fetched invoices for payment calculation', [
                                                'invoice_count' => $invoices->count(),
                                                'invoices' => $invoices->map(function ($invoice) {
                                                    return [
                                                        'id' => $invoice->id,
                                                        'number' => $invoice->invoice_number,
                                                        'total' => $invoice->total,
                                                        'remaining' => self::resolveInvoiceRemainingAmount($invoice),
                                                    ];
                                                })->toArray(),
                                            ]);

                                            $total = self::calculateSelectedInvoiceTotal($invoices);

                                            $set('total_payment', self::formatMoneyState($total));

                                            // Set payment details for each selected invoice
                                            $paymentDetails = self::buildPaymentDetails($invoices);

                                            $set('payment_details', $paymentDetails);
                                            \Illuminate\Support\Facades\Log::info('Payment details set successfully', [
                                                'total_payment' => $total,
                                                'payment_details_count' => count($paymentDetails),
                                            ]);
                                        } catch (\Throwable $exception) {
                                            Log::error('VendorPaymentResource invoice selection processing failed', [
                                                'error' => $exception->getMessage(),
                                                'trace' => $exception->getTraceAsString(),
                                                'invoice_ids' => $invoiceIds,
                                            ]);
                                            $set('total_payment', self::formatMoneyState(0));
                                            $set('payment_details', []);
                                            ProcurementFailureNotifier::warning(
                                                'Gagal Memuat Detail Invoice',
                                                $exception,
                                                'Detail invoice yang dipilih belum berhasil diproses. Periksa invoice yang dipilih lalu coba lagi.'
                                            );
                                        }

                                        // End loading state and force section re-render
                                        $set('is_processing_invoices', false);
                                        $set('force_section_update', !$get('force_section_update'));
                                    })
                                        ->columns(1)
                                    ->searchable(),
                            ]),

                        // Payment Details per Invoice Section
                        Section::make('Detail Pembayaran per Invoice')
                            ->description(function ($get) {
                                $selected = $get('selected_invoices');
                                $isProcessing = $get('is_processing_invoices');

                                if ($isProcessing) {
                                    return 'Memproses pilihan invoice...';
                                }

                                if (!empty($selected) && (is_array($selected) ? count($selected) > 0 : true)) {
                                    $count = is_array($selected) ? count($selected) : 1;
                                    return "Tentukan jumlah pembayaran untuk {$count} invoice yang dipilih";
                                }
                                return 'Tentukan jumlah pembayaran untuk setiap invoice yang dipilih';
                            })
                            ->visible(function ($get) {
                                $selected = $get('selected_invoices');
                                $forceUpdate = $get('force_section_update'); // Add dependency
                                $isVisible = !empty($selected) && (is_array($selected) ? count($selected) > 0 : true);

                                \Illuminate\Support\Facades\Log::info('Section visibility check', [
                                    'selected_invoices' => $selected,
                                    'is_visible' => $isVisible,
                                    'force_update' => $forceUpdate,
                                    'type' => gettype($selected),
                                    'count' => is_array($selected) ? count($selected) : 'not_array'
                                ]);

                                return $isVisible;
                            })
                            ->reactive()
                            ->live()
                            ->schema([
                                Placeholder::make('processing_invoice_selection')
                                    ->label('')
                                    ->content(new \Illuminate\Support\HtmlString('
                                        <div class="flex items-center justify-center space-x-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                                            <svg class="animate-spin h-6 w-6 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                                                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                            <div class="text-blue-800 font-medium">
                                                Memproses pilihan invoice, mohon tunggu...
                                            </div>
                                        </div>
                                    '))
                                    ->visible(fn($get) => $get('is_processing_invoices')),
                                Placeholder::make('loading_payment_details')
                                    ->label('')
                                    ->content('Memproses detail pembayaran...')
                                    ->visible(fn($get) => !empty($get('selected_invoices')) && empty($get('payment_details')) && !$get('is_processing_invoices')),
                                Repeater::make('payment_details')
                                    ->label('')
                                    ->reactive()
                                    ->visible(fn($get) => !empty($get('payment_details')) && !$get('is_processing_invoices'))
                                    ->disabled(fn($get) => $get('is_processing_invoices'))
                                    ->schema([
                                        TextInput::make('invoice_number')
                                            ->label('No. Invoice')
                                            ->readonly()
                                            ->columnSpan(1),
                                        TextInput::make('invoice_date')
                                            ->label('Tgl Invoice')
                                            ->readonly()
                                            ->columnSpan(1),
                                        TextInput::make('due_date')
                                            ->label('Due Date')
                                            ->readonly()
                                            ->columnSpan(1),
                                        TextInput::make('total_invoice')
                                            ->label('Total Invoice Source')
                                            ->readonly()
                                            ->indonesianMoney()
                                            ->helperText(fn ($get) => $get('total_invoice_display') ?: null)
                                            ->columnSpan(1),
                                        TextInput::make('remaining_amount')
                                            ->label('Sisa Hutang Source')
                                            ->readonly()
                                            ->indonesianMoney()
                                            ->helperText(fn ($get) => $get('remaining_amount_display') ?: null)
                                            ->columnSpan(1),
                                        TextInput::make('payment_amount')
                                            ->label('Jumlah Pembayaran Source')
                                            ->indonesianMoney()
                                            ->live(debounce: 500)
                                            ->required()
                                            ->helperText(fn ($get) => $get('remaining_amount')
                                                ? 'Maks: ' . ($get('remaining_amount_display') ?: MoneyHelper::rupiah($get('remaining_amount') ?? 0))
                                                : null
                                            )
                                            ->rules([function (Get $get) {
                                                return function ($attribute, $value, $fail) use ($get) {
                                                    $remaining = \App\Helpers\MoneyHelper::safeParse($get('remaining_amount') ?? 0);
                                                    $paid = \App\Helpers\MoneyHelper::safeParse($value ?? 0);
                                                    if ($paid > $remaining + 1.00) { // 1.00 tolerance for rupiah rounding
                                                        $fail('Jumlah pembayaran tidak boleh melebihi sisa hutang (' . ($get('remaining_amount_display') ?: MoneyHelper::rupiah($remaining)) . ').');
                                                    }
                                                };
                                            }])
                                            ->placeholder(function ($get) {
                                                $selectedInvoices = $get('../../selected_invoices');
                                                if (!empty($selectedInvoices)) {
                                                    return 'Masukkan jumlah pembayaran...';
                                                }
                                                return 'Pilih invoice terlebih dahulu';
                                            })
                                            ->validationMessages([
                                                'required' => 'Jumlah pembayaran harus diisi',
                                                'numeric' => 'Jumlah pembayaran harus berupa angka'
                                            ])
                                            ->afterStateUpdated(function ($set, $get, $state) {
                                                // Recalculate total payment when any payment amount changes
                                                // Use relative path to access repeater data from within repeater field
                                                $paymentDetails = $get('../../payment_details') ?? [];

                                                $totalPayment = 0;
                                                if (is_array($paymentDetails)) {
                                                    foreach ($paymentDetails as $detail) {
                                                        $amount = 0;
                                                        if (is_array($detail) && isset($detail['payment_amount'])) {
                                                            $amount = \App\Helpers\MoneyHelper::safeParse($detail['payment_amount'] ?? 0);
                                                        } elseif (is_object($detail) && isset($detail->payment_amount)) {
                                                            $amount = \App\Helpers\MoneyHelper::safeParse($detail->payment_amount ?? 0);
                                                        }
                                                        $totalPayment += $amount;
                                                    }
                                                }

                                                $set('../../total_payment', self::formatMoneyState($totalPayment));

                                                \Illuminate\Support\Facades\Log::info('Payment amount updated, recalculating total', [
                                                    'new_payment_amount' => $state,
                                                    'total_payment' => $totalPayment,
                                                    'payment_details_count' => count($paymentDetails),
                                                ]);
                                            })
                                            ->columnSpan(1),
                                        Hidden::make('invoice_id'),
                                        Hidden::make('total_invoice_display')->dehydrated(false),
                                        Hidden::make('remaining_amount_display')->dehydrated(false),
                                    ])
                                    ->columns(1)
                                    ->columnSpanFull()
                                    ->addable(false)
                                    ->deletable(false)
                                    ->reorderable(false)
                                    ->default([])
                                    ->key(fn($get) => md5(json_encode($get('payment_details') ?? []))),
                            ]),

                            // Notes and Payment Method Section
                        Section::make()
                            ->columns(2)
                            ->schema([
                                Textarea::make('notes')
                                    ->label('Catatan')
                                    ->rows(3)
                                    ->columnSpan(1),

                                Radio::make('payment_method')
                                    ->label('Payment Method')
                                    ->inline()
                                    ->required()
                                    ->reactive()
                                    ->afterStateUpdated(function ($set, $get, $state) {
                                        $set('coa_id', VendorPaymentAccounts::defaultId($state));
                                    })
                                    ->options([
                                        'Cash' => 'Cash',
                                        'Bank Transfer' => 'Bank Transfer',
                                        'Credit' => 'Credit',
                                        'Deposit' => 'Deposit'
                                    ])
                                    ->columnSpan(1),
                            ]),

                        // Bank Account & Transfer Reference
                        Section::make('Informasi Bank & Bukti Transfer')
                            ->columns(3)
                            ->schema([
                                TextInput::make('target_bank_account')
                                    ->label('Rekening Bank Tujuan (Vendor)')
                                    ->placeholder('Contoh: BCA - 1234567890 (a.n. PT Supplier)')
                                    ->required(fn(Get $get) => in_array($get('payment_method'), ['Bank Transfer', 'Transfer']))
                                    ->helperText('Nomor rekening bank tujuan supplier. Wajib untuk metode Transfer.')
                                    ->columnSpan(1),

                                TextInput::make('transfer_reference_number')
                                    ->label('No. Referensi Transfer / Bukti Bank')
                                    ->placeholder('Contoh: TRF-20260918-0012')
                                    ->required(fn(Get $get) => in_array($get('payment_method'), ['Bank Transfer', 'Transfer']))
                                    ->helperText('Nomor referensi atau bukti transfer bank. Wajib untuk metode Transfer.')
                                    ->columnSpan(1),

                                FileUpload::make('proof_file')
                                    ->label('Unggah Bukti Transfer')
                                    ->disk('public')
                                    ->directory('vendor-payments/proofs')
                                    ->acceptedFileTypes(['image/*', 'application/pdf'])
                                    ->maxSize(10240)
                                    ->openable()
                                    ->downloadable()
                                    ->previewable()
                                    ->helperText('Unggah berkas bukti resi transfer (PDF atau Gambar).')
                                    ->columnSpan(1),
                            ]),

                        // Payment Details Section
                        Section::make()
                            ->columns(3)
                            ->schema([
                                TextInput::make('ntpn')
                                    ->label('NTPN')
                                    ->placeholder('Masukkan NTPN (opsional, untuk pembayaran impor)')
                                    ->nullable()
                                    ->maxLength(255)
                                    ->helperText('NTPN hanya diisi untuk pembayaran impor. Input manual, tidak dapat digenerate.'),
                                Placeholder::make('calculating_total')
                                    ->label('Total Pembayaran')
                                    ->content('Menghitung total pembayaran...')
                                    ->visible(fn($get) => !empty($get('selected_invoices')) && MoneyHelper::safeParse($get('total_payment') ?? 0) === 0.0)
                                    ->columnSpan(1),

                                TextInput::make('total_payment')
                                    ->label('Total Pembayaran Source')
                                    ->required()
                                    ->indonesianMoney()
                                    ->reactive()
                                    ->readOnly() // Make it read-only since it's calculated automatically
                                    ->default(0)
                                    ->visible(fn($get) => MoneyHelper::safeParse($get('total_payment') ?? 0) > 0)
                                    ->extraAttributes([
                                        'class' => 'auto-calculated-field',
                                        'data-field' => 'total_payment'
                                    ])
                                    ->helperText(function ($get) {
                                        $invoiceIds = $get('selected_invoices');
                                        $invoice = is_array($invoiceIds) && !empty($invoiceIds)
                                            ? Invoice::find((int) reset($invoiceIds))
                                            : null;

                                        return $invoice
                                            ? 'Total ini dihitung otomatis: ' . PurchaseInvoiceResource::formatInvoiceCurrencyPair($invoice, $get('total_payment'))
                                            : 'Total ini dihitung otomatis berdasarkan invoice yang dipilih';
                                    }),

                                Select::make('coa_id')
                                    ->label('COA')
                                    ->options(fn ($get) => VendorPaymentAccounts::options($get('payment_method')))
                                    ->preload()
                                    ->searchable()
                                    ->reactive()
                                    ->extraAttributes([
                                        'id' => 'main-coa-field'
                                    ])
                                    ->helperText('COA akan otomatis ter-select berdasarkan metode pembayaran, namun masih bisa diubah secara manual')
                                    ->validationMessages([
                                        'required' => 'COA belum dipilih'
                                    ])
                                    ->required(),
                            ]),

                        

                        Section::make('Pajak Impor (Opsional)')
                            ->description('Isi nilai pajak impor ketika pembayaran ini mencakup PPN Impor, PPh 22, atau Bea Masuk. Nilai akan dijurnal saat pembayaran Kas/Bank.')
                            ->columns(2)
                            ->schema([
                                Toggle::make('is_import_payment')
                                    ->label('Pembayaran mencakup pajak impor?')
                                    ->helperText('Aktifkan bila pembayaran impor melibatkan PPN/PPh/Bea. Biarkan mati jika bukan transaksi impor.')
                                    ->reactive()
                                    ->default(false),
                                TextInput::make('ppn_import_amount')
                                    ->label('PPN Impor')
                                    ->indonesianMoney()
                                    ->default(0)
                                    ->disabled(fn($get) => !$get('is_import_payment'))
                                    ->dehydrated()
                                    ->helperText('Masukkan nilai PPN Masukan impor yang akan diakui saat pembayaran'),
                                TextInput::make('pph22_amount')
                                    ->label('PPh 22 Impor')
                                    ->indonesianMoney()
                                    ->default(0)
                                    ->disabled(fn($get) => !$get('is_import_payment'))
                                    ->dehydrated()
                                    ->helperText('Opsional: Pajak PPh 22 yang dibayarkan saat impor'),
                                TextInput::make('bea_masuk_amount')
                                    ->label('Bea Masuk')
                                    ->indonesianMoney()
                                    ->default(0)
                                    ->disabled(fn($get) => !$get('is_import_payment'))
                                    ->dehydrated()
                                    ->helperText('Opsional: biaya Bea Masuk yang dibayarkan di bea cukai'),
                            ]),

                        // Hidden fields for backward compatibility
                        Hidden::make('status')->default('Draft'),
                        Hidden::make('payment_adjustment')->default(0),
                        Hidden::make('diskon')->default(0),

                        // Wire model fields for JavaScript communication (dehydrated for saving)
                        Hidden::make('selected_invoices')
                            ->reactive()
                            ->dehydrated(true)
                            ->live(onBlur: true),
                        Hidden::make('invoice_receipts')
                            ->reactive()
                            ->dehydrated(true)
                            ->live(onBlur: true),
                    ])
            ]);
    }

    public static function getEloquentQuery(): \Illuminate\Database\Eloquent\Builder
    {
        return parent::getEloquentQuery()->with(['supplier', 'vendorPaymentDetail.invoice']);
    }

    public static function formatMoneyState($value): string
    {
        return number_format((float) MoneyHelper::safeParse($value ?? 0), 2, ',', '.');
    }

    protected static function formatVendorPaymentTotal(?VendorPayment $payment, mixed $amount): string
    {
        $invoice = null;
        $selectedInvoices = $payment?->selected_invoices;
        $invoiceIds = is_string($selectedInvoices) ? json_decode($selectedInvoices, true) : $selectedInvoices;

        if (is_array($invoiceIds) && !empty($invoiceIds)) {
            $invoice = Invoice::find((int) reset($invoiceIds));
        }

        if (! $invoice && $payment?->relationLoaded('vendorPaymentDetail')) {
            $invoice = $payment->vendorPaymentDetail->first()?->invoice;
        }

        $sourceAmount = $payment?->total_payment ?? $amount;

        return $invoice
            ? PurchaseInvoiceResource::formatInvoiceCurrencyPair($invoice, $sourceAmount)
            : MoneyHelper::rupiah($amount);
    }

    public static function calculateSelectedInvoiceTotal($invoices): float
    {
        return self::buildInvoicePaymentSnapshot($invoices)->sum('remaining_amount');
    }

    public static function resolveInvoiceRemainingAmount(Invoice $invoice): float
    {
        // Invoice batal sudah dijurnal balik dan hutangnya dikeluarkan; jangan jatuh ke fallback total invoice.
        if ($invoice->isCancelled()) {
            return 0.0;
        }

        $accountPayable = $invoice->accountPayable;

        if ($invoice->relationLoaded('accountPayable') && $accountPayable?->getKey()) {
            return max(0, (float) MoneyHelper::safeParse($accountPayable->remaining_original ?? $accountPayable->remaining ?? 0));
        }

        if ($accountPayable?->getKey()) {
            return max(0, (float) MoneyHelper::safeParse($accountPayable->remaining_original ?? $accountPayable->remaining ?? 0));
        }

        $paidTotal = (float) VendorPaymentDetail::query()
            ->where('invoice_id', $invoice->id)
            ->selectRaw('COALESCE(SUM(amount + COALESCE(adjustment_amount, 0)), 0) as paid_total')
            ->value('paid_total');

        return max(0, (float) MoneyHelper::safeParse($invoice->total ?? 0) - $paidTotal);
    }

    private static function buildInvoicePaymentSnapshot($invoices)
    {
        $invoiceCollection = collect($invoices)->values();

        if ($invoiceCollection->isEmpty()) {
            return collect();
        }

        $invoiceIds = $invoiceCollection->pluck('id')->filter()->values();
        $fallbackPaidTotals = VendorPaymentDetail::query()
            ->whereIn('invoice_id', $invoiceIds)
            ->selectRaw('invoice_id, COALESCE(SUM(amount + COALESCE(adjustment_amount, 0)), 0) as paid_total')
            ->groupBy('invoice_id')
            ->pluck('paid_total', 'invoice_id');

        return $invoiceCollection->map(function ($invoice) use ($fallbackPaidTotals) {
            $totalAmount = (float) MoneyHelper::safeParse($invoice->total ?? 0);
            $accountPayable = $invoice->accountPayable;
            $remainingAmount = $accountPayable?->getKey()
                ? max(0, (float) MoneyHelper::safeParse($accountPayable->remaining_original ?? $accountPayable->remaining ?? 0))
                : max(0, $totalAmount - (float) ($fallbackPaidTotals[$invoice->id] ?? 0));

            return [
                'invoice' => $invoice,
                'total_amount' => $totalAmount,
                'remaining_amount' => $remainingAmount,
            ];
        });
    }

    public static function buildPaymentDetails($invoices): array
    {
        return self::buildInvoicePaymentSnapshot($invoices)->map(function ($snapshot) {
            /** @var Invoice $invoice */
            $invoice = $snapshot['invoice'];
            $remainingAmount = $snapshot['remaining_amount'];

            return [
                'invoice_id' => $invoice->id,
                'invoice_number' => $invoice->invoice_number,
                'invoice_date' => $invoice->invoice_date ? $invoice->invoice_date->toDateString() : null,
                'due_date' => $invoice->due_date ? $invoice->due_date->toDateString() : null,
                'total_invoice' => self::formatMoneyState($snapshot['total_amount']),
                'remaining_amount' => self::formatMoneyState($remainingAmount),
                'payment_amount' => self::formatMoneyState($remainingAmount),
                'total_invoice_display' => PurchaseInvoiceResource::formatInvoiceCurrencyPair($invoice, $snapshot['total_amount']),
                'remaining_amount_display' => PurchaseInvoiceResource::formatInvoiceCurrencyPair($invoice, $remainingAmount),
            ];
        })->toArray();
    }

    public static function mutateFormDataBeforeFill(array $data): array
    {

        // For edit mode, set payment_details based on selected_invoices
        if (!empty($data['selected_invoices'])) {
            try {
                // Handle both array and JSON string formats
                $selectedInvoices = $data['selected_invoices'];

                // If it's a JSON string, decode it
                if (is_string($selectedInvoices)) {
                    $selectedInvoices = json_decode($selectedInvoices, true);
                }

                // Ensure it's an array
                if (!is_array($selectedInvoices)) {
                    $selectedInvoices = [];
                }

                if (!empty($selectedInvoices)) {
                    $invoices = Invoice::whereIn('id', $selectedInvoices)
                        ->with('accountPayable')
                        ->get();

                    $data['payment_details'] = self::buildPaymentDetails($invoices);
                } else {
                    $data['payment_details'] = [];
                }
            } catch (\Throwable $exception) {
                Log::warning('VendorPaymentResource: gagal mengisi detail pembayaran', [
                    'vendor_payment_id' => $data['id'] ?? null,
                    'error' => $exception->getMessage(),
                ]);
                ProcurementFailureNotifier::warning(
                    'Detail Pembayaran Belum Lengkap',
                    $exception,
                    'Detail pembayaran vendor belum berhasil dimuat sepenuhnya. Silakan refresh halaman atau periksa invoice yang terkait.'
                );
                $data['payment_details'] = [];
                $data['selected_invoices'] = [];
            }
        } else {
            $data['payment_details'] = [];
        }

        return $data;
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('payment_number')
                    ->label('No. Pembayaran')
                    ->searchable()
                    ->sortable()
                    ->copyable()
                    ->placeholder(fn ($record) => 'VP-' . str_pad($record->id, 5, '0', STR_PAD_LEFT)),

                TextColumn::make('transfer_reference_number')
                    ->label('No. Ref Transfer')
                    ->searchable()
                    ->placeholder('-')
                    ->toggleable(),

                TextColumn::make('cabang.name')
                    ->label('Cabang')
                    ->sortable()
                    ->placeholder('-'),

                TextColumn::make('supplier')
                    ->label('Supplier')
                    ->formatStateUsing(function ($state) {
                        return "({$state->code}) {$state->perusahaan}";
                    })
                    ->searchable(query: function (Builder $query, $search) {
                        $query->whereHas('supplier', function ($query) use ($search) {
                            $query->where('code', 'LIKE', '%' . $search . '%')
                                ->orWhere('perusahaan', 'LIKE', '%' . $search . '%');
                        });
                    }),

                TextColumn::make('invoice_summary')
                    ->label('Invoices')
                    ->getStateUsing(function ($record) {
                        // Ensure we get the casted array value
                        $selectedInvoices = $record->selected_invoices;

                        if (!$selectedInvoices || empty($selectedInvoices)) {
                            $invoiceNumbers = $record->vendorPaymentDetail
                                ->map(fn ($detail) => $detail->invoice?->invoice_number)
                                ->filter()
                                ->values()
                                ->all();

                            return !empty($invoiceNumbers) ? implode(', ', $invoiceNumbers) : '-';
                        }

                        // Handle both JSON string and array formats
                        $invoiceIds = is_string($selectedInvoices) ? json_decode($selectedInvoices, true) : $selectedInvoices;
                        if (!is_array($invoiceIds)) {
                            return '-';
                        }

                        try {
                            // Static cache to avoid N+1 when rendering multiple rows
                            static $invoiceNumberCache = [];
                            $missingIds = array_values(array_diff($invoiceIds, array_keys($invoiceNumberCache)));
                            if (!empty($missingIds)) {
                                $invoiceNumberCache += Invoice::whereIn('id', $missingIds)
                                    ->pluck('invoice_number', 'id')
                                    ->toArray();
                            }
                            $numbers = array_filter(array_map(fn ($id) => $invoiceNumberCache[$id] ?? null, $invoiceIds));
                            return $numbers ? implode(', ', $numbers) : '-';
                        } catch (\Throwable $exception) {
                            Log::warning('VendorPaymentResource invoice summary rendering failed', [
                                'vendor_payment_id' => $record->id,
                                'error' => $exception->getMessage(),
                            ]);

                            return 'Data invoice tidak tersedia';
                        }
                    }),

                TextColumn::make('payment_date')
                    ->label('Tanggal Pembayaran')
                    ->date('d/m/Y')
                    ->sortable(),

                TextColumn::make('ntpn')
                    ->label('NTPN')
                    ->searchable()
                    ->placeholder('-'),

                TextColumn::make('total_payment')
                    ->label('Total Pembayaran (Rp / Source)')
                    ->formatStateUsing(fn ($state, VendorPayment $record) => self::formatVendorPaymentTotal($record, $state))
                    ->sortable(),

                TextColumn::make('payment_method')
                    ->label('Metode Pembayaran')
                    ->badge()
                    ->color(fn(string $state): string => match ($state) {
                        'Cash' => 'success',
                        'Bank Transfer' => 'info',
                        'bank_transfer' => 'info',
                        'Credit' => 'warning',
                        'Deposit' => 'gray',
                        default => 'gray',
                    }),

                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->formatStateUsing(fn ($state) => VendorPayment::STATUS_LABELS[$state] ?? $state)
                    ->color(fn(string $state): string => match ($state) {
                        'Draft' => 'gray',
                        'Partial' => 'warning',
                        'Paid' => 'success',
                        'Approved' => 'success',
                        'Rejected' => 'danger',
                        default => 'gray',
                    }),

                TextColumn::make('created_at')
                    ->label('Dibuat')
                    ->dateTime('d/m/Y H:i')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('supplier_id')
                    ->label('Supplier')
                    ->relationship('supplier', 'perusahaan')
                    ->searchable()
                    ->preload(),
                SelectFilter::make('payment_method')
                    ->label('Metode Pembayaran')
                    ->options([
                        'Cash' => 'Cash',
                        'Bank Transfer' => 'Bank Transfer',
                        'Credit' => 'Credit',
                        'Deposit' => 'Deposit',
                    ]),
                SelectFilter::make('status')
                    ->label('Status')
                    ->options(VendorPayment::STATUS_LABELS),
            ])
            ->actions([
                ActionGroup::make([
                    Tables\Actions\ViewAction::make(),
                    Tables\Actions\EditAction::make()
                        ->visible(fn ($record) => strtolower((string) $record->status) === 'draft'),
                    Tables\Actions\Action::make('view_journal_entries')
                        ->label('Journal Entries')
                        ->icon('heroicon-o-document-text')
                        ->color('info')
                        ->url(fn($record) => route('filament.admin.resources.journal-entries.index', [
                            'tableFilters[source_type][value]' => 'App\Models\VendorPayment',
                            'tableFilters[source_id][source_id]' => $record->id
                        ]))
                        ->openUrlInNewTab(),
                    Tables\Actions\DeleteAction::make()
                        ->visible(fn ($record) => strtolower((string) $record->status) === 'draft'),
                ]),
            ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make()
                        ->action(function ($records) {
                            $drafts = $records->filter(fn ($r) => strtolower((string) $r->status) === 'draft');
                            $nonDrafts = $records->count() - $drafts->count();
                            $drafts->each->delete();
                            if ($nonDrafts > 0) {
                                \Filament\Notifications\Notification::make()
                                    ->warning()
                                    ->title('Sebagian Pembayaran Tidak Dihapus')
                                    ->body("Hanya {$drafts->count()} pembayaran status Draft yang dihapus. {$nonDrafts} pembayaran yang sudah diproses tidak dapat dihapus.")
                                    ->send();
                            }
                        }),
                ]),
            ])
            ->defaultSort('created_at', 'desc')
            ->description(new \Illuminate\Support\HtmlString(
                '<details class="mb-4">' .
                    '<summary class="cursor-pointer font-semibold">Panduan Vendor Payment (Pembayaran Vendor/Supplier)</summary>' .
                    '<div class="mt-2 text-sm">' .
                    '<ul class="list-disc pl-5">' .
                    '<li><strong>Apa ini:</strong> Vendor Payment adalah record pembayaran kepada vendor/supplier untuk melunasi invoice pembelian yang telah diterima.</li>' .
                    '<li><strong>Metode Pembayaran:</strong> <em>Cash</em> (tunai), <em>Bank Transfer</em> (transfer bank), <em>Check</em> (cek), <em>Giro</em> (bilyet giro), atau <em>Other</em> (metode lainnya).</li>' .
                    '<li><strong>Komponen Utama:</strong> <em>Supplier</em> (vendor penerima pembayaran), <em>Invoice(s)</em> (invoice yang dibayar - bisa multiple), <em>Payment Date</em> (tanggal pembayaran), <em>Total Payment</em> (total nominal), <em>Payment Method</em> (metode pembayaran).</li>' .
                    '<li><strong>Multiple Invoices:</strong> Satu vendor payment dapat digunakan untuk membayar beberapa invoice sekaligus. Sistem akan otomatis mengalokasikan pembayaran ke masing-masing invoice.</li>' .
                    '<li><strong>Payment Allocation:</strong> Pembayaran dialokasikan ke invoice berdasarkan urutan tanggal invoice (FIFO - First In First Out) atau dapat diatur manual per item invoice.</li>' .
                    '<li><strong>Validasi:</strong> <em>Invoice Validation</em> - memastikan invoice masih outstanding. <em>Amount Check</em> - total payment tidak melebihi total outstanding invoice. <em>Supplier Match</em> - invoice harus milik supplier yang sama.</li>' .
                    '<li><strong>Integration:</strong> Terintegrasi dengan <em>Purchase Invoice</em> (pelunasan), <em>Account Payable</em> (pengurangan hutang), <em>Journal Entry</em> (otomatis buat jurnal), <em>Cash/Bank Account</em> (pengurangan saldo), dan <em>Deposit</em> (untuk overpayment).</li>' .
                    '<li><strong>Actions:</strong> <em>View</em> (lihat detail payment), <em>Edit</em> (ubah payment), <em>Delete</em> (hapus payment), <em>Print Payment</em> (cetak bukti pembayaran), <em>Generate Journal</em> (buat jurnal entry).</li>' .
                    '<li><strong>Permissions:</strong> <em>view any vendor payment</em>, <em>create vendor payment</em>, <em>update vendor payment</em>, <em>delete vendor payment</em>, <em>restore vendor payment</em>, <em>force-delete vendor payment</em>.</li>' .
                    '<li><strong>Journal Impact:</strong> Otomatis membuat journal entry dengan debit Account Payable dan credit Cash/Bank Account. Overpayment akan dicatat sebagai vendor deposit.</li>' .
                    '<li><strong>Reporting:</strong> Menyediakan data untuk accounts payable aging, cash disbursement journal, dan vendor payment history tracking.</li>' .
                    '</ul>' .
                    '</div>' .
                    '</details>'
            ));
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListVendorPayments::route('/'),
            'create' => Pages\CreateVendorPayment::route('/create'),
            'view' => Pages\ViewVendorPayment::route('/{record}'),
            'edit' => Pages\EditVendorPayment::route('/{record}/edit'),
        ];
    }
}
