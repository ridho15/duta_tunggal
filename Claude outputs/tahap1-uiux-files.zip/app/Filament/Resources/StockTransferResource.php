<?php

namespace App\Filament\Resources;

use App\Filament\Resources\StockTransferResource\Pages;
use App\Filament\Resources\StockTransferResource\Pages\ViewStockTransfer;
use App\Http\Controllers\HelperController;
use App\Models\InventoryStock;
use App\Models\Product;
use App\Models\Rak;
use App\Models\StockTransfer;
use App\Models\Warehouse;
use App\Services\StockTransferService;
use Filament\Forms\Components\Actions\Action;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Actions\Action as ActionsAction;
use Filament\Tables\Actions\ActionGroup;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Actions\DeleteBulkAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Filament\Tables\Enums\ActionsPosition;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class StockTransferResource extends Resource
{
    use \App\Filament\Concerns\HasMenuAccess;

    protected static ?string $model = StockTransfer::class;

    protected static bool $shouldRegisterNavigation = true;

    protected static ?string $navigationIcon = 'heroicon-o-arrows-right-left';

    protected static ?string $navigationGroup = 'GUDANG';

    protected static ?string $navigationLabel = 'Pindah Stok';

    protected static ?string $modelLabel = 'Pindah Stok';

    protected static ?string $pluralModelLabel = 'Pindah Stok';

    protected static ?int $navigationSort = 4;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Fieldset::make('Form Stock Transfer')
                    ->schema([
                        TextInput::make('transfer_number')
                            ->required()
                            ->unique(ignoreRecord: true)
                            ->suffixAction(Action::make('generatePoNumber')
                                ->icon('heroicon-m-arrow-path') // ikon reload
                                ->tooltip('Generate PO Number')
                                ->action(function ($set, $get, $state) {
                                    $stockTransferService = app(StockTransferService::class);
                                    $set('transfer_number', $stockTransferService->generateTransferNumber());
                                }))
                            ->maxLength(255),
                        DateTimePicker::make('transfer_date')
                            ->label('Tanggal Transfer')
                            ->required(),
                        Select::make('from_warehouse_id')
                            ->label('Dari Gudang')
                            ->preload()
                            ->searchable()
                            ->live()
                            ->relationship('fromWarehouse', 'id', function (Builder $query) {
                                // Show all warehouses across all branches
                                $query->withoutGlobalScope(\App\Models\Scopes\CabangScope::class);
                            })
                            ->getOptionLabelFromRecordUsing(function (Warehouse $warehouse) {
                                return "({$warehouse->kode}) {$warehouse->name}";
                            })
                            ->required(),
                        Select::make('to_warehouse_id')
                            ->label('Ke Gudang')
                            ->preload()
                            ->searchable()
                            ->live()
                            ->relationship('toWarehouse', 'id', function (Builder $query, $get) {
                                $fromId = $get('from_warehouse_id');
                                $query->withoutGlobalScope(\App\Models\Scopes\CabangScope::class);
                                if ($fromId) {
                                    $query->where('id', '!=', $fromId);
                                }
                            })
                            ->getOptionLabelFromRecordUsing(function (Warehouse $warehouse) {
                                return "({$warehouse->kode}) {$warehouse->name}";
                            })
                            ->required(),
                        Repeater::make('stockTransferItem')
                            ->relationship()
                            ->live()
                            ->label('Transfer Items')
                            ->columnSpanFull()
                            ->columns(2)
                            ->minItems(1)
                            ->defaultItems(1)
                            ->schema([
                                Select::make('product_id')
                                    ->label('Product')
                                    ->searchable()
                                    ->live()
                                    ->helperText(function ($get) {
                                        $whId = $get('from_warehouse_id') ?: $get('../../from_warehouse_id');
                                        $productId = $get('product_id');
                                        if (! $whId || ! $productId) {
                                            return null;
                                        }
                                        $inventoryStock = InventoryStock::where('warehouse_id', $whId)
                                            ->where('product_id', $productId)->first();
                                        if ($inventoryStock && $inventoryStock->rak) {
                                            $codeStr = filled($inventoryStock->rak->code) ? "({$inventoryStock->rak->code}) " : '';
                                            return "Rak Default: " . $codeStr . ($inventoryStock->rak->name ?? '-');
                                        }

                                        return "Rak Default: -";
                                    })
                                    ->getOptionLabelUsing(fn ($value): ?string => ($p = Product::find($value)) ? "({$p->sku}) {$p->name}" : null)
                                    ->options(function ($get, $state) {
                                        if ($state && ($p = Product::find($state))) {
                                            return [$p->id => "({$p->sku}) {$p->name}"];
                                        }
                                        $whId = $get('from_warehouse_id') ?: $get('../../from_warehouse_id');
                                        if (! $whId) {
                                            return [];
                                        }
                                        return Product::whereHas('inventoryStock', function (Builder $q) use ($whId) {
                                            $q->where('warehouse_id', $whId)->where('qty_available', '>', 0);
                                        })->limit(50)->get()->mapWithKeys(fn (Product $p) => [$p->id => "({$p->sku}) {$p->name}"])->toArray();
                                    })
                                    ->getSearchResultsUsing(function (string $search, $get) {
                                        $whId = $get('from_warehouse_id') ?: $get('../../from_warehouse_id');
                                        $query = Product::query()
                                            ->where(function ($q) use ($search) {
                                                $q->where('name', 'like', "%{$search}%")
                                                    ->orWhere('sku', 'like', "%{$search}%");
                                            });
                                        if ($whId) {
                                            $query->whereHas('inventoryStock', function (Builder $q) use ($whId) {
                                                $q->where('warehouse_id', $whId);
                                            });
                                        }
                                        return $query->limit(50)->get()->mapWithKeys(fn (Product $p) => [$p->id => "({$p->sku}) {$p->name}"])->toArray();
                                    })
                                    ->required(),
                                TextInput::make('quantity')
                                    ->label('Quantity')
                                    ->numeric()
                                    ->default(1)
                                    ->minValue(1)
                                    ->required(),
                                Select::make('from_warehouse_id')
                                    ->label('Dari Gudang')
                                    ->preload()
                                    ->searchable()
                                    ->live()
                                    ->default(function ($get) {
                                        return $get('../../from_warehouse_id');
                                    })
                                    ->afterStateUpdated(fn ($set) => $set('from_rak_id', null))
                                    ->options(fn () => static::resolveWarehouseOptions())
                                    ->getSearchResultsUsing(fn (string $search) => static::resolveWarehouseOptions($search))
                                    ->required(),
                                Select::make('from_rak_id')
                                    ->label('Dari Rak')
                                    ->preload()
                                    ->live()
                                    ->searchable()
                                    ->nullable()
                                    ->options(function ($get) {
                                        $whId = $get('from_warehouse_id') ?: $get('../../from_warehouse_id');
                                        return StockAdjustmentResource::resolveRakOptions((int) $whId);
                                    })
                                    ->getSearchResultsUsing(function (string $search, $get) {
                                        $whId = $get('from_warehouse_id') ?: $get('../../from_warehouse_id');
                                        return StockAdjustmentResource::resolveRakOptions((int) $whId, $search);
                                    })
                                    ->helperText(function ($get) {
                                        $productId = $get('product_id');
                                        $rakId = $get('from_rak_id');
                                        $whId = $get('from_warehouse_id') ?: $get('../../from_warehouse_id');
                                        if (! $productId || ! $rakId || ! $whId) {
                                            return 'Opsional jika gudang tidak memiliki rak.';
                                        }

                                        $inventoryStock = InventoryStock::where('product_id', $productId)
                                            ->where('warehouse_id', $whId)
                                            ->where('rak_id', $rakId)
                                            ->first();
                                        if ($inventoryStock) {
                                            return 'Jumlah stok fisik ' . number_format((float) $inventoryStock->qty_available, 0, ',', '.');
                                        }

                                        return 'Opsional jika gudang tidak memiliki rak.';
                                    }),
                                Select::make('to_warehouse_id')
                                    ->label('Ke Gudang')
                                    ->preload()
                                    ->searchable()
                                    ->live()
                                    ->default(function ($get) {
                                        return $get('../../to_warehouse_id');
                                    })
                                    ->afterStateUpdated(fn ($set) => $set('to_rak_id', null))
                                    ->options(fn () => static::resolveWarehouseOptions())
                                    ->getSearchResultsUsing(fn (string $search) => static::resolveWarehouseOptions($search))
                                    ->required(),
                                Select::make('to_rak_id')
                                    ->label('Ke Rak')
                                    ->preload()
                                    ->live()
                                    ->searchable()
                                    ->nullable()
                                    ->options(function ($get) {
                                        $whId = $get('to_warehouse_id') ?: $get('../../to_warehouse_id');
                                        return StockAdjustmentResource::resolveRakOptions((int) $whId);
                                    })
                                    ->getSearchResultsUsing(function (string $search, $get) {
                                        $whId = $get('to_warehouse_id') ?: $get('../../to_warehouse_id');
                                        return StockAdjustmentResource::resolveRakOptions((int) $whId, $search);
                                    })
                                    ->helperText(function ($get) {
                                        $productId = $get('product_id');
                                        $rakId = $get('to_rak_id');
                                        $whId = $get('to_warehouse_id') ?: $get('../../to_warehouse_id');
                                        if (! $productId || ! $rakId || ! $whId) {
                                            return 'Opsional jika gudang tidak memiliki rak.';
                                        }

                                        $inventoryStock = InventoryStock::where('product_id', $productId)
                                            ->where('warehouse_id', $whId)
                                            ->where('rak_id', $rakId)
                                            ->first();
                                        if ($inventoryStock) {
                                            return 'Jumlah stok fisik ' . number_format((float) $inventoryStock->qty_available, 0, ',', '.');
                                        }

                                        return 'Opsional jika gudang tidak memiliki rak.';
                                    })
                            ])
                    ])
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('created_at', 'desc')
            ->columns([
                TextColumn::make('transfer_number')
                    ->label('Transfer Number')
                    ->searchable(),
                TextColumn::make('transfer_date')
                    ->label('Tanggal Transfer')
                    ->dateTime()
                    ->sortable(),
                TextColumn::make('fromWarehouse')
                    ->label('Dari Gudang')
                    ->formatStateUsing(function ($state) {
                        return "({$state->kode}) {$state->name}";
                    })
                    ->searchable(query: function (Builder $query, $search) {
                        $query->whereHas('fromWarehouse', function (Builder $query) use ($search) {
                            $query->where('kode', 'LIKE', '%' . $search . '%')
                                ->orWhere('name', 'LIKE', '%' . $search . '%');
                        });
                    }),
                TextColumn::make('toWarehouse')
                    ->label('Ke Gudang')
                    ->formatStateUsing(function ($state) {
                        return "({$state->kode}) {$state->name}";
                    })
                    ->searchable(query: function (Builder $query, $search) {
                        $query->whereHas('toWarehouse', function (Builder $query) use ($search) {
                            $query->where('kode', 'LIKE', '%' . $search . '%')
                                ->orWhere('name', 'LIKE', '%' . $search . '%');
                        });
                    }),
                TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->color(function ($state) {
                        return match ($state) {
                            'Draft' => 'gray',
                            'Request' => 'primary',
                            'Approved' => 'success',
                            'Reject' => 'danger',
                            'Cancelled' => 'warning',
                            default => '-'
                        };
                    })
                    ->formatStateUsing(function ($state) {
                        return Str::upper($state);
                    }),
                TextColumn::make('stockTransferItem.product.name')
                    ->label('Items')
                    ->badge(),
                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('deleted_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                ActionGroup::make([
                    ViewAction::make()
                        ->color('primary'),
                    EditAction::make()
                        ->visible(fn ($record) => in_array($record->status, ['Draft', 'Request'], true))
                        ->color('success'),
                    DeleteAction::make()
                        ->visible(fn ($record) => in_array($record->status, ['Draft', 'Request', 'Reject'], true)),
                    ActionsAction::make('request_transfer')
                        ->label('Request Transfer')
                        ->color('success')
                        ->requiresConfirmation()
                        ->visible(function ($record) {
                            return static::canRequestTransfer() && $record->status == 'Draft';
                        })
                        ->icon('heroicon-o-arrow-down-circle')
                        ->action(function ($record) {
                            try {
                                $stockTransferService = app(StockTransferService::class);
                                $stockTransferService->requestTransfer($record);
                                HelperController::sendNotification(isSuccess: true, title: "Information", message: "Request stock transfer berhasil dikirimkan. Proses selanjutnya: Manajer Gudang atau Manajer Logistik perlu mereview dan menyetujui permintaan transfer stok ini.");
                            } catch (ValidationException $exception) {
                                HelperController::sendNotification(isSuccess: false, title: 'Validasi Transfer Stok', message: collect($exception->errors())->flatten()->implode("\n"));
                            }
                        }),
                    ActionsAction::make('approve')
                        ->label('Approve')
                        ->color('success')
                        ->icon('heroicon-o-check-badge')
                        ->requiresConfirmation()
                        ->visible(function ($record) {
                            return static::canResponseTransfer() && $record->status == 'Request';
                        })
                        ->action(function ($record) {
                            try {
                                $stockTransferService = app(StockTransferService::class);
                                $stockTransferService->approveStockTransfer($record);
                                HelperController::sendNotification(isSuccess: true, title: 'Information', message: "Request transfer stock berhasil diapprove. Proses selanjutnya: Tim Gudang perlu memproses dan mengirimkan barang sesuai dengan jumlah transfer yang telah disetujui.");
                            } catch (ValidationException $exception) {
                                HelperController::sendNotification(isSuccess: false, title: 'Validasi Transfer Stok', message: collect($exception->errors())->flatten()->implode("\n"));
                            }
                        }),
                    ActionsAction::make('reject')
                        ->label('Reject')
                        ->color('danger')
                        ->icon('heroicon-o-x-circle')
                        ->requiresConfirmation()
                        ->visible(function ($record) {
                            return static::canResponseTransfer() && $record->status == 'Request';
                        })
                        ->action(function ($record) {
                            try {
                                app(StockTransferService::class)->rejectTransfer($record);
                                HelperController::sendNotification(isSuccess: true, title: 'Information', message: "Request transfer stock ditolak. Proses selanjutnya: Pemohon perlu merevisi permintaan transfer sesuai keterangan penolakan dan mengajukan kembali.");
                            } catch (ValidationException $exception) {
                                HelperController::sendNotification(isSuccess: false, title: 'Validasi Transfer Stok', message: collect($exception->errors())->flatten()->implode("\n"));
                            }
                        })
                ])
            ], position: ActionsPosition::BeforeColumns)
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ])
            ->description(new \Illuminate\Support\HtmlString(
                '<details class="mb-4">' .
                    '<summary class="cursor-pointer font-semibold">Panduan Stock Transfer</summary>' .
                    '<div class="mt-2 text-sm">' .
                        '<ul class="list-disc pl-5">' .
                            '<li><strong>Apa ini:</strong> Stock Transfer adalah proses pemindahan stok inventory dari satu gudang ke gudang lainnya dalam perusahaan.</li>' .
                            '<li><strong>Status Flow:</strong> Draft → Request → Approved/Reject. Transfer harus melalui approval workflow sebelum dieksekusi.</li>' .
                            '<li><strong>Warehouse Selection:</strong> Pilih gudang asal (From) dan gudang tujuan (To) untuk transfer stok antar lokasi.</li>' .
                            '<li><strong>Items Transfer:</strong> Pilih produk, quantity, dan rak tujuan untuk setiap item yang akan ditransfer.</li>' .
                            '<li><strong>Actions:</strong> <em>Request Transfer</em> (draft), <em>Approve/Reject</em> (request). Setiap transfer memerlukan approval dari authorized user.</li>' .
                            '<li><strong>Permissions:</strong> <em>request stock transfer</em> untuk membuat request, <em>response stock transfer</em> untuk approve/reject.</li>' .
                            '<li><strong>Integration:</strong> Terintegrasi dengan inventory management, stock movement tracking, dan warehouse management.</li>' .
                        '</ul>' .
                    '</div>' .
                '</details>'
            ));
    }

    public static function canEdit(Model $record): bool
    {
        return parent::canEdit($record) && in_array($record->status, ['Draft', 'Request'], true);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function canRequestTransfer(): bool
    {
        $user = Auth::user();
        if (! $user) {
            return false;
        }

        return $user->hasRole(['Super Admin', 'Owner', 'Admin', 'Admin Inventory', 'Inventory Manager', 'Warehouse Staff'])
            || $user->hasPermissionTo('request stock transfer');
    }

    public static function canResponseTransfer(): bool
    {
        $user = Auth::user();
        if (! $user) {
            return false;
        }

        return $user->hasRole(['Super Admin', 'Owner', 'Admin', 'Admin Inventory', 'Inventory Manager', 'Warehouse Staff'])
            || $user->hasPermissionTo('response stock transfer');
    }

    public static function resolveWarehouseOptions(?string $search = null): array
    {
        $query = Warehouse::query()->withoutGlobalScope(\App\Models\Scopes\CabangScope::class);

        if (filled($search)) {
            $query->where(function (Builder $q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('kode', 'like', "%{$search}%");
            });
        }

        return $query->get()->mapWithKeys(function (Warehouse $w) {
            $label = filled($w->kode) ? "({$w->kode}) {$w->name}" : $w->name;
            return [$w->id => $label];
        })->toArray();
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListStockTransfers::route('/'),
            'create' => Pages\CreateStockTransfer::route('/create'),
            'view' => ViewStockTransfer::route('/{record}'),
            'edit' => Pages\EditStockTransfer::route('/{record}/edit'),
        ];
    }
}
