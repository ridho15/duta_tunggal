<?php

namespace Database\Seeders;

use App\Http\Controllers\HelperController;
use App\Models\Customer;
use App\Models\Permission;
use App\Models\Role;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Log;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $roleDescriptions = HelperController::roleDescriptions();

        $owner = Role::updateOrCreate([
            'name' => 'Owner',
        ], [
            'name' => 'Owner',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Owner'] ?? null,
        ]);

        $superAdmin = Role::updateOrCreate([
            'name' => 'Super Admin',
        ], [
            'name' => 'Super Admin',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Super Admin'] ?? null,
        ]);

        $admin = Role::updateOrCreate([
            'name' => 'Admin',
        ], [
            'name' => 'Admin',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Admin'] ?? null,
        ]);

        $salesManager = Role::updateOrCreate([
            'name' => 'Sales Manager',
        ], [
            'name' => 'Sales Manager',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Sales Manager'] ?? null,
        ]);

        $sales = Role::updateOrCreate([
            'name' => 'Sales',
        ], [
            'name' => 'Sales',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Sales'] ?? null,
        ]);

        $kasir = Role::updateOrCreate([
            'name' => 'Kasir',
        ], [
            'name' => 'Kasir',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Kasir'] ?? null,
        ]);

        $adminPengiriman = Role::updateOrCreate([
            'name' => 'Admin Pengiriman',
        ], [
            'name' => 'Admin Pengiriman',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Admin Pengiriman'] ?? null,
        ]);

        $inventoryManager = Role::updateOrCreate([
            'name' => 'Inventory Manager',
        ], [
            'name' => 'Inventory Manager',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Inventory Manager'] ?? null,
        ]);

        $adminInventory = Role::updateOrCreate([
            'name' => 'Admin Inventory',
        ], [
            'name' => 'Admin Inventory',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Admin Inventory'] ?? null,
        ]);

        $checker = Role::updateOrCreate([
            'name' => 'Checker',
        ], [
            'name' => 'Checker',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Checker'] ?? null,
        ]);

        $financeManager = Role::updateOrCreate([
            'name' => 'Finance Manager',
        ], [
            'name' => 'Finance Manager',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Finance Manager'] ?? null,
        ]);

        $adminKeuangan = Role::updateOrCreate([
            'name' => 'Admin Keuangan',
        ], [
            'name' => 'Admin Keuangan',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Admin Keuangan'] ?? null,
        ]);

        $accounting = Role::updateOrCreate([
            'name' => 'Accounting',
        ], [
            'name' => 'Accounting',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Accounting'] ?? null,
        ]);

        $purchasing = Role::updateOrCreate([
            'name' => 'Purchasing',
        ], [
            'name' => 'Purchasing',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Purchasing'] ?? null,
        ]);

        // Additional recommended roles
        $purchasingManager = Role::updateOrCreate([
            'name' => 'Purchasing Manager',
        ], [
            'name' => 'Purchasing Manager',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Purchasing Manager'] ?? null,
        ]);

        $warehouseStaff = Role::updateOrCreate([
            'name' => 'Warehouse Staff',
        ], [
            'name' => 'Warehouse Staff',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Warehouse Staff'] ?? null,
        ]);

        $deliveryDriver = Role::updateOrCreate([
            'name' => 'Delivery Driver',
        ], [
            'name' => 'Delivery Driver',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Delivery Driver'] ?? null,
        ]);

        $customerService = Role::updateOrCreate([
            'name' => 'Customer Service',
        ], [
            'name' => 'Customer Service',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Customer Service'] ?? null,
        ]);

        $auditor = Role::updateOrCreate([
            'name' => 'Auditor',
        ], [
            'name' => 'Auditor',
            'guard_name' => 'web',
            'description' => $roleDescriptions['Auditor'] ?? null,
        ]);

        $itSupport = Role::updateOrCreate([
            'name' => 'IT Support',
        ], [
            'name' => 'IT Support',
            'guard_name' => 'web',
            'description' => $roleDescriptions['IT Support'] ?? null,
        ]);


        $owner->syncPermissions(Permission::all());
        $superAdmin->syncPermissions(Permission::all());

        // Role -> resource mapping: each role gets ALL permissions for the listed resources
        $roleResourceMap = [
            'Admin' => [
                'user', 'role', 'permission', 'currency', 'chart of account',
                'tax setting', 'cabang', 'asset', 'journal entry', 'delivery schedule',
                'supplier', 'product', 'warehouse', 'unit of measure',
            ],
            'Finance Manager' => [
                'account payable', 'account receivable', 'vendor payment', 'vendor payment detail',
                'customer receipt', 'customer receipt item', 'invoice', 'invoice item',
                'deposit', 'deposit log', 'ageing schedule', 'voucher request',
                'asset', 'asset depreciation', 'asset disposal', 'asset transfer',
                'cash bank account', 'cash bank transaction detail', 'journal entry',
                'purchase return', 'customer return',
            ],
            'Admin Keuangan' => [
                'account payable', 'vendor payment', 'deposit', 'invoice', 'invoice item',
                'voucher request', 'asset', 'asset depreciation', 'asset disposal',
                'asset transfer', 'cash bank account', 'cash bank transaction detail', 'journal entry',
            ],
            'Accounting' => [
                'chart of account', 'account payable', 'account receivable', 'deposit',
                'invoice', 'invoice item', 'ageing schedule', 'asset', 'asset depreciation',
                'asset disposal', 'asset transfer', 'cash bank account',
                'cash bank transaction detail', 'journal entry',
            ],
            'Purchasing' => [
                'order request', 'order request item',
                'purchase order', 'purchase order item', 'purchase receipt', 'purchase receipt item',
                'purchase order biaya', 'purchase order currency', 'purchase return',
                'supplier', 'product',
            ],
            'Purchasing Manager' => [
                'order request', 'order request item',
                'purchase order', 'purchase order item', 'purchase receipt',
                'vendor payment', 'purchase return', 'purchase return item',
                'purchase order biaya', 'purchase order currency',
                'supplier', 'product', 'asset',
            ],
            'Inventory Manager' => [
                'warehouse', 'warehouse confirmation', 'inventory stock', 'stock movement',
                'stock transfer', 'stock transfer item', 'product', 'product category',
                'rak', 'unit of measure', 'product unit conversion', 'quality control',
                'asset transfer', 'bill of material', 'bill of material item',
                'production', 'production plan', 'material issue',
                'order request', 'order request item',
            ],
            'Admin Inventory' => [
                'warehouse', 'inventory stock', 'stock movement', 'product',
                'product category', 'rak', 'unit of measure', 'product unit conversion',
            ],
            'Warehouse Staff' => [
                'warehouse', 'warehouse confirmation', 'stock transfer', 'stock transfer item',
                'inventory stock', 'rak', 'quality control',
            ],
            'Checker' => [
                'warehouse confirmation', 'quality control', 'inventory stock',
                'purchase receipt item',
            ],
            'Sales Manager' => [
                'sales order', 'sales order item', 'quotation', 'quotation item',
                'invoice', 'customer', 'customer receipt', 'customer return',
                'return product', 'return product item', 'delivery order', 'surat jalan',
                'delivery schedule',
            ],
            'Sales' => [
                'sales order', 'sales order item', 'quotation', 'customer',
            ],
            'Kasir' => [
                'customer receipt', 'customer receipt item', 'invoice', 'deposit',
                'cash bank account',
            ],
            'Customer Service' => [
                'customer', 'quotation', 'sales order', 'delivery order',
                'surat jalan', 'delivery schedule', 'customer return',
            ],
            'Admin Pengiriman' => [], // izin rinci di blok khusus di bawah (tanpa hapus & tanpa konfirmasi DO)
            'Delivery Driver' => [
                'delivery order', 'delivery order item', 'vehicle', 'surat jalan', 'delivery schedule',
            ],
            'Auditor' => [], // Auditor receives only 'view any' for every resource (via special block below)
            'IT Support' => [
                'user', 'role', 'permission', 'tax setting', 'currency',
            ],
        ];

        // Apply permissions per role based on mapping
        foreach ($roleResourceMap as $roleName => $resources) {
            $role = Role::where('name', $roleName)->first();
            if (! $role) {
                continue;
            }

            $permsToAssign = [];
            $allDefined = HelperController::listPermission();
            $missingResources = [];
            foreach ($resources as $res) {
                // If mapping contains full list key (like auditor), handle separately
                if (is_int($res)) {
                    continue;
                }

                if ($res === 'AUDITOR_ALL') {
                    continue;
                }

                // if resource exists in helper list, collect all action names
                    if (isset($allDefined[$res])) {
                        // Do not grant destructive actions to most roles. Only allow for these roles:
                        $allowedDestructiveRoles = [
                        'Owner',
                        'Super Admin',
                        'Admin',
                        'Purchasing Manager',
                        'Inventory Manager',
                        'Finance Manager',
                        'Sales Manager',
                    ];

                        // NEG-3.3 fix: certain privileged actions must be excluded from staff-level roles
                        // even when the resource is in their access list.
                        $privilegedActionExclusions = [
                            // Sales staff may view/create/edit quotations but CANNOT approve or reject them.
                            // Approval is a Sales Manager responsibility (SALES_TIER_1_ROLES).
                            'Sales' => ['quotation' => ['approve', 'reject']],
                            // Customer Service assists with quotation workflow but cannot approve/reject.
                            'Customer Service' => ['quotation' => ['approve', 'reject']],
                        ];

                        foreach ($allDefined[$res] as $action) {
                            if (in_array($action, ['delete', 'force-delete']) && !in_array($roleName, $allowedDestructiveRoles, true)) {
                                // skip destructive action for this role
                                continue;
                            }

                            // Skip privileged actions excluded for this specific role+resource combination
                            if (isset($privilegedActionExclusions[$roleName][$res])
                                && in_array($action, $privilegedActionExclusions[$roleName][$res], true)) {
                                continue;
                            }

                            $permsToAssign[] = $action . ' ' . $res;
                        }
                    } else {
                        // collect missing mapping for logging/alerting
                        if (!in_array($res, ['AUDITOR_ALL'], true) && !is_int($res)) {
                            $missingResources[] = $res;
                        }
                    }
            }

            if (!empty($missingResources)) {
                Log::warning('RoleSeeder: unknown resources referenced in roleResourceMap', [
                    'role' => $roleName,
                    'missing_resources' => array_values(array_unique($missingResources)),
                ]);
            }

            // Special: Auditor — grant view any for all resources
            if ($roleName === 'Auditor') {
                foreach ($allDefined as $resName => $actions) {
                    if (in_array('view any', $actions)) {
                        $permsToAssign[] = 'view any ' . $resName;
                    }
                }
            }

            // Kasir: hanya boleh MELIHAT dan MENYETUJUI Sales Order (UAT B2) — bukan membuat/mengubah/menghapus.
            // Syarat harga sesuai batas harga master produk ditegakkan di ApprovalControlService.
            if ($roleName === 'Kasir') {
                array_push($permsToAssign, 'view any sales order', 'view sales order', 'response sales order');
            }

            // Admin Pengiriman (Spesifikasi UI/UX Bagian 5, kode ADP) — daftar sama dengan migrasi 2026_10_19_090000.
            if ($roleName === 'Admin Pengiriman') {
                array_push($permsToAssign,
                    'view any sales order', 'view sales order',
                    'view any delivery order', 'view delivery order', 'create delivery order', 'update delivery order', 'request delivery order',
                    'view any delivery order item', 'view delivery order item', 'create delivery order item', 'update delivery order item',
                    'view any surat jalan', 'view surat jalan', 'create surat jalan', 'update surat jalan', 'request surat jalan',
                    'view any invoice', 'view invoice', 'create invoice', 'update invoice',
                    'view any return product', 'view return product', 'create return product', 'update return product',
                    'view any return product item', 'view return product item', 'create return product item', 'update return product item',
                    'view any vehicle', 'view vehicle', 'create vehicle', 'update vehicle',
                    'view any driver', 'view driver', 'create driver', 'update driver',
                    'view any delivery schedule', 'view delivery schedule', 'create delivery schedule', 'update delivery schedule', 'update status delivery schedule',
                    'view any inventory stock', 'view inventory stock',
                );
            }

            // Sync unique permissions that exist in DB
            $permsToAssign = array_unique($permsToAssign);
            $existingPerms = Permission::whereIn('name', $permsToAssign)->get();
            if ($existingPerms->count()) {
                $role->syncPermissions($existingPerms);
            } else {
                Log::info('RoleSeeder: no existing permissions found to assign for role', [
                    'role' => $roleName,
                    'requested_permissions' => $permsToAssign,
                ]);
            }
        }
    }
}
