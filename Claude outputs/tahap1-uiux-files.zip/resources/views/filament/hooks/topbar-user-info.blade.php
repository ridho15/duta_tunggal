@auth
    @php
        $dtUser = auth()->user();
        $dtCabang = $dtUser->cabang?->nama ?? ($dtUser->manage_type === 'all' ? 'Semua cabang' : null);
        $dtRole = $dtUser->getRoleNames()->first();
    @endphp
    {{-- Spesifikasi UI/UX 3.2: kanan header "Nama · Cabang" --}}
    <div class="hidden sm:flex flex-col items-end leading-tight me-2 text-right">
        <span class="text-sm font-semibold text-gray-900">{{ $dtUser->name }}</span>
        <span class="text-xs text-gray-500">{{ collect([$dtRole, $dtCabang])->filter()->join(' · ') }}</span>
    </div>
@endauth
